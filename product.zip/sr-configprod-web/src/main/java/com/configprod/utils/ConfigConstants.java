package com.configprod.utils;

public class ConfigConstants {
	
	public static final String PROD_DETAILS = "findproddetails";
	//public static final String CONFIG_DELETE = "deleteconfig";
	public static final String DPROD_ID = "D";
	public static final String PPROD_ID = "P";
	public static final String PROD_CONFIG = "productConfig";
	public static final String BUSINESS_CONFIG = "businessconfig";
	public static final String PROD_TYPE_CD = "pType";

}
