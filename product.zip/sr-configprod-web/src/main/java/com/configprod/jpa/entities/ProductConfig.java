package com.configprod.jpa.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
//import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Lob;
//import javax.persistence.NamedQueries;
//import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
//import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


@Entity
@Table(name="TPRODUCT_CONFIG")
public class ProductConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PROD_ID")
	@GeneratedValue(generator="ProdSeq")  
    @GenericGenerator(name="ProdSeq", strategy="foreign", parameters=@Parameter(value="product", name = "property"))  
	private long productId;
	
	@Column(name="PROD_CONFIG")
	private String prodConfig;
	
	@PrimaryKeyJoinColumn
	private Product product;
	
	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProdConfig() {
		return prodConfig;
	}

	public void setProdConfig(String prodConfig) {
		this.prodConfig = prodConfig;
	}
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	
}
