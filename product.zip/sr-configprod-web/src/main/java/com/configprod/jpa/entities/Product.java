package com.configprod.jpa.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="TPRODUCT")
@NamedQuery(name="findproddetails",query="select p from Product p where p.productType = :pType ")
public class Product implements Serializable {
	

	@Id
	@Column(name="PROD_ID")
	@GeneratedValue(generator = "ProdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "ProdSeq", sequenceName = "SEQ_PROD_ID",   allocationSize = 1)
	private long productId;
	
	@Column(name="PROD_TYPE_CD")
	private String productType;

	@Column(name="PROD_NAME")
	private String productName;
	
	private ProductConfig pConfig;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy="product", cascade = CascadeType.ALL)
	public ProductConfig getPConfig() {
		return pConfig;
	}

	public void setPConfig(ProductConfig pConfig) {
		this.pConfig = pConfig;
	}

	
}