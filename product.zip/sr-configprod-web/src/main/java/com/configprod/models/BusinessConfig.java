package com.configprod.models;

public class BusinessConfig {
	
private String[] lob;

private String country;

public String[] getLob() {
	return lob;
}

public void setLob(String[] lob) {
	this.lob = lob;
}

public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}

@Override
public String toString()
{
	return "ClasssPojo [lob = "+lob+", country = "+country+"]";
}

}