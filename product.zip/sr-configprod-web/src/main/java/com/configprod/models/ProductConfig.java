package com.configprod.models;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProductConfig")
public class ProductConfig {
	
	
	private String region;
	
	private String lob;
	
	private BusinessConfig businessConfig;
	
	private String wfType;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public BusinessConfig getBusinessConfig() {
		return businessConfig;
	}

	public void setBusinessConfig(BusinessConfig businessConfig) {
		this.businessConfig = businessConfig;
	}

	public String getWfType() {
		return wfType;
	}

	public void setWfType(String wfType) {
		this.wfType = wfType;
	}
	
	public String toString()
	{
		return "ClassPojo [region = "+region+",lob = "+lob+", businessconfig = "+businessConfig+", wftype = "+wfType+"]";
	}
}