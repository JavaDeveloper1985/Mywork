package com.configprod.models;


public class ProductData {
	
	
private String productId;
private String productName;
private ProductConfig productConfig;

public String getProductId() {
	return productId;
}
public void setProductId(String productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public ProductConfig getProductConfig() {
	return productConfig;
}
public void setProductConfig(ProductConfig productConfig) {
	this.productConfig = productConfig;
}

}
