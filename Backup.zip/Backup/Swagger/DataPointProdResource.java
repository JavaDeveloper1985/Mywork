package com.swissre.prodcfg.ws.facade.rest;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Stateless
@LocalBean
@Path("/DataPointProducts")
@Api(value="Data Point Products")
public class DataPointProdResource {

	private static final Logger logger = Logger.getLogger(DataPointProdResource.class.getName());

	@EJB
	DataPointProdService datapointProdService;

	@POST
	//@Path("/DataPointProducts")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Add Data Point Products" )
	public Response addProductData(ProductData product) {
		logger.info("input data::" + product.toString());
		try {
			ProductData prod = datapointProdService.addProductData(product);
			logger.info("output data::" + product.toString());
			return Response.status(Status.CREATED).entity(prod).build();
		} catch (ConfigException ce) {
			logger.error("Error in adding data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while adding product", e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while adding product").build();
		}

	}

	/*@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/api/DataPointProducts")
	@ApiOperation(value="Get Data Point Products" )
	public Response getProductData() {
		logger.info("Get all data");
		try {
			List<ProductData> configData = datapointProdService.getDataPointProd();
			logger.info("output all data::" + configData);
			return Response.status(Status.OK).entity(configData).build();
		} catch (ConfigException ce) {
			logger.error("Error in finding all data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while finding all data point product details::", e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while finding all data point product details::")
					.build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/api/DataPointProducts/{id}")
	@ApiOperation(value="Get Data Point Products by id" )
	public Response getProductDataById(@ApiParam(value="product id") @PathParam("id") String id) {
		logger.info("input id:" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProductData pData = datapointProdService.getDataPointProdById(Long.parseLong(id));
				logger.info("output id:" + pData.toString());
				return Response.status(Status.OK).entity(pData).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in finding data point product details by ID", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while finding data point details by ID::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while finding data point details by ID::" + id)
					.build();
		}
	}*/
	
	@Path("/{id}")
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Update Data Point Products" )
	public Response updateProductData(@ApiParam(value="product id") @PathParam("id") String id, @ApiParam(value="ProductData")ProductData product) {
		logger.info("update data::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				product.setProductId(id);
				ProductData prod = datapointProdService.putProductData(product);
				logger.info("updated data::" + prod.toString());
				return Response.status(Status.OK).entity(prod).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in updating data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while updating data::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while updating data::" + id).build();
		}
	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	@ApiOperation(value="Delete Data Point Products" )
	public Response deleteProductData(@ApiParam(value="product id") @PathParam("id") String id) {
		logger.info("Delete by selected Id::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				datapointProdService.deleteProductData(Long.parseLong(id));
				return Response.status(Status.OK).entity(id).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in deleting data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while deleting product id::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while deleting product id::" + id).build();
		}

	}
}