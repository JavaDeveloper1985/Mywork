package com.swissre.prodcfg.ws.facade.rest;

import java.net.URI;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
//import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Stateless
@LocalBean
@Path("/")
@Api(value = "/", description = "Process Products")
public class AppResource {

	private static final Logger logger = Logger.getLogger(AppResource.class.getName());

	@EJB
	ProcessProdService ProcessProdService;

	@EJB
	DataPointProdService datapointProdService;

	private static final String LINK_SELF = "self";

	@Context
	UriInfo uriInfo;

	@POST
	@Path("/DataPointProducts")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Add Data Point Products")
	public Response addDataProductData(ProductData product) {
		logger.info("input data::" + product.toString());
		try {
			ProductData prod = datapointProdService.addProductData(product);
			Link link = buildSelfLink(uriInfo, prod);
			prod.addLink(link);
			logger.info("output data::" + new ObjectMapper().writeValueAsString(prod));
			return Response.status(Status.CREATED).entity(new ObjectMapper().writeValueAsString(prod)).build();
		} catch (ConfigException ce) {
			logger.error("Error in adding data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while adding product", e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while adding product").build();
		}

	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("DataPointProducts/{id}")
	@ApiOperation(value = "Update Data Point Products")
	public Response updateDataProductData(@ApiParam(value = "product id") @PathParam("id") String id,
			@ApiParam(value = "ProductData") ProductData product) {
		logger.info("update data::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				product.setProductId(id);
				ProductData prod = datapointProdService.putProductData(product);
				Link link = buildSelfLink(uriInfo, prod);
				prod.addLink(link);
				logger.info("updated data::" + new ObjectMapper().writeValueAsString(prod));
				return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(prod)).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in updating data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while updating data::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while updating data::" + id).build();
		}
	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/DataPointProducts/{id}")
	@ApiOperation(value = "Delete Data Point Products")
	public Response deleteDataProductData(@ApiParam(value = "product id") @PathParam("id") String id) {
		logger.info("Delete by selected Id::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				datapointProdService.deleteProductData(Long.parseLong(id));
				return Response.status(Status.OK).entity(id).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in deleting data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while deleting product id::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error occured while deleting product id::" + id).build();
		}

	}

	@POST
	@Path("/ProcessProducts")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Add Process Products")
	public Response addProductData(@ApiParam(value = "Prodcuts") ProductData product) {
		logger.info("input data::" + product.toString());
		try {
			ProductData prod = ProcessProdService.addProductData(product);
			Link link = buildSelfLink(uriInfo, prod);
			prod.addLink(link);
			logger.info("output data::" + new ObjectMapper().writeValueAsString(prod));
			return Response.status(Status.CREATED).entity(new ObjectMapper().writeValueAsString(prod)).build();
		} catch (ConfigException ce) {
			logger.error("Error in adding process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while adding process product details", e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while adding process product details").build();
		}

	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Update Process Products")
	@Path("/ProcessProducts/{id}")
	public Response updateProductData(@ApiParam(value = "product id") @PathParam("id") String id, ProductData product) {
		logger.info("update data::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				product.setProductId(id);
				ProductData prod = ProcessProdService.putProductData(product);
				Link link = buildSelfLink(uriInfo, prod);
				prod.addLink(link);
				logger.info("updated data::" + new ObjectMapper().writeValueAsString(prod));
				return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(prod)).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in updating process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while updating process product data by id::" + id, e);
			return Response.status(Status.BAD_REQUEST)
					.entity("Error in while updating process product data by id::" + id).build();
		}

	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Delete Process Products")
	@Path("/ProcessProducts/{id}")
	public Response deleteProductData(@ApiParam(value = "product id") @PathParam("id") String id) {
		logger.info("Delete by selected Id::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProcessProdService.deleteProductData(Long.parseLong(id));
				return Response.status(Status.OK).entity(id).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in deleting process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while deleting process product id::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while deleting process product id::" + id)
					.build();
		}

	}

	private Link buildSelfLink(UriInfo uriInfo, ProductData product) {
		URI uri = uriInfo.getBaseUriBuilder().path(ApiResource.class).path(product.getProductId()).build();
		Link link = Link.fromUri(uri).rel(LINK_SELF).build();
		return link;
	}
}
