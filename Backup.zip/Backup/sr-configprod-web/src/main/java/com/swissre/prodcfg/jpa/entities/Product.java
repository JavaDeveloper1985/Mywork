package com.swissre.prodcfg.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the TPRODUCT database table.
 * 
 */
@Entity
@Table(name = "TPRODUCT")
@NamedQueries({ @NamedQuery(name = "findproddetails", query = "select p from Product p where p.prodTypeCd = :pType"),
		@NamedQuery(name = "findproddetailsbyid", query = "select p from Product p where p.prodTypeCd = :pType and p.prodId = :pId"),
		@NamedQuery(name = "getprodcount", query = "select count(p) from Product p where p.prodTypeCd = :pType") })
		@NamedQuery(name = "deleteproduct", query = "delete from Product p where p.prodId = :pId and p.prodTypeCd = :pType")

public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TPRODUCT_PRODID_GENERATOR", sequenceName = "SEQ_PROD_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TPRODUCT_PRODID_GENERATOR")
	@Column(name = "PROD_ID")
	private long prodId;

	@Column(name = "PROD_NAME")
	private String prodName;

	@Column(name = "PROD_TYPE_CD")
	private String prodTypeCd;

	// bi-directional one-to-one association to ProductConfig
	@OneToOne(mappedBy = "product", cascade = CascadeType.ALL )
	private ProductConfig productConfig;

	public Product() {
	}

	public long getProdId() {
		return this.prodId;
	}

	public void setProdId(long prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return this.prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdTypeCd() {
		return this.prodTypeCd;
	}

	public void setProdTypeCd(String prodTypeCd) {
		this.prodTypeCd = prodTypeCd;
	}

	public ProductConfig getProductConfig() {
		return this.productConfig;
	}

	public void setProductConfig(ProductConfig productConfig) {
		this.productConfig = productConfig;
	}

}