package com.swissre.prodcfg.ws.facade.rest;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Stateless
@LocalBean
@Path("/DataPointProducts")
@Api(value = "Data Point Products")
public class DataPointProductResource {

	private static final Logger logger = Logger.getLogger(DataPointProductResource.class.getName());

	@EJB
	DataPointProdService datapointProdService;

	private static final String LINK_SELF = "self";
	@Context
	UriInfo uriInfo;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	// @Path("/DataPointProducts")
	@ApiOperation(value = "Get Data Point Products")
	public Response getProductData() {
		logger.info("Get all data");
		try {
			List<ProductData> configData = datapointProdService.getDataPointProd();
			List<ProductData> productData = new ArrayList<>();
			for (ProductData product : configData) {
				Link link = buildSelfLink(uriInfo, product);
				ProductData pd = new ProductData();
				pd.setProductId(product.getProductId());
				pd.setProductName(product.getProductName());
				pd.setProductConfig(product.getProductConfig());
				pd.addLink(link);
				productData.add(pd);
			}
			logger.info("output all data::" + new ObjectMapper().writeValueAsString(productData));
			return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(productData)).build();
		} catch (ConfigException ce) {
			logger.error("Error in finding all data point product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while finding all data point product details::", e);
			return Response.status(Status.BAD_REQUEST)
					.entity("Error occured while finding all data point product details::").build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	@ApiOperation(value = "Get Data Point Products by id")
	public Response getProductDataById(@ApiParam(value = "product id") @PathParam("id") String id) {
		logger.info("input id:" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProductData pData = datapointProdService.getDataPointProdById(Long.parseLong(id));
				Link link = buildSelfLink(uriInfo, pData);
				pData.addLink(link);
				logger.info("output id:" + new ObjectMapper().writeValueAsString(pData));
				return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(pData)).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in finding data point product details by ID", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error occured while finding data point details by ID::" + id, e);
			return Response.status(Status.BAD_REQUEST)
					.entity("Error occured while finding data point details by ID::" + id).build();
		}
	}

	private Link buildSelfLink(UriInfo uriInfo, ProductData product) {
		URI uri = uriInfo.getBaseUriBuilder().path(DataPointProductResource.class).path(product.getProductId()).build();
		Link link = Link.fromUri(uri).rel(LINK_SELF).build();
		return link;
	}

}