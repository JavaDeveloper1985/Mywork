package com.swissre.prodcfg.ws.facade.rest;

import static com.swissre.prodcfg.data.access.QueryParameter.with;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.jpa.entities.Product;
import com.swissre.prodcfg.jpa.entities.ProductConfig;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;
import com.swissre.prodcfg.utils.ProdConstants;

@Stateless
@LocalBean
public class DataPointProdService {
	private static final Logger logger = Logger.getLogger(DataPointProdService.class.getName());

	@EJB
	DataAccessService dataAccessService;

	public ProductData addProductData(ProductData product) throws ConfigException {
		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdName(product.getProductName());
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prod.setProdTypeCd(ProdConstants.DPROD_ID);
				prod.setProductConfig(prodcfg);
				prodcfg.setProduct(prod);

				prod = (Product) dataAccessService.create(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in addProductData at DataPointProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public List<ProductData> getDataPointProd() throws ConfigException {
		List<ProductData> configList = new ArrayList<ProductData>();
		try {
			List<Product> cnfList = dataAccessService.findWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS,
					with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID).parameters());

			for (Product cnf : cnfList) {
				ProductData config = new ProductData();
				config.setProductId(Long.toString(cnf.getProdId()));
				config.setProductName(cnf.getProdName());
				config.setProductConfig(getProductConfig(cnf.getProductConfig().getProdCfg()).get("productConfig"));
				configList.add(config);
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in getDataPointProd", e);
			throw new ConfigException(e.getMessage());
		}
		return configList;

	}

	public ProductData getDataPointProdById(long id) throws ConfigException {
		logger.info("get product by id:" + id);
		ProductData config = new ProductData();
		try {
			Product prod = dataAccessService.findSingleResultWithNamedQuery(Product.class,
					ProdConstants.PROD_DETAILS_BYID, with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID)
							.and(ProdConstants.PROD_ID, id).parameters());

			config.setProductId(Long.toString(prod.getProdId()));
			config.setProductName(prod.getProdName());
			config.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));
		} catch (ConfigException ce) {
			logger.error("Error in getDataPointProdById", ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in getDataPointProdById", e);
			throw new ConfigException(e.getMessage());

		}
		return config;

	}

	public ProductData putProductData(ProductData product) throws ConfigException {

		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdId(Long.parseLong(product.getProductId()));
				prod.setProdName(product.getProductName());
				prod.setProdTypeCd(ProdConstants.DPROD_ID);
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prodcfg.setProduct(prod);
				prod.setProductConfig(prodcfg);
				prod = (Product) dataAccessService.update(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in putProductData at DataPointProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public void deleteProductData(long id) {
		dataAccessService.delete(Product.class, id);
	}

	public Map<String, Object> getProductConfig(String cngxml) throws ConfigException {
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		logger.info("XML Config data ::" + cngxml);
		try {
			JSONObject jObject = XML.toJSONObject(cngxml);
			ObjectMapper mapper = new ObjectMapper();
			jsonInMap = mapper.readValue(jObject.toString(), new TypeReference<Map<String, Object>>() {

			});

		} catch (Exception e) {
			logger.error("Error while converting xml to map object", e);
			throw new ConfigException(e.getMessage());

		}
		return jsonInMap;
	}

}
