package com.swissre.prodcfg.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TPRODUCT_CONFIG database table.
 * 
 */
@Entity
@Table(name="TPRODUCT_CONFIG")
//@NamedQuery(name="ProductConfig.findAll", query="SELECT p FROM ProductConfig p")
public class ProductConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TPRODUCT_CONFIG_PRODCONFID_GENERATOR", sequenceName="SEQ_PROD_CONFIG_ID", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TPRODUCT_CONFIG_PRODCONFID_GENERATOR")
	@Column(name="PROD_CONF_ID")
	private long prodConfId;


	@Lob
	@Column(name="PROD_CFG")
	private String prodCfg;

	//bi-directional one-to-one association to Product
	@OneToOne(mappedBy="productConfig",cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Product product;

	public ProductConfig() {
	}

	public long getProdConfId() {
		return this.prodConfId;
	}

	public void setProdConfId(long prodConfId) {
		this.prodConfId = prodConfId;
	}



	public String getProdCfg() {
		return this.prodCfg;
	}

	public void setProdCfg(String prodCfg) {
		this.prodCfg = prodCfg;
	}

	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}