package com.swissre.prodcfg.ws.facade.rest;

import static com.swissre.prodcfg.data.access.QueryParameter.with;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.jpa.entities.Product;
import com.swissre.prodcfg.jpa.entities.ProductConfig;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ProdConstants;


@Stateless
@LocalBean
public class ProcessProdService {
	@EJB
	DataAccessService dataAccessService;

	public ProductData addProductData(ProductData product) {
		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		prod.setProdName("");
		prodcfg.setProdCfg(product.getProductConfig().toString());
		prod.setProdTypeCd(ProdConstants.PPROD_ID);
		prod.setProductConfig(prodcfg);
		prodcfg.setProduct(prod);
		prod = (Product) dataAccessService.create(prod);
		product.setProductId(Long.toString(prod.getProdId()));
		product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));
		return product;

	}
	
	public List<ProductData> getProcessProd() {

		List<Product> cnfList = dataAccessService.findWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS,
				with(ProdConstants.PROD_TYPE_CD, ProdConstants.PPROD_ID).parameters());
		List<ProductData> configList = new ArrayList<ProductData>();
		for (Product cnf : cnfList) {
			ProductData config = new ProductData();
			config.setProductId(Long.toString(cnf.getProdId()));
			config.setProductName(cnf.getProdName());
			config.setProductConfig(getProductConfig(cnf.getProductConfig().getProdCfg()));
			configList.add(config);
		}
		return configList;

	}
	
	public ProductData getProcessProdById(long id) {

		Product prod = dataAccessService.findSingleResultWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS_BYID,
				with(ProdConstants.PROD_TYPE_CD, ProdConstants.PPROD_ID).and(ProdConstants.PROD_ID, id).parameters());
		ProductData config = new ProductData();
		config.setProductId(Long.toString(prod.getProdId()));
		config.setProductName(prod.getProdName());
		config.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));

		return config;

	}
	
	public ProductData putProductData(ProductData product) {

		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		prod.setProdId(Long.parseLong(product.getProductId()));
		prod.setProdName("");
		prod.setProdTypeCd(ProdConstants.PPROD_ID);
		prodcfg.setProdCfg(product.getProductConfig().toString());
		prod.setProductConfig(prodcfg);
		prodcfg.setProduct(prod);
		prod = (Product) dataAccessService.update(prod);
		product.setProductId(Long.toString(prod.getProdId()));
		product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()).get("productConfig"));
		return product;

	}
	
	public void deleteProductData(long id) {
		dataAccessService.delete(Product.class, id);
	}
	

	public Map<String, Object> getProductConfig(String cngxml) {
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		try {

			XmlMapper xmlMapper = new XmlMapper();
			jsonInMap = xmlMapper.readValue(cngxml, new TypeReference<Map<String, Object>>() {

			});

		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonInMap;
	}

}