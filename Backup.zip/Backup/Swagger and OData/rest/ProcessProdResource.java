package com.swissre.prodcfg.ws.facade.rest;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;
import com.swissre.prodcfg.utils.ProductNotFoundException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Stateless
@LocalBean
@Path("/ProcessProducts")
@Api(value = "Process Products")
public class ProcessProdResource {

	private static final Logger logger = Logger.getLogger(ProcessProdResource.class.getName());
	@EJB
	ProcessProdService ProcessProdService;
	@Context
	UriInfo uriInfo;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Add Process Products")
	public Response addProductData(@ApiParam(value = "Prodcuts") ProductData product) {
		logger.info("input data::" + product.toString());
		try {
			ProductData prod = ProcessProdService.addProductData(product, uriInfo);
			logger.info("output data::" + new ObjectMapper().writeValueAsString(prod));
			return Response.status(Status.CREATED).entity(new ObjectMapper().writeValueAsString(prod)).build();
		} catch (ConfigException ce) {
			logger.error("Error in adding process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMessage()).build();
		} catch (Exception e) {
			logger.error("Error in while adding process product details", e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while adding process product details").build();
		}

	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Update Process Products")
	@Path("/{id}")
	public Response updateProductData(@ApiParam(value = "product id") @PathParam("id") String id, ProductData product) {
		logger.info("update data::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				product.setProductId(id);
				ProductData prod = ProcessProdService.putProductData(product, uriInfo);
				logger.info("updated data::" + new ObjectMapper().writeValueAsString(prod));
				return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(prod)).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in updating process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMessage()).build();
		} catch (Exception e) {
			logger.error("Error in while updating process product data by id::" + id, e);
			return Response.status(Status.BAD_REQUEST)
					.entity("Error in while updating process product data by id::" + id).build();
		}

	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Delete Process Products")
	@Path("/{id}")
	public Response deleteProductData(@ApiParam(value = "product id") @PathParam("id") String id) {
		logger.info("Delete by selected Id::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProcessProdService.deleteProductData(Long.parseLong(id));
				return Response.status(Status.OK).entity(id).build();
			}
		} catch (ProductNotFoundException e) {
			logger.warn("No product with id " + id + " found");
			return Response.status(Status.NOT_FOUND).entity(e.getMessage()).build();
		} catch (ConfigException ce) {
			logger.error("Error in deleting process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMessage()).build();
		} catch (Exception e) {
			logger.error("Error in while deleting process product id::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while deleting process product id::" + id)
					.build();
		}

	}

}
