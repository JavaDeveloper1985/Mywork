package com.swissre.prodcfg.ws.facade.rest;

import static com.swissre.prodcfg.data.access.QueryParameter.with;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.UriInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.jpa.entities.Product;
import com.swissre.prodcfg.jpa.entities.ProductConfig;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.models.ProductReposne;
import com.swissre.prodcfg.utils.ConfigException;
import com.swissre.prodcfg.utils.ProdConstants;
import com.swissre.prodcfg.utils.ProductNotFoundException;

@Stateless
@LocalBean
public class DataPointProdService {
	private static final Logger logger = Logger.getLogger(DataPointProdService.class.getName());

	private static final Integer DEFAULT_TOP = 50;

	private static final String DEFAULT_ORDERBY = "p.prodName";

	private static final String LINK_SELF = "self";

	@EJB
	DataAccessService dataAccessService;

	public ProductData addProductData(ProductData product, UriInfo uriInfo) throws ConfigException {
		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdName(product.getProductName());
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prod.setProdTypeCd(ProdConstants.DPROD_ID);
				prod.setProductConfig(prodcfg);
				prodcfg.setProduct(prod);
				prod = (Product) dataAccessService.create(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
				product.addLink(buildSelfLink(uriInfo, product));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in addProductData at DataPointProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public ProductReposne getDataPointProd(Integer top, Integer skip, String orderBy, UriInfo uriInfo, String cnt)
			throws ConfigException {
		ProductReposne pr = new ProductReposne();
		List<ProductData> configList = new ArrayList<ProductData>();
		boolean count = false;
		Integer stop = 0;
		try {
			if (top == null || top <= 0) {
				stop = DEFAULT_TOP;
			}else{
				stop = top;
			}
			if (skip == null) {
				skip = 0;
			}
			if (StringUtils.isBlank(orderBy)) {
				orderBy = DEFAULT_ORDERBY;
			}
			if (null != cnt) {
				count = Boolean.parseBoolean(cnt);
				if (null != top)
					stop = top;
			}
			if (count) {
				Long pcount = dataAccessService.findSingleResultWithNamedQuery(Long.class, ProdConstants.PROD_COUNT,
						with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID).parameters());
				pr.setCount(Long.toString(pcount.longValue()));
				if (stop > 0)
					stop = pcount.intValue();
				logger.info(" Count::: " + pcount);
			}
			if (stop != 0) {
				List<Product> cnfList = dataAccessService.findWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS,
						with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID).parameters(), stop, skip,orderBy);

				for (Product cnf : cnfList) {
					ProductData config = new ProductData();
					config.setProductId(Long.toString(cnf.getProdId()));
					config.setProductName(cnf.getProdName());
					config.setProductConfig(getProductConfig(cnf.getProductConfig().getProdCfg()));
					config.addLink(buildSelfLink(uriInfo, config));
					configList.add(config);
				}
				pr.setProducts(configList);
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in getDataPointProd", e);
			throw new ConfigException(e.getMessage());
		}
		return pr;

	}

	public ProductData getDataPointProdById(long id, UriInfo uriInfo) throws ConfigException {
		logger.info("get product by id:" + id);
		ProductData config = new ProductData();
		try {
			Product prod = dataAccessService.findSingleResultWithNamedQuery(Product.class,
					ProdConstants.PROD_DETAILS_BYID, with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID)
							.and(ProdConstants.PROD_ID, id).parameters());

			config.setProductId(Long.toString(prod.getProdId()));
			config.setProductName(prod.getProdName());
			config.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
			config.addLink(buildSelfLink(uriInfo, config));
		} catch (ConfigException ce) {
			logger.error("Error in getDataPointProdById", ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in getDataPointProdById", e);
			throw new ConfigException(e.getMessage());

		}
		return config;

	}

	public Long getDataPointProdCount() throws ConfigException {
		Long count = 0l;
		try {

			count = dataAccessService.findSingleResultWithNamedQuery(Long.class, ProdConstants.PROD_COUNT,
					with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID).parameters());
			logger.info(" Count" + count);

		} catch (ConfigException ce) {
			logger.error("Error in getDataPointProdCount", ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in getDataPointProdCount", e);
			throw new ConfigException(e.getMessage());

		}
		return count;
	}

	public ProductData putProductData(ProductData product, UriInfo uriInfo) throws ConfigException {

		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdId(Long.parseLong(product.getProductId()));
				prod.setProdName(product.getProductName());
				prod.setProdTypeCd(ProdConstants.DPROD_ID);
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prodcfg.setProduct(prod);
				prod.setProductConfig(prodcfg);
				prod = (Product) dataAccessService.update(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
				product.addLink(buildSelfLink(uriInfo, product));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in putProductData at DataPointProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public int deleteProductData(long id) {
		int deleteCount = dataAccessService.deleteWithNamedQuery(ProdConstants.PRODUCT_DELETE,
				with(ProdConstants.PROD_TYPE_CD, ProdConstants.DPROD_ID).and("productId", id).parameters());
		if (deleteCount <= 0) {
			throw new ProductNotFoundException("Data Point Product " + id + " not found");
		}
		return deleteCount;
	}

	public Map<String, Object> getProductConfig(String cngxml) throws ConfigException {
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		logger.info("XML Config data ::" + cngxml);
		try {
			JSONObject jObject = XML.toJSONObject(cngxml);
			ObjectMapper mapper = new ObjectMapper();
			jsonInMap = mapper.readValue(jObject.toString(), new TypeReference<Map<String, Object>>() {

			});

		} catch (Exception e) {
			logger.error("Error while converting xml to map object", e);
			throw new ConfigException(e.getMessage());

		}
		return jsonInMap;
	}

	private Link buildSelfLink(UriInfo uriInfo, ProductData product) {
		URI uri = uriInfo.getBaseUriBuilder().path(ProcessProductResource.class).path(product.getProductId()).build();
		Link link = Link.fromUri(uri).rel(LINK_SELF).build();
		return link;
	}

}
