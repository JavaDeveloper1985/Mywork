insert into tproduct_type values ('P', 'Process Product');
insert into tproduct_type values ('D', 'Data Point Product');
--insert into tproduct_type values ('A', 'Application-Specific Product');

