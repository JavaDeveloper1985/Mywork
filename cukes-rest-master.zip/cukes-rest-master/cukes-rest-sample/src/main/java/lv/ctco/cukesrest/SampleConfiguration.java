package lv.ctco.cukesrest;

import com.yammer.dropwizard.config.*;

public class SampleConfiguration extends Configuration {

}
