package lv.ctco.cukesrest.gadgets.dto;

public enum GadgetType {
    LAPTOP,
    SMARTPHONE,
    TABLET,
    SMART_WATCH,
    BOOK_READER
}
