package lv.ctco.cukesrest.internal.matchers;

import org.hamcrest.*;
import org.hamcrest.Matcher;

import java.util.regex.*;

public class EndsWithRegexp {

    public static Matcher<String> endsWithRegexp(final String regexp) {
        return new BaseMatcher<String>() {

            @Override
            public void describeTo(Description description) {
                description.appendText("matches pattern " + regexp);
            }

            @Override
            public boolean matches(Object item) {
                String value = (String) item;
                java.util.regex.Matcher matcher = Pattern.compile(".*" + regexp).matcher(value);

                return matcher.matches();
            }
        };
    }
}
