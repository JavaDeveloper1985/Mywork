package lv.ctco.cukesrest.loadrunner.function;

public interface LoadRunnerFunction {
    String format();
}
