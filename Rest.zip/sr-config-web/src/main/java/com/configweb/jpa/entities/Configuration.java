package com.configweb.jpa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CONFIG")
public class Configuration implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="CONFIG_ID")
	@SequenceGenerator(name = "MySequence", sequenceName = "config_seq", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MySequence")
	private long configId;

	@Lob
	@Column(name="CONFIG_DATA")
	private String configData;
	
	public long getConfigId() {
		return configId;
	}

	public void setConfigId(long configId) {
		this.configId = configId;
	}

	public String getConfigData() {
		return configData;
	}

	public void setConfigData(String configData) {
		this.configData = configData;
	}


}
