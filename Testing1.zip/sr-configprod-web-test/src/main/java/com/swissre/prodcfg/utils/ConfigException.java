package com.swissre.prodcfg.utils;

public class ConfigException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String errorCode;
	private String msg;

	public ConfigException(String detail) {
		this(detail, null);
	}

	public ConfigException(String detail, String errorCode) {
		super(detail);
		this.msg = detail;
		this.errorCode = errorCode;
	}

	public String getMsg() {
		return msg;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
