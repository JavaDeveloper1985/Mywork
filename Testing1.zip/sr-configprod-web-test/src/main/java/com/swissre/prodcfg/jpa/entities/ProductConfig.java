package com.swissre.prodcfg.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the TPRODUCT_CONFIG database table.
 * 
 */
@Entity
@Table(name = "TPRODUCT_CONFIG")
@NamedQuery(name = "ProductConfig.findAll", query = "SELECT p FROM ProductConfig p")
public class ProductConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Lob
	@Column(name = "PROD_CFG")
	private String prodCfg;

	// bi-directional one-to-one association to Product
	@Id
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PROD_ID")
	private Product product;

	public ProductConfig() {
	}

	/*
	 * public long getProdId() { return this.prodId; }
	 * 
	 * public void setProdId(long prodId) { this.prodId = prodId; }
	 */

	public String getProdCfg() {
		return this.prodCfg;
	}

	public void setProdCfg(String prodCfg) {
		this.prodCfg = prodCfg;
	}

	public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}