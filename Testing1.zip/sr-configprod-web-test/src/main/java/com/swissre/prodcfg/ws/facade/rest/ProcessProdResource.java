package com.swissre.prodcfg.ws.facade.rest;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;

@Stateless
@LocalBean
@Path("/")
public class ProcessProdResource {

	private static final Logger logger = Logger.getLogger(ProcessProdResource.class.getName());
	@EJB
	ProcessProdService ProcessProdService;

	@POST
	@Path("/app/ProcessProducts")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addProductData(ProductData product) {
		logger.info("input data::" + product.toString());
		try {
			ProductData prod = ProcessProdService.addProductData(product);
			logger.info("output data::" + product.toString());
			return Response.status(Status.CREATED).entity(prod).build();
		} catch (ConfigException ce) {
			logger.error("Error in adding process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while adding process product details", e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while adding process product details").build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/api/ProcessProducts")
	public Response getProductData() {
		logger.info("Get all data");
		try {
			List<ProductData> configData = ProcessProdService.getProcessProd();
			logger.info("output all data::" + configData);
			return Response.status(Status.OK).entity(configData).build();
		} catch (ConfigException ce) {
			logger.error("Error in finding all process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while finding all process product details::", e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while finding all process product details::")
					.build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/api/ProcessProducts/{id}")
	public Response getProductDataById(@PathParam("id") String id) {
		logger.info("input id:" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProductData pData = ProcessProdService.getProcessProdById(Long.parseLong(id));
				logger.info("output product data by id:" + pData.toString());
				return Response.status(Status.OK).entity(pData).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in finding process product details by ID", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while finding process details by ID::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while finding process details by ID::" + id)
					.build();
		}

	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/app/ProcessProducts/{id}")
	public Response updateProductData(@PathParam("id") String id, ProductData product) {
		logger.info("update data::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				product.setProductId(id);
				ProductData prod = ProcessProdService.putProductData(product);
				logger.info("updated data::" + prod.toString());
				return Response.status(Status.OK).entity(prod).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in updating process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while updating process product data by id::" + id, e);
			return Response.status(Status.BAD_REQUEST)
					.entity("Error in while updating process product data by id::" + id).build();
		}

	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/app/ProcessProducts/{id}")
	public Response deleteProductData(@PathParam("id") String id) {
		logger.info("Delete by selected Id::" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProcessProdService.deleteProductData(Long.parseLong(id));
				return Response.status(Status.OK).entity(id).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in deleting process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while deleting process product id::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while deleting process product id::" + id)
					.build();
		}

	}

}
