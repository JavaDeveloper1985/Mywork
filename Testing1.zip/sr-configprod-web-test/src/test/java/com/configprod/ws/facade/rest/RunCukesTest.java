package com.configprod.ws.facade.rest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty", "json:target/cucumber.json" }, features = {
		"classpath:features/configprod" }, glue = "lv.ctco.cukesrest.api", strict = true)
public class RunCukesTest {

}
