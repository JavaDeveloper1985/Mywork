package com.configprod.ws.facade.rest;

import org.junit.Test;

public class DataPointProdServiceTest {
	
	@Test
	public void testgetDataPointProd() {
		
		
	}



}
