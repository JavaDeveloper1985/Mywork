
package com.swissre.poc.screencontrol;
import java.util.HashMap;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.swissre.poc.test.WeldJUnit4Runner;

    @ApplicationScoped

    @RunWith(WeldJUnit4Runner.class)

    public class SAMPLE001ScreenControllerTest {
	@Inject
	private ScreenControllerService screenControllerService;
	@Test
    public void testRestrictScreen() {

    Map<String, Object> contextMap = new HashMap<String, Object>() {
	
    	private static final long serialVersionUID = 1L;

			{
				put("LOB", "PROPERTY");
			}
		      
		    };

		ScreenRestrictions restrictions = this.screenControllerService.restrictScreen("SAMPLE001", contextMap);
		//System.out.println("sample001=====>" + restrictions);

		Assert.assertEquals("Restriction command", ",~A,B,~C,!D,doIt", restrictions.toString());

		restrictions = this.screenControllerService.restrictScreen("SAMPLE002", contextMap);
		//System.out.println("sample002=====>" + restrictions);

		Assert.assertEquals("Restriction command", ",~A,B,~C,!D,doIt", restrictions.toString());
            }
            }
