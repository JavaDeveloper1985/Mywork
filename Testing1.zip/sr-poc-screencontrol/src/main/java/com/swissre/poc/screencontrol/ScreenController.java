package com.swissre.poc.screencontrol;

import java.util.Map;

/**
 * Created by S3PEDX on 10/27/2016.
 */
public interface ScreenController {
	String getScreenId();

	ScreenRestrictions restrictScreen(ScreenRestrictionBuilder restrictions, Map<String, Object> screenContext);
}