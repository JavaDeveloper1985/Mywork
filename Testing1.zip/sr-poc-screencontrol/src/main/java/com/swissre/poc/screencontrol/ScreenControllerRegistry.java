package com.swissre.poc.screencontrol;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 * A simple registry of {@code ScreenController}s.
 */
    @Singleton
    class ScreenControllerRegistry {
    @Inject @Any
    private Instance<ScreenController> screenControllers;
    private Map<String, ScreenController> screenControllerMap;

    @PostConstruct
    void init() {
        // Initialize the Map of controllers
    	this.screenControllerMap = new HashMap<String, ScreenController>();
 
    	
        for (ScreenController controller : this.screenControllers) {
        	//System.out.println("====1=== ::"+controller.getScreenId());
            this.screenControllerMap.put(controller.getScreenId(), controller);
        }
        }

    public ScreenController getScreenController(String screenId) {
    	//System.out.println("====>"+screenId);
        return this.screenControllerMap.get(screenId);
        }
        }
