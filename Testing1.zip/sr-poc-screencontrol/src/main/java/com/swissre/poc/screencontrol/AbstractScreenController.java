package com.swissre.poc.screencontrol;

/**
 * Created by S3PEDX on 10/31/2016.
 */
    public abstract class AbstractScreenController implements ScreenController {

    protected static final String CLASS_NAME_SUFFIX = "ScreenController";
    
     @Override
    public String getScreenId() {
        String className = getClass().getSimpleName();
        String screenId = null;
       
        if (className.endsWith(CLASS_NAME_SUFFIX)) {
           screenId = className.substring(0, className.indexOf(CLASS_NAME_SUFFIX));
        }

        return screenId;
        }
        }