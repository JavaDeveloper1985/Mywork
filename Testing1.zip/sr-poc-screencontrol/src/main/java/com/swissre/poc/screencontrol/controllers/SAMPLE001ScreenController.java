package com.swissre.poc.screencontrol.controllers;

import com.swissre.poc.screencontrol.AbstractScreenController;
import com.swissre.poc.screencontrol.ScreenRestrictionBuilder;
import com.swissre.poc.screencontrol.ScreenRestrictions;

import javax.enterprise.context.ApplicationScoped;
import java.util.Map;

/**
 * Sample screen controller for a screen with id 'SAMPLE001'.
 */
    @ApplicationScoped
    public class SAMPLE001ScreenController extends AbstractScreenController {
    	@Override
    public ScreenRestrictions restrictScreen(ScreenRestrictionBuilder restrictions, Map<String, Object> screenContext) {

   //System.out.println("==============>end============>"+screenContext.get("LOB"));
    return restrictions
                .enable("A")
                .disable("B")
                .enable("C",screenContext.get("LOB").equals("PROPERTY"))
                .require("D")
                .action("doIt")
                .build();
    }
    }
