package com.swissre.poc.screencontrol;

import java.util.Map;

public interface ScreenControllerService {
	ScreenRestrictions restrictScreen(String screenId, Map<String, Object> screenContext);
	
     }