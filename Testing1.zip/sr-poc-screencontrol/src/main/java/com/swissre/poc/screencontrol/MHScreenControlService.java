package com.swissre.poc.screencontrol;

import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.inject.Alternative;


/**
 * A service used to control the fields on a screen (e.g., read-only, editable, mandatory, etc.).
 */
   @Stateless
   @LocalBean
   @TransactionAttribute(TransactionAttributeType.REQUIRED)
   @Alternative
public class MHScreenControlService implements ScreenControllerService {
	
   
    /* (non-Javadoc)
	 * @see com.swissre.poc.screencontrol.ScreenControllerService#restrictScreen(java.lang.String, java.util.Map)
	 */
	public ScreenRestrictions restrictScreen(String screenId, Map<String, Object> screenContext) {
    	
    	//System.out.println("Inside "+this.getClass().getSimpleName()+" :restrictScreen Method");
    	
        //TODO: implementation for MHScreenControllerService - which is to be determined..
        return new ScreenRestrictionBuilder() 
        		
        		 .enable("A")
                 .disable("B")
                 .enable("C",screenContext.get("LOB").equals("PROPERTY"))
                 .require("D")
                 .action("doIt")
                 .build();
        }
        }
  
