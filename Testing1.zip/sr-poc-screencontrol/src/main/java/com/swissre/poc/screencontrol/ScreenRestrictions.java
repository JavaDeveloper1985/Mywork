package com.swissre.poc.screencontrol;

/**
 * Holds the restrictions for a screen.
 */
    public class ScreenRestrictions {
    final String restrictionCommand;

    public ScreenRestrictions(String restrictionCommand) {
        this.restrictionCommand = restrictionCommand;
        }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ScreenRestrictions that = (ScreenRestrictions) o;

        if (restrictionCommand != null ? restrictionCommand.equals(that.restrictionCommand) : that.restrictionCommand != null)
            return false;
     
        return true;
        }

    @Override
    public int hashCode() {
        return restrictionCommand != null ? restrictionCommand.hashCode() : 0;
        }
         
    @Override
    public String toString() {
        return this.restrictionCommand;
        }
        }
