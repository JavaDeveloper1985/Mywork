package com.swissre.poc.screencontrol;

/**
 * A "builder" class used to construct {@code ScreenRestrictions} objects using a fluent API.
 */
    public class ScreenRestrictionBuilder {

    private StringBuilder restrictionCommand = new StringBuilder();

    public ScreenRestrictions build() {
        return new ScreenRestrictions(restrictionCommand.toString());
    }

    public ScreenRestrictionBuilder enable(String field) {
        return enable(field, true);
    }

    public ScreenRestrictionBuilder disable(String field) {
        return enable(field, false);
    }

    public ScreenRestrictionBuilder enable(String field, boolean enableField) {
        // Enable:  ",~" + field
        // Disable: "," + field
        this.restrictionCommand.append(',');
        if (enableField) {
            this.restrictionCommand.append('~');
      }
        this.restrictionCommand.append(field);
        return this;
      }

    public ScreenRestrictionBuilder require(String field) {
        // Require:  ",!" + field
        this.restrictionCommand.append(",!").append(field);
        return this;
      }

    public ScreenRestrictionBuilder action(String action) {
        this.restrictionCommand.append(',').append(action);
        return this;
      }
      }
