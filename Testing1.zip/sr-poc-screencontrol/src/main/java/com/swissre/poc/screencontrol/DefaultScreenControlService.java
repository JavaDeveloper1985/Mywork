package com.swissre.poc.screencontrol;

import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;


/**
 * A service used to control the fields on a screen (e.g., read-only, editable, mandatory, etc.).
 */
   @Stateless
   @LocalBean
   @TransactionAttribute(TransactionAttributeType.REQUIRED)
public class DefaultScreenControlService implements ScreenControllerService {
	
   @Inject
   private ScreenControllerRegistry screenControllerRegistry;
   
    /* (non-Javadoc)
	 * @see com.swissre.poc.screencontrol.ScreenControllerService#restrictScreen(java.lang.String, java.util.Map)
	 */
    @Override
	public ScreenRestrictions restrictScreen(String screenId, Map<String, Object> screenContext) {
    	
    	//System.out.println("Inside "+this.getClass().getSimpleName()+" :restrictScreen Method");
    	
        ScreenRestrictions restrictions= null;
       
        ScreenController controller = screenControllerRegistry.getScreenController(screenId);
   
        if (controller != null) {
            ScreenRestrictionBuilder restrictionBuilder = new ScreenRestrictionBuilder();
            restrictions = controller.restrictScreen(restrictionBuilder, screenContext);
        }
        return restrictions;
        }
   }
        
