package com.swissre.man.proto.activiti;

import org.activiti.engine.IdentityService;
import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;
import org.activiti.engine.identity.UserQuery;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.activiti.spring.boot.ProcessEngineConfigurationConfigurer;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class ActivitiApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ActivitiApplication.class, args);
	}
	
	@Bean
	ProcessEngineConfigurationConfigurer processEngineConfigurationConfigurer() {
		return new ActivitiConfigurer();
	}
	
	@Bean
	InitializingBean usersAndGroupsInitializer(final SpringProcessEngineConfiguration config, final IdentityService identityService) {

	    return new InitializingBean() {
	        public void afterPropertiesSet() throws Exception {
	        	UserQuery userQuery = identityService.createUserQuery();
	        	User user = userQuery.userId("admin").singleResult();
	        	if (user == null) {
		            Group group = identityService.newGroup("user");
		            group.setName("users");
		            group.setType("security-role");
		            identityService.saveGroup(group);
	
		            User admin = identityService.newUser("admin");
		            admin.setPassword("admin");
		            identityService.saveUser(admin);
	        	}
	        }
	    };
	}
	
}
