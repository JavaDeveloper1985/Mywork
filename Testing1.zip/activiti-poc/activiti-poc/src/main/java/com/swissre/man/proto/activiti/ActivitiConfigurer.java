package com.swissre.man.proto.activiti;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

import org.activiti.spring.SpringProcessEngineConfiguration;
import org.activiti.spring.boot.ProcessEngineConfigurationConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

public class ActivitiConfigurer implements ProcessEngineConfigurationConfigurer {
	
	private static final String APP_PROPS_FILE				= "/application.properties";
	private static final String PROP_DATABASE_TABLE_PREFIX	= "spring.activiti.databaseTablePrefix";
	private static final String PROP_TABLE_PREFIX_IS_SCHEMA	= "spring.activiti.tablePrefixIsSchema";
	
	private Logger logger = Logger.getLogger(ActivitiConfigurer.class.getName());
	
	@Override
	public void configure(SpringProcessEngineConfiguration config) {
		try {
			Properties appProps = PropertiesLoaderUtils.loadProperties(new ClassPathResource(APP_PROPS_FILE));

			config.setDatabaseTablePrefix(appProps.getProperty(PROP_DATABASE_TABLE_PREFIX, ""));
			config.setTablePrefixIsSchema(
					Boolean.parseBoolean(appProps.getProperty(PROP_TABLE_PREFIX_IS_SCHEMA, "false")));
			
			logger.config("databaseTablePrefix: '" + config.getDatabaseTablePrefix() + "'");
			logger.config("tablePrefixIsSchema: " + config.isTablePrefixIsSchema());
		} catch (IOException e) {
			throw new RuntimeException("Error reading " + APP_PROPS_FILE, e);
		}
	}
}
