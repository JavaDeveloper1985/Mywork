/**
 * 
 */
package com.swissre.prodcfg.utils;

/**
 * Exception to indicate that a product was not found.
 */
public class ProductNotFoundException extends ConfigException {

	private static final long serialVersionUID = 1L;

	/**
	 * @param detail
	 */
	public ProductNotFoundException(String detail) {
		super(detail);
	}

	/**
	 * @param detail
	 * @param causedBy
	 */
	public ProductNotFoundException(String detail, Exception causedBy) {
		super(detail, causedBy);
	}

}
