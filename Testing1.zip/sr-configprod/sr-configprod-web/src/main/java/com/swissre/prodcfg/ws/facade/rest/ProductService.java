package com.swissre.prodcfg.ws.facade.rest;

import static com.swissre.prodcfg.data.access.QueryParameter.with;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.UriInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.jpa.entities.Product;
import com.swissre.prodcfg.jpa.entities.ProductConfig;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.models.ProductResponse;
import com.swissre.prodcfg.utils.ConfigException;
import com.swissre.prodcfg.utils.ProdConstants;
import com.swissre.prodcfg.utils.ProductNotFoundException;

@Stateless
@LocalBean
public class ProductService {
	private static final Logger logger = Logger.getLogger(ProductService.class.getName());

	private static final Integer DEFAULT_TOP = 50;

	private static final String DEFAULT_ORDERBY = "productName";

	private static final String LINK_SELF = "self";

	@EJB
	DataAccessService dataAccessService;

	public ProductData addProductData(ProductData product, UriInfo uriInfo, String prodType) throws ConfigException {
		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdName(product.getProductName());
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prod.setProdTypeCd(prodType);
				prod.setProductConfig(prodcfg);
				prodcfg.setProduct(prod);
				prod = (Product) dataAccessService.create(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg(), prodType));
				product.addLink(buildSelfLink(uriInfo, product, prodType));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in adding ProductData at ProductServices", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public ProductResponse getAllProducts(Integer top, Integer skip, String orderBy, UriInfo uriInfo, String cnt,
			String prodType, String pConfig) throws ConfigException {
		ProductResponse pr = new ProductResponse();
		List<ProductData> configList = new ArrayList<ProductData>();
		boolean count = false;
		boolean bconfig = true;
		Integer stop = 0;
		try {
			if (top == null || top <= 0) {
				stop = DEFAULT_TOP;
			} else {
				stop = top;
			}
			if (skip == null) {
				skip = 0;
			}
			if (StringUtils.isBlank(orderBy)) {
				orderBy = DEFAULT_ORDERBY;
			}
			if (null != cnt) {
				count = Boolean.parseBoolean(cnt);
				if (null != top)
					stop = top;
			}
			if(null !=pConfig){
				bconfig = Boolean.valueOf(pConfig);
			}
			if (count) {
				Long pcount = dataAccessService.findSingleResultWithNamedQuery(Long.class, ProdConstants.PROD_COUNT,
						with(ProdConstants.PROD_TYPE_CD, prodType.equals(ProdConstants.DPROD_ID)
								? ProdConstants.DPROD_ID : ProdConstants.PPROD_ID).parameters());
				pr.setCount(Long.toString(pcount.longValue()));
				if (stop > 0)
					stop = pcount.intValue();
				logger.info(" Count::: " + pcount);
			}
			if (stop != 0) {
				if (orderBy.contains(ProdConstants.PRODUCT_NAME)) {
					orderBy = orderBy.replace(ProdConstants.PRODUCT_NAME, ProdConstants.PRODUCT_NAME_ORDER);
				} else if (orderBy.contains(ProdConstants.PRODUCT_ID)) {
					orderBy = orderBy.replace(ProdConstants.PRODUCT_ID, ProdConstants.PRODUCT_ID_ORDER);
				}
				List<Product> cnfList = dataAccessService
						.findWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS,
								with(ProdConstants.PROD_TYPE_CD, prodType.equals(ProdConstants.DPROD_ID)
										? ProdConstants.DPROD_ID : ProdConstants.PPROD_ID).parameters(),
								stop, skip, orderBy);

				for (Product cnf : cnfList) {
					ProductData config = new ProductData();
					config.setProductId(Long.toString(cnf.getProdId()));
					config.setProductName(cnf.getProdName());
					if(bconfig){
					config.setProductConfig(getProductConfig(cnf.getProductConfig().getProdCfg(), prodType));
					}
					config.addLink(buildSelfLink(uriInfo, config, prodType));
					configList.add(config);
				}
				pr.setProducts(configList);
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in FindingAllProducts", e);
			throw new ConfigException(e.getMessage());
		}
		return pr;

	}

	public ProductData getProdById(long id, UriInfo uriInfo, String prodType) throws ConfigException {
		logger.info("get product by id:" + id);
		ProductData config = new ProductData();
		try {
			Product prod = dataAccessService
					.findSingleResultWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS_BYID,
							with(ProdConstants.PROD_TYPE_CD, prodType.equals(ProdConstants.DPROD_ID)
									? ProdConstants.DPROD_ID : ProdConstants.PPROD_ID).and(ProdConstants.PROD_ID, id)
											.parameters());

			config.setProductId(Long.toString(prod.getProdId()));
			config.setProductName(prod.getProdName());
			config.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg(), prodType));
			config.addLink(buildSelfLink(uriInfo, config, prodType));
		} catch (ConfigException ce) {
			logger.error("Error in get Product ById", ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in get Product ById", e);
			throw new ConfigException(e.getMessage());

		}
		return config;

	}

	public ProductData putProductData(ProductData product, UriInfo uriInfo, String prodType) throws ConfigException {

		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductName())
					|| StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product name/config details is empty");
			} else {
				prod.setProdId(Long.parseLong(product.getProductId()));
				prod.setProdName(product.getProductName());
				prod.setProdTypeCd(prodType);
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prodcfg.setProduct(prod);
				prod.setProductConfig(prodcfg);
				prod = (Product) dataAccessService.update(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg(), prodType));
				product.addLink(buildSelfLink(uriInfo, product, prodType));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMessage(), ce);
			throw new ConfigException(ce.getMessage());
		} catch (Exception e) {
			logger.error("Error in updatingProductData at ProductServices", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public int deleteProductData(long id, String prodType) {
		int deleteCount = dataAccessService.deleteWithNamedQuery(ProdConstants.PROD_DETAILS_BYID,
				with(ProdConstants.PROD_TYPE_CD,
						prodType.equals(ProdConstants.DPROD_ID) ? ProdConstants.DPROD_ID : ProdConstants.PPROD_ID)
								.and("pId", id).parameters());
		if (deleteCount <= 0) {
			throw new ProductNotFoundException("Product " + id + " not found");
		}
		return deleteCount;
	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> getProductConfig(String cngxml, String prodType) throws ConfigException {
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		logger.info("XML Config data ::" + cngxml);
		try {
			JSONObject jObject = XML.toJSONObject(cngxml);
			ObjectMapper mapper = new ObjectMapper();
			jsonInMap = mapper.readValue(jObject.toString(), new TypeReference<Map<String, Object>>() {

			});
				jsonInMap = (Map<String, Object>) jsonInMap.get("productConfig");
		} catch (Exception e) {
			logger.error("Error while converting xml to map object", e);
			throw new ConfigException(e.getMessage());

		}
		return jsonInMap;
	}

	private Link buildSelfLink(UriInfo uriInfo, ProductData product, String prodType) {
		URI uri = uriInfo.getBaseUriBuilder().path( prodType.equals(ProdConstants.DPROD_ID)
				? DataPointProductResource.class : ProcessProductResource.class).path(product.getProductId()).build();
		Link link = Link.fromUri(uri).rel(LINK_SELF).build();
		return link;
	}

}
