package com.swissre.prodcfg.utils;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.core.Link;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;;

public class LinksSerializer extends StdSerializer<List<Link>> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LinksSerializer() {
		super(List.class, true);
	}

	public LinksSerializer(Class<List<Link>> t) {
		super(t);
	}

	@Override
	public void serialize(List<Link> links, JsonGenerator jgen, SerializerProvider provider)
			throws IOException, JsonGenerationException {
		jgen.writeStartArray();
		for (Link link : links) {
			jgen.writeStartObject();
			jgen.writeStringField("rel", link.getRel());
			jgen.writeStringField("href", link.getUri().toString());
			// jgen.writeStringField("type", link.getType());
			jgen.writeEndObject();
		}
		jgen.writeEndArray();
	}
}
