package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TIB_PROGRAM database table.
 * 
 */
@Entity
@Table(name="TIB_PROGRAM")
@NamedQuery(name="TIBProgram.findAll", query="SELECT t FROM TIBProgram t")
public class TIBProgram implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TIB_PROGRAM_IBPROGRAMNO_GENERATOR", sequenceName="IB_PROGRAM_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TIB_PROGRAM_IBPROGRAMNO_GENERATOR")
	@Column(name="IB_PROGRAM_NO")
	private long ibProgramNo;

	@Column(name="BUSINESS_DESC")
	private String businessDesc;

	@Column(name="DEAL_NO")
	private BigDecimal dealNo;

	@Column(name="ENTERED_COSTING_FLAG")
	private String enteredCostingFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="IB_PROGRAM_CRT_DAT")
	private Date ibProgramCrtDat;

	@Temporal(TemporalType.DATE)
	@Column(name="IB_PROGRAM_EXPIRATION_DAT")
	private Date ibProgramExpirationDat;

	@Column(name="IB_PROGRAM_ID")
	private String ibProgramId;

	@Column(name="IB_PROGRAM_ID_FULL_NAM")
	private String ibProgramIdFullNam;

	@Column(name="IB_PROGRAM_ID_VERSION")
	private String ibProgramIdVersion;

	@Temporal(TemporalType.DATE)
	@Column(name="IB_PROGRAM_INCEPTION_DAT")
	private Date ibProgramInceptionDat;

	@Temporal(TemporalType.DATE)
	@Column(name="IB_PROGRAM_LST_MOD_DAT")
	private Date ibProgramLstModDat;

	@Column(name="IB_PROGRAM_NAME")
	private String ibProgramName;

	@Column(name="INDST_SEG_NO")
	private BigDecimal indstSegNo;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	@Column(name="LINE_OF_BUSINESS_NO")
	private BigDecimal lineOfBusinessNo;

	@Column(name="MARKET_POSITION_NO")
	private BigDecimal marketPositionNo;

	@Column(name="MASTER_BRKR_COMM_APPL_TO")
	private String masterBrkrCommApplTo;

	@Column(name="MASTER_BRKR_REF_NUM")
	private String masterBrkrRefNum;

	@Column(name="MSATER_BRKR_COMM_PRCNTG")
	private BigDecimal msaterBrkrCommPrcntg;

	@Column(name="PROGRAM_COUNTRY_NO")
	private BigDecimal programCountryNo;

	@Column(name="PROGRAM_CURRENCY_NO")
	private BigDecimal programCurrencyNo;

	@Column(name="PROGRAM_DISPOSITION_NO")
	private BigDecimal programDispositionNo;

	@Temporal(TemporalType.DATE)
	@Column(name="QUOTE_TARGET_DAT")
	private Date quoteTargetDat;

	@Temporal(TemporalType.DATE)
	@Column(name="RENEWAL_TRIGGER_DAT")
	private Date renewalTriggerDat;

	@Column(name="RENEWAL_TRIGGER_DAYS")
	private BigDecimal renewalTriggerDays;

	private BigDecimal rowversion;

	@Column(name="SUM_INSURED")
	private BigDecimal sumInsured;

	@Column(name="TOTAL_PROGRAM_PREMIUM")
	private BigDecimal totalProgramPremium;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	public TIBProgram() {
	}

	public long getIbProgramNo() {
		return this.ibProgramNo;
	}

	public void setIbProgramNo(long ibProgramNo) {
		this.ibProgramNo = ibProgramNo;
	}

	public String getBusinessDesc() {
		return this.businessDesc;
	}

	public void setBusinessDesc(String businessDesc) {
		this.businessDesc = businessDesc;
	}

	public BigDecimal getDealNo() {
		return this.dealNo;
	}

	public void setDealNo(BigDecimal dealNo) {
		this.dealNo = dealNo;
	}

	public String getEnteredCostingFlag() {
		return this.enteredCostingFlag;
	}

	public void setEnteredCostingFlag(String enteredCostingFlag) {
		this.enteredCostingFlag = enteredCostingFlag;
	}

	public Date getIbProgramCrtDat() {
		return this.ibProgramCrtDat;
	}

	public void setIbProgramCrtDat(Date ibProgramCrtDat) {
		this.ibProgramCrtDat = ibProgramCrtDat;
	}

	public Date getIbProgramExpirationDat() {
		return this.ibProgramExpirationDat;
	}

	public void setIbProgramExpirationDat(Date ibProgramExpirationDat) {
		this.ibProgramExpirationDat = ibProgramExpirationDat;
	}

	public String getIbProgramId() {
		return this.ibProgramId;
	}

	public void setIbProgramId(String ibProgramId) {
		this.ibProgramId = ibProgramId;
	}

	public String getIbProgramIdFullNam() {
		return this.ibProgramIdFullNam;
	}

	public void setIbProgramIdFullNam(String ibProgramIdFullNam) {
		this.ibProgramIdFullNam = ibProgramIdFullNam;
	}

	public String getIbProgramIdVersion() {
		return this.ibProgramIdVersion;
	}

	public void setIbProgramIdVersion(String ibProgramIdVersion) {
		this.ibProgramIdVersion = ibProgramIdVersion;
	}

	public Date getIbProgramInceptionDat() {
		return this.ibProgramInceptionDat;
	}

	public void setIbProgramInceptionDat(Date ibProgramInceptionDat) {
		this.ibProgramInceptionDat = ibProgramInceptionDat;
	}

	public Date getIbProgramLstModDat() {
		return this.ibProgramLstModDat;
	}

	public void setIbProgramLstModDat(Date ibProgramLstModDat) {
		this.ibProgramLstModDat = ibProgramLstModDat;
	}

	public String getIbProgramName() {
		return this.ibProgramName;
	}

	public void setIbProgramName(String ibProgramName) {
		this.ibProgramName = ibProgramName;
	}

	public BigDecimal getIndstSegNo() {
		return this.indstSegNo;
	}

	public void setIndstSegNo(BigDecimal indstSegNo) {
		this.indstSegNo = indstSegNo;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public BigDecimal getLineOfBusinessNo() {
		return this.lineOfBusinessNo;
	}

	public void setLineOfBusinessNo(BigDecimal lineOfBusinessNo) {
		this.lineOfBusinessNo = lineOfBusinessNo;
	}

	public BigDecimal getMarketPositionNo() {
		return this.marketPositionNo;
	}

	public void setMarketPositionNo(BigDecimal marketPositionNo) {
		this.marketPositionNo = marketPositionNo;
	}

	public String getMasterBrkrCommApplTo() {
		return this.masterBrkrCommApplTo;
	}

	public void setMasterBrkrCommApplTo(String masterBrkrCommApplTo) {
		this.masterBrkrCommApplTo = masterBrkrCommApplTo;
	}

	public String getMasterBrkrRefNum() {
		return this.masterBrkrRefNum;
	}

	public void setMasterBrkrRefNum(String masterBrkrRefNum) {
		this.masterBrkrRefNum = masterBrkrRefNum;
	}

	public BigDecimal getMsaterBrkrCommPrcntg() {
		return this.msaterBrkrCommPrcntg;
	}

	public void setMsaterBrkrCommPrcntg(BigDecimal msaterBrkrCommPrcntg) {
		this.msaterBrkrCommPrcntg = msaterBrkrCommPrcntg;
	}

	public BigDecimal getProgramCountryNo() {
		return this.programCountryNo;
	}

	public void setProgramCountryNo(BigDecimal programCountryNo) {
		this.programCountryNo = programCountryNo;
	}

	public BigDecimal getProgramCurrencyNo() {
		return this.programCurrencyNo;
	}

	public void setProgramCurrencyNo(BigDecimal programCurrencyNo) {
		this.programCurrencyNo = programCurrencyNo;
	}

	public BigDecimal getProgramDispositionNo() {
		return this.programDispositionNo;
	}

	public void setProgramDispositionNo(BigDecimal programDispositionNo) {
		this.programDispositionNo = programDispositionNo;
	}

	public Date getQuoteTargetDat() {
		return this.quoteTargetDat;
	}

	public void setQuoteTargetDat(Date quoteTargetDat) {
		this.quoteTargetDat = quoteTargetDat;
	}

	public Date getRenewalTriggerDat() {
		return this.renewalTriggerDat;
	}

	public void setRenewalTriggerDat(Date renewalTriggerDat) {
		this.renewalTriggerDat = renewalTriggerDat;
	}

	public BigDecimal getRenewalTriggerDays() {
		return this.renewalTriggerDays;
	}

	public void setRenewalTriggerDays(BigDecimal renewalTriggerDays) {
		this.renewalTriggerDays = renewalTriggerDays;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public BigDecimal getSumInsured() {
		return this.sumInsured;
	}

	public void setSumInsured(BigDecimal sumInsured) {
		this.sumInsured = sumInsured;
	}

	public BigDecimal getTotalProgramPremium() {
		return this.totalProgramPremium;
	}

	public void setTotalProgramPremium(BigDecimal totalProgramPremium) {
		this.totalProgramPremium = totalProgramPremium;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

}