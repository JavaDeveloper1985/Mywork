package com.swissre.ipa.exception;

public class IPAException extends Exception{
    
	public IPAException(String message){
		super(message);
	}
	public IPAException(String message, Throwable cause) {
        super(message, cause);
    }
}
