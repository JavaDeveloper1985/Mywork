package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TPARTNER_ROLE database table.
 * 
 */
@Entity
@Table(name="TPARTNER_ROLE")
@NamedQuery(name="TpartnerRole.findAll", query="SELECT t FROM TpartnerRole t")
public class TpartnerRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TPARTNER_ROLE_PARTNERROLENO_GENERATOR", sequenceName="PARTNER_ROLE_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TPARTNER_ROLE_PARTNERROLENO_GENERATOR")
	@Column(name="PARTNER_ROLE_NO")
	private long partnerRoleNo;

	@Column(name="ACTIVE_FLAG")
	private String activeFlag;

	@Column(name="CONTRACT_NO")
	private BigDecimal contractNo;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	@Column(name="PARTNER_ROLE_NAME")
	private String partnerRoleName;

	private BigDecimal rowversion;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	//bi-directional many-to-one association to Tpartner
	@ManyToOne
	@JoinColumn(name="PARTNER_NO")
	private Tpartner tpartner;

	public TpartnerRole() {
	}

	public long getPartnerRoleNo() {
		return this.partnerRoleNo;
	}

	public void setPartnerRoleNo(long partnerRoleNo) {
		this.partnerRoleNo = partnerRoleNo;
	}

	public String getActiveFlag() {
		return this.activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public BigDecimal getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(BigDecimal contractNo) {
		this.contractNo = contractNo;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public String getPartnerRoleName() {
		return this.partnerRoleName;
	}

	public void setPartnerRoleName(String partnerRoleName) {
		this.partnerRoleName = partnerRoleName;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

	public Tpartner getTpartner() {
		return this.tpartner;
	}

	public void setTpartner(Tpartner tpartner) {
		this.tpartner = tpartner;
	}

}