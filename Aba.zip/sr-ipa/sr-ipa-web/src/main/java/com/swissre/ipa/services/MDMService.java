package com.swissre.ipa.services;

import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;

import org.apache.commons.lang3.StringUtils;

import com.swissre.cmd.data.access.DataAccessService;
import com.swissre.cmd.util.AppException;
import com.swissre.ipa.integration.mdm.RestUtil;
import com.swissre.ipa.util.ServiceConstants;

@Stateless
@LocalBean
public class MDMService {
	
	private static final Logger LOGGER = Logger.getLogger(MDMService.class.getName());
	@EJB
	DataAccessService dataAccessService;
		
	public String getCarriers(String searchQuery,boolean codeSearchOnly, String env, String option1) {
		String list = null;		
		String mdmURL = "";
		if(codeSearchOnly){
			mdmURL = getBaseMDMURL(env, ServiceConstants.CATEGORY_LEGALENTITIES) + "?$filter=Id eq " +"'" + searchQuery + "'";
			if(StringUtils.isNotBlank(option1)){
				mdmURL = mdmURL + " and countryOfRegName like "+ "'" + option1 + "'";
			}
		} else {
			if(StringUtils.isNotBlank(option1)){
				mdmURL = getBaseMDMURL(env, ServiceConstants.CATEGORY_LEGALENTITIES) + "?$filter=countryOfRegName like "+ "'" + option1 + "'";
				if(StringUtils.isNotBlank(searchQuery) && !searchQuery.equals("***")){
					mdmURL = mdmURL + " and Name like '" + searchQuery +"'";
				}
			} else {
				mdmURL = getBaseMDMURL(env, ServiceConstants.CATEGORY_LEGALENTITIES);
				if(StringUtils.isNotBlank(searchQuery) && !searchQuery.equals("***")){
					mdmURL = mdmURL + "?$filter=Name like '" + searchQuery +"'";
				}
			}
		}
		list = fetchDataFromRestServices(removeSpecialCharacters(mdmURL));
		LOGGER.info("carriersList url-" + mdmURL);
		LOGGER.info("carriersList-" + list);
		JsonArrayBuilder  jsonArraybuilder =  Json.createArrayBuilder();
		if(list != null){				
			JsonReader jsonReader = Json.createReader(new StringReader(list));
			JsonObject object = jsonReader.readObject();
			jsonReader.close();
			JsonArray carriers = object.getJsonArray("legalEntities");
			for (int i = 0; i < carriers.size(); i++) {
			    JsonObject obj = carriers.getJsonObject(i);
			    JsonObjectBuilder jsonObjBuilder = Json.createObjectBuilder();
	    		jsonObjBuilder.add("code", obj.getString("entityId"));//srLegalEntitySdlType
	    		jsonObjBuilder.add("desc", obj.getString("entityLegalName"));
	    		jsonArraybuilder.add(jsonObjBuilder);	
			}
		}
		JsonArray array = jsonArraybuilder.build();
		return array.toString();
	}	
	
	public String getInsured(String searchQuery, boolean codeSearchOnly, String env){
		JsonArray jsonArray;
		if(codeSearchOnly) {
			StringBuilder mdmUrlId = new StringBuilder();
			mdmUrlId = mdmUrlId.append(getBaseMDMURL(env, ServiceConstants.CATEGORY_CLIENTS)).append("?$filter=Id eq ").append("'").append(searchQuery).append("'");
			String insuredList = fetchDataFromRestServices(removeSpecialCharacters(mdmUrlId.toString()));
			LOGGER.info("insuredList for codeSearchOnly: "+insuredList);			
			jsonArray = prepareMDMJsonArray(codeSearchOnly, insuredList, searchQuery);
			if(jsonArray.size() <= 0){
				String corPartUrl = getBaseCorpartURL(env) + searchQuery;
				String corpartInsuredList = fetchDataFromRestServices(corPartUrl);
				LOGGER.info("corpartInsuredList: "+corpartInsuredList);
				jsonArray = prepareCorpartJsonArray(corpartInsuredList);
			}			
		} else {
			StringBuilder mdmUrl = new StringBuilder();
			mdmUrl = mdmUrl.append(getBaseMDMURL(env, ServiceConstants.CATEGORY_CLIENTS)).append("?$search=").append(searchQuery).append("&").append("$top=50");
			LOGGER.info("mdmUrl: "+mdmUrl);
			String insuredList = fetchDataFromRestServices(removeSpecialCharacters(mdmUrl.toString()));
			LOGGER.info("insuredList: "+insuredList);
			jsonArray = prepareMDMJsonArray(codeSearchOnly, insuredList, searchQuery);
		}		
		return jsonArray.toString();
	}
	
	private String fetchDataFromRestServices(String url){
		String restResponse = "";
		try {
			RestUtil util = new RestUtil();
			restResponse = util.execute(url);
		} catch (AppException ex) {			
			LOGGER.log(Level.SEVERE, ex.getMessage());
			throw new AppException(ex.getMessage(), ex.getCause());
		}
		return restResponse;
	}
	
	private JsonArray prepareMDMJsonArray(boolean codeSearchOnly, String insuredList, String searchQuery){
		JsonArrayBuilder  jsonArraybuilder =  Json.createArrayBuilder();
		JsonReader jsonReader = Json.createReader(new StringReader(insuredList));
		JsonObject object = jsonReader.readObject();
		jsonReader.close();
		JsonArray insuredArray = object.getJsonArray("clients");
		for (int i = 0; i < insuredArray.size(); i++) {
			JsonObject obj = insuredArray.getJsonObject(i);
			JsonObjectBuilder jsonObjBuilder = Json.createObjectBuilder();
		    if(codeSearchOnly){		    	
		    	if (Integer.toString(obj.getInt("id")).equals(searchQuery))
			    {		    		
		    		LOGGER.info("codeSearchOnly: ");
		    		jsonObjBuilder.add("code", obj.getInt("id"));
		    		jsonObjBuilder.add("desc", obj.getString("name"));
		    		jsonArraybuilder.add(jsonObjBuilder);
			    }
		    } else {
		    	if (obj.getString("name").toLowerCase().contains(searchQuery.toLowerCase()))
			    {
		    		LOGGER.info("not codeSearchOnly: ");
		    		jsonObjBuilder.add("code", obj.getInt("id"));
		    		jsonObjBuilder.add("desc", obj.getString("name"));
		    		jsonArraybuilder.add(jsonObjBuilder);	
			    }
		    }	   					    
		}
		JsonArray array = jsonArraybuilder.build();
		return array;
	}
	
	private JsonArray prepareCorpartJsonArray(String insuredList){
		JsonArrayBuilder  jsonArraybuilder =  Json.createArrayBuilder();
		JsonReader jsonReader = Json.createReader(new StringReader(insuredList));
	    JsonObject corpartObj = jsonReader.readObject();
	    jsonReader.close();
		JsonObjectBuilder responseObj = Json.createObjectBuilder();
		responseObj.add("code", corpartObj.getInt("corpartId"));
		responseObj.add("desc", corpartObj.getString("insuredName"));
		jsonArraybuilder.add(responseObj);
		JsonArray array = jsonArraybuilder.build();
		return array;
	}
	
	private String removeSpecialCharacters(String url){
		String urlString = url;
		urlString = urlString.replaceAll(" ", "%20");
		urlString = urlString.replaceAll("'", "%27");
		return urlString;
	}
	
	private String getBaseMDMURL(String envName, String categoryName) {
		String baseMDMURL = ""; 
		if(envName.equalsIgnoreCase(ServiceConstants.IPA_ENV_DEV)){
			baseMDMURL = "http://web-dev.swissre.com/webapp/mds/rest/" + categoryName;
		} else if(envName.equalsIgnoreCase(ServiceConstants.IPA_ENV_TRAIN)) {
			baseMDMURL = "http://web-ite.swissre.com/webapp/mds/rest/" + categoryName;
		} else {
			baseMDMURL = "http://web.swissre.com/webapp/mds/rest/" + categoryName;
		}
		return baseMDMURL;
	}
	
	private String getBaseCorpartURL(String envName){
		String baseCorpartURL = "";
		if(envName.equalsIgnoreCase(ServiceConstants.IPA_ENV_DEV)){
			baseCorpartURL = "https://web-dev.swissre.com/webapp/csq/rest/AddInsuredService/getAddInsured/";
		} else if(envName.equalsIgnoreCase(ServiceConstants.IPA_ENV_TRAIN)) {
			baseCorpartURL = "https://web-ite.swissre.com/webapp/csq/rest/AddInsuredService/getAddInsured/";
		} else {
			baseCorpartURL = "https://web.swissre.com/webapp/csq/rest/AddInsuredService/getAddInsured/";
		}
		return baseCorpartURL;
	}
}
