package com.swissre.ipa.rest.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;

import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.swissre.cmd.interceptors.AppService;
import com.swissre.ipa.rest.AppRestURIs;
import com.swissre.ipa.services.ProgramService;

@Stateless
@LocalBean
@AppService
@RolesAllowed({"AuthenticatedUser","AppUser","AppUpdateUser"})
@Path(AppRestURIs.EMPLOYEES)
public class EmployeeResource {
	
	@EJB
	ProgramService programService;
	
	@POST	
	@Consumes({APPLICATION_JSON})
	@Path("/{employeeFName}/{empRole}/{programNo}")
	public Response createNewEmployeeEntry(@PathParam("employeeFName") String employeeFName,
			@PathParam("empRole") String empRole,
			@PathParam("programNo") String programNo)
	{
		if(employeeFName == null || employeeFName.trim().length() == 0) {
			return Response.serverError().entity("Employee First Name cannot be blank").build();
		}
		if(empRole == null || empRole.trim().length() == 0) {
			return Response.serverError().entity("Employee Role Name cannot be blank").build();
		}
		if(programNo == null || programNo.trim().length() == 0) {
			return Response.serverError().entity("Program No cannot be blank").build();
		}
		Long empNo = programService.saveEmpDetails(employeeFName,empRole,programNo);
		return Response.created(URI.create(AppRestURIs.EMPLOYEES+"/"+empNo)).entity(empNo).build();
	}
	
}
