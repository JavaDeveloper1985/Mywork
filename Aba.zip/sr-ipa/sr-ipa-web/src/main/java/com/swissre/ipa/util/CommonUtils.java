package com.swissre.ipa.util;

import java.text.SimpleDateFormat;
import java.util.Date;



public class CommonUtils {

	public static String formatToStringDate(Date date, String inputFormat) {
		StringBuilder convertedDate = null;
		if (date != null) {
			convertedDate = new StringBuilder(
					new SimpleDateFormat(inputFormat).format(date));
			return convertedDate.toString();
		}
		return "";
	}
	
	public static String removeSpecialCharacters(String fName)
	{
		String fileName = fName;
		fileName = fileName.replaceAll(" ", "");
		fileName = fileName.replaceAll("[^a-zA-Z0-9.-]", "_");
		return fileName;
	}
	
}
