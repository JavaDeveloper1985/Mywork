package com.swissre.ipa.integration.edms.mapper;


import java.util.Date;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import com.swissre.ipa.entity.model.VEDMSPolicyAttr;
import com.swissre.ipa.services.wsclient.upload.SingleValsType;
import com.swissre.ipa.util.AppUtils;

import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.impl.ConfigurableMapper;
import ma.glasnost.orika.metadata.ClassMap;

public class DocumentSingleValueMapper extends ConfigurableMapper {

	public static final String EDMS_DATE_FORMAT = "yyyy-MM-dd";
	public static final String EDMS_INDUCTION_DATE_FORMAT = "yyyy-MM-dd-HH.mm.ss.SSS";
	
	public void configure(MapperFactory mapperFactory) {
		
		ClassMap<VEDMSPolicyAttr, SingleValsType> classMap = mapperFactory
				.classMap(VEDMSPolicyAttr.class, SingleValsType.class)
				.field("bussFuncCd", "bussFuncCd")
				.byDefault()
				.customize(
						new CustomMapper<VEDMSPolicyAttr, SingleValsType>() {
							@Override
							public void mapAtoB(VEDMSPolicyAttr policyAttr, SingleValsType singleVals,
									MappingContext context) {
								singleVals.setSrInsuredNames(new JAXBElement<String>(new QName("", "sr_insured_names"),
										String.class, SingleValsType.class, policyAttr.getInsuredName()));
								singleVals.setSrInductionDate(
										AppUtils.covertDateToString(new Date(), EDMS_INDUCTION_DATE_FORMAT));
								singleVals.setSrTtyEffDt(new JAXBElement<String>(new QName("", "sr_tty_eff_dt"),
										String.class, SingleValsType.class,
										AppUtils.covertDateToString(policyAttr.getProgramInsDate(), EDMS_DATE_FORMAT)));
								if (policyAttr.getExpirationDat() != null) {
									singleVals.setSrExpirationDate(
											new JAXBElement<String>(new QName("", "sr_expiration_date"), String.class,
													SingleValsType.class, AppUtils.covertDateToString(
															policyAttr.getExpirationDat(), EDMS_DATE_FORMAT)));
								}
							}
						}).toClassMap();

		mapperFactory.registerClassMap(classMap);
	}
}
