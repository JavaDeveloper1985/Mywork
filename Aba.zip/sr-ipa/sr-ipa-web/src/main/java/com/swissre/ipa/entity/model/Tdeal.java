package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TDEAL database table.
 * 
 */
@Entity
@NamedQuery(name="Tdeal.findAll", query="SELECT t FROM Tdeal t")
public class Tdeal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDEAL_DEALNO_GENERATOR", sequenceName="DEAL_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDEAL_DEALNO_GENERATOR")
	@Column(name="DEAL_NO")
	private long dealNo;

	@Column(name="DEAL_ID")
	private String dealId;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	private BigDecimal rowversion;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	public Tdeal() {
	}

	public long getDealNo() {
		return this.dealNo;
	}

	public void setDealNo(long dealNo) {
		this.dealNo = dealNo;
	}

	public String getDealId() {
		return this.dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

}