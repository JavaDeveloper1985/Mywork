package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the V_POLICY_BUS_ATTR_EDMS database table.
 * 
 */
@Entity
@Table(name="V_POLICY_BUS_ATTR_EDMS")
@NamedQuery(name="VEDMSPolicyAttr.findAll", query="SELECT v FROM VEDMSPolicyAttr v")
public class VEDMSPolicyAttr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="BUS_AREA_CD")
	private String bussAreaCd;

	@Column(name="BUS_FUNCTION_CD")
	private String bussFuncCd;

	@Column(name="CARRIER_ID")
	private String legalEntityId;

	@Column(name="CARRIER_NAME")
	private String legalEntityName;

	@Column(name="CONTRACT_NO")
	private BigDecimal contractNo;

	@Column(name="DOC_CATEGORY")
	private String docCategory;

	@Column(name="DOC_TYPE")
	private String documentType;

	@Id
	@Column(name="DOCUMENT_TRACKER_NO")
	private BigDecimal documentTrackerNo;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRATION_DAT")
	private Date expirationDat;

	@Temporal(TemporalType.DATE)
	@Column(name="INCEPTION_DAT")
	private Date inceptionDat;

	@Column(name="INDUCTION_APP")
	private String srInductionApplication;

	@Column(name="INDUCTION_LOC")
	private String srInductionLocation;

	@Column(name="INSURED_ID")
	private String insuredId;

	@Column(name="INSURED_NAME")
	private String insuredName;

	@Column(name="LOB_NAME")
	private String LineOfBusiness;

	@Column(name="LOB_NO")
	private BigDecimal lobNo;

	@Column(name="POLICY_COUNTRY_CODE")
	private String programCountry;

	@Column(name="POLICY_IND")
	private String masterPolicyInd;

	@Column(name="POLICY_NO")
	private String policyNumber;

	@Column(name="PROGRAM_COUNTRY_CODE")
	private String countryOfLegalEntity;

	@Column(name="PROGRAM_ID")
	private String programUid;

	@Temporal(TemporalType.DATE)
	@Column(name="PROGRAM_INS_DATE")
	private Date programInsDate;

	@Column(name="PROGRAM_NAME")
	private String programName;

	@Column(name="PROGRAM_NO")
	private BigDecimal programNo;

	@Column(name="SRC_SYSTEM_CD")
	private String SourceSystemCd;

	public VEDMSPolicyAttr() {
	}

	public String getBussAreaCd() {
		return this.bussAreaCd;
	}

	public void setBussAreaCd(String bussAreaCd) {
		this.bussAreaCd = bussAreaCd;
	}

	public String getBussFuncCd() {
		return this.bussFuncCd;
	}

	public void setBussFuncCd(String bussFuncCd) {
		this.bussFuncCd = bussFuncCd;
	}

	public String getLegalEntityId() {
		return this.legalEntityId;
	}

	public void setLegalEntityId(String legalEntityId) {
		this.legalEntityId = legalEntityId;
	}

	public String getLegalEntityName() {
		return this.legalEntityName;
	}

	public void setLegalEntityName(String legalEntityName) {
		this.legalEntityName = legalEntityName;
	}

	public BigDecimal getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(BigDecimal contractNo) {
		this.contractNo = contractNo;
	}

	public String getDocCategory() {
		return this.docCategory;
	}

	public void setDocCategory(String docCategory) {
		this.docCategory = docCategory;
	}

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public BigDecimal getDocumentTrackerNo() {
		return this.documentTrackerNo;
	}

	public void setDocumentTrackerNo(BigDecimal documentTrackerNo) {
		this.documentTrackerNo = documentTrackerNo;
	}

	public Date getExpirationDat() {
		return this.expirationDat;
	}

	public void setExpirationDat(Date expirationDat) {
		this.expirationDat = expirationDat;
	}

	public Date getInceptionDat() {
		return this.inceptionDat;
	}

	public void setInceptionDat(Date inceptionDat) {
		this.inceptionDat = inceptionDat;
	}

	public String getSrInductionApplication() {
		return this.srInductionApplication;
	}

	public void setSrInductionApplication(String srInductionApplication) {
		this.srInductionApplication = srInductionApplication;
	}

	public String getSrInductionLocation() {
		return this.srInductionLocation;
	}

	public void setSrInductionLocation(String srInductionLocation) {
		this.srInductionLocation = srInductionLocation;
	}

	public String getInsuredId() {
		return this.insuredId;
	}

	public void setInsuredId(String insuredId) {
		this.insuredId = insuredId;
	}

	public String getInsuredName() {
		return this.insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getLineOfBusiness() {
		return this.LineOfBusiness;
	}

	public void setLineOfBusiness(String LineOfBusiness) {
		this.LineOfBusiness = LineOfBusiness;
	}

	public BigDecimal getLobNo() {
		return this.lobNo;
	}

	public void setLobNo(BigDecimal lobNo) {
		this.lobNo = lobNo;
	}

	public String getProgramCountry() {
		return this.programCountry;
	}

	public void setProgramCountry(String programCountry) {
		this.programCountry = programCountry;
	}

	public String getMasterPolicyInd() {
		return this.masterPolicyInd;
	}

	public void setMasterPolicyInd(String masterPolicyInd) {
		this.masterPolicyInd = masterPolicyInd;
	}

	public String getPolicyNumber() {
		return this.policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getCountryOfLegalEntity() {
		return this.countryOfLegalEntity;
	}

	public void setCountryOfLegalEntity(String countryOfLegalEntity) {
		this.countryOfLegalEntity = countryOfLegalEntity;
	}

	public String getProgramUid() {
		return this.programUid;
	}

	public void setProgramUid(String programUid) {
		this.programUid = programUid;
	}

	public Date getProgramInsDate() {
		return this.programInsDate;
	}

	public void setProgramInsDate(Date programInsDate) {
		this.programInsDate = programInsDate;
	}

	public String getProgramName() {
		return this.programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public BigDecimal getProgramNo() {
		return this.programNo;
	}

	public void setProgramNo(BigDecimal programNo) {
		this.programNo = programNo;
	}

	public String getSourceSystemCd() {
		return this.SourceSystemCd;
	}

	public void setSourceSystemCd(String SourceSystemCd) {
		this.SourceSystemCd = SourceSystemCd;
	}

}