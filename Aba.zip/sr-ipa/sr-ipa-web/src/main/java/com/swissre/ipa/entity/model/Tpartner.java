package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TPARTNER database table.
 * 
 */
@Entity
@NamedQueries({ @NamedQuery(name="Tpartner.findAll", query="SELECT t FROM Tpartner t"),
				@NamedQuery(name = "Tpartner.findBySDLId", query = "SELECT t FROM Tpartner t WHERE t.partnerSdlId = :partnerSdlId")})
public class Tpartner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TPARTNER_PARTNERNO_GENERATOR", sequenceName="PARTNER_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TPARTNER_PARTNERNO_GENERATOR")
	@Column(name="PARTNER_NO")
	private long partnerNo;

	@Column(name="CORPART_ID")
	private String corpartId;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	@Column(name="PARNTER_COMPANY_ALIAS")
	private String parnterCompanyAlias;

	@Column(name="PARTNER_ADDRESS_LINE_1")
	private String partnerAddressLine1;

	@Column(name="PARTNER_ADDRESS_LINE_2")
	private String partnerAddressLine2;

	@Column(name="PARTNER_CITY")
	private String partnerCity;

	@Column(name="PARTNER_COMPANY_NAME")
	private String partnerCompanyName;

	@Column(name="PARTNER_COUNTRY_NO")
	private BigDecimal partnerCountryNo;

	@Column(name="PARTNER_EMAIL")
	private String partnerEmail;

	@Column(name="PARTNER_PHONE")
	private String partnerPhone;

	@Column(name="PARTNER_POSTCODE")
	private String partnerPostcode;

	@Column(name="PARTNER_SDL_ID")
	private String partnerSdlId;

	private BigDecimal rowversion;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	//bi-directional many-to-one association to TpartnerRole
	@OneToMany(mappedBy="tpartner")
	private List<TpartnerRole> tpartnerRoles;

	public Tpartner() {
	}

	public long getPartnerNo() {
		return this.partnerNo;
	}

	public void setPartnerNo(long partnerNo) {
		this.partnerNo = partnerNo;
	}

	public String getCorpartId() {
		return this.corpartId;
	}

	public void setCorpartId(String corpartId) {
		this.corpartId = corpartId;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public String getParnterCompanyAlias() {
		return this.parnterCompanyAlias;
	}

	public void setParnterCompanyAlias(String parnterCompanyAlias) {
		this.parnterCompanyAlias = parnterCompanyAlias;
	}

	public String getPartnerAddressLine1() {
		return this.partnerAddressLine1;
	}

	public void setPartnerAddressLine1(String partnerAddressLine1) {
		this.partnerAddressLine1 = partnerAddressLine1;
	}

	public String getPartnerAddressLine2() {
		return this.partnerAddressLine2;
	}

	public void setPartnerAddressLine2(String partnerAddressLine2) {
		this.partnerAddressLine2 = partnerAddressLine2;
	}

	public String getPartnerCity() {
		return this.partnerCity;
	}

	public void setPartnerCity(String partnerCity) {
		this.partnerCity = partnerCity;
	}

	public String getPartnerCompanyName() {
		return this.partnerCompanyName;
	}

	public void setPartnerCompanyName(String partnerCompanyName) {
		this.partnerCompanyName = partnerCompanyName;
	}

	public BigDecimal getPartnerCountryNo() {
		return this.partnerCountryNo;
	}

	public void setPartnerCountryNo(BigDecimal partnerCountryNo) {
		this.partnerCountryNo = partnerCountryNo;
	}

	public String getPartnerEmail() {
		return this.partnerEmail;
	}

	public void setPartnerEmail(String partnerEmail) {
		this.partnerEmail = partnerEmail;
	}

	public String getPartnerPhone() {
		return this.partnerPhone;
	}

	public void setPartnerPhone(String partnerPhone) {
		this.partnerPhone = partnerPhone;
	}

	public String getPartnerPostcode() {
		return this.partnerPostcode;
	}

	public void setPartnerPostcode(String partnerPostcode) {
		this.partnerPostcode = partnerPostcode;
	}

	public String getPartnerSdlId() {
		return this.partnerSdlId;
	}

	public void setPartnerSdlId(String partnerSdlId) {
		this.partnerSdlId = partnerSdlId;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

	public List<TpartnerRole> getTpartnerRoles() {
		return this.tpartnerRoles;
	}

	public void setTpartnerRoles(List<TpartnerRole> tpartnerRoles) {
		this.tpartnerRoles = tpartnerRoles;
	}

	public TpartnerRole addTpartnerRole(TpartnerRole tpartnerRole) {
		getTpartnerRoles().add(tpartnerRole);
		tpartnerRole.setTpartner(this);

		return tpartnerRole;
	}

	public TpartnerRole removeTpartnerRole(TpartnerRole tpartnerRole) {
		getTpartnerRoles().remove(tpartnerRole);
		tpartnerRole.setTpartner(null);

		return tpartnerRole;
	}

}