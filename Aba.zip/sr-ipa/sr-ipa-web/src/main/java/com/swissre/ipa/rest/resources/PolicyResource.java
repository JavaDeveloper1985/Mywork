package com.swissre.ipa.rest.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.MULTIPART_FORM_DATA;

import java.net.URI;
import java.util.logging.Logger;

import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.swissre.cmd.interceptors.AppService;
import com.swissre.ipa.rest.AppRestURIs;
import com.swissre.ipa.services.EDMSService;

@Stateless
@LocalBean
@AppService
@RolesAllowed({"AuthenticatedUser","AppUser","AppUpdateUser"})
@Path(AppRestURIs.POLICY)

public class PolicyResource {
	
	@EJB
	EDMSService edmsService;
	
	private static final Logger logger = Logger.getLogger(PolicyResource.class.getName());
	
	@POST
	@Produces({ APPLICATION_JSON })
	@Consumes({ MULTIPART_FORM_DATA })
	@Path("/upload/{documentTrackerNo}/env/{env}/prefix/{prefix}")
	public Response uploadFile(@Context HttpServletRequest httpServletRequest
			,@PathParam("documentTrackerNo") String documentTrackerNo
			,@PathParam("env") String env
			,@PathParam("prefix") String prefix) {
		if(documentTrackerNo == null || documentTrackerNo.length() == 0) {
			return Response.serverError().entity("Document Tracker No cannot be blank").build();
		}
		String edmsResponse = edmsService.uploadDocument(httpServletRequest,documentTrackerNo,env,prefix);
		if(edmsResponse == null) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Document could not be uploaded for documentTrackerNo: "+documentTrackerNo).build();
		}
		
		return Response.created(URI.create(AppRestURIs.POLICY)).entity(edmsResponse).build();
	}
	
	@POST
	@Path("/program/{programNo}/contract/{contractNo}/docType/{docTypeNo}")
	@Produces({ APPLICATION_JSON })
	@Consumes({ APPLICATION_JSON })
	public Response createDocTypeEntry(@PathParam("programNo") String programNo
			,@PathParam("contractNo") String contractNo
			,@PathParam("docTypeNo") String docTypeNo){
		if(programNo == null || programNo.length() == 0) {
			return Response.serverError().entity("Program No cannot be blank").build();
		}		
		if(contractNo == null || contractNo.length() == 0) {
			return Response.serverError().entity("Contract No cannot be blank").build();
		}
		if(docTypeNo == null || docTypeNo.length() == 0) {
			return Response.serverError().entity("Documnent Type No cannot be blank").build();
		}
		String edmsResponse = edmsService.createDocTypeEntry(programNo,contractNo,docTypeNo);
		return Response.created(URI.create(AppRestURIs.POLICY)).entity(edmsResponse).build();		
	}		
}




