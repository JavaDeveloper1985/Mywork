package com.swissre.ipa.util;

import java.io.File;


public class EnvironmentProperties {

	
	private static final String DEV_URL_PREFIX =  "http://web-dev.swissre.com/webapp";
	private static final String LOCAL_URL_PREFIX =  "http://localhost:10000/webapp";
	private static final String TRAIN_URL_PREFIX =  "http://web-ite.swissre.com/webapp";
	private static final String PROD_URL_PREFIX =  "http://web.swissre.com/webapp";

	private static final String PREVIEW_SERVLET_RELATIVE_URL =  "/bsk/EDMSDocumentPreviewServlet";
	private static final String PREVIEW_PACKAGE_SERVLET_RELATIVE_URL ="/bsk/EDMSDocumentMergeAndPreviewServlet";
	private static final String WORD_PREVIEW_PACKAGE_SERVLET_RELATIVE_URL="/bsk/EDMSDocumentMergeAndPreviewWordServlet";
	
	private static final String EDMS_PREVIEW_SERVLET_RELATIVE_URL =  "StreamingServlet?appName=NATIVE&docId=";
	private static final String DGF_FILE_UPLOAD_SERVLET_NAME = "dgfFileUploadServlet";
	
	private static Environment env;
	private static String appName;
	private static boolean isLocalDev;
	private static File tempDir;
	
	private EnvironmentProperties() {
	}

	public static String getEnvironment() {
		return env.getName();
	}

	public static String getURLPrefix() {
		String urlPrefix = null;
		
        switch (env) {
            case DEVELOPMENT:
            	urlPrefix = (isLocalDev ? LOCAL_URL_PREFIX : DEV_URL_PREFIX);
                break;
                    
            case TRAINING:
            	urlPrefix = TRAIN_URL_PREFIX;
                break;
                         
            case PRODUCTION: 
            	urlPrefix = PROD_URL_PREFIX;
                break;
            
            default:
                throw new IllegalStateException("No environment set");	                
        }
		return urlPrefix;
	}

	public static void setEnvironment(Environment env) {
		EnvironmentProperties.env = env;
	}

	public static String getApplicationName() {
		return appName;
	}
	
	public static void setApplicationName(String applicationName) {
		appName = applicationName;
	}
	
	public static void setIsLocalDev() {
		isLocalDev = true;
	}
	
	public static boolean isLocalDev() {
		return isLocalDev;
	}
	
	public static File getTempDir() {
		if (tempDir == null) {
			 tempDir = new File(System.getProperty("java.io.tmpdir"));
		}
		
		return tempDir;
	}
	
	public static String getPreviewServletRelativeURL() {
		return getURLPrefix() + PREVIEW_SERVLET_RELATIVE_URL;
	}

	/**
	 * @return the previewPackageServletRelativeUrl
	 */
	public static String getPreviewPackageServletRelativeUrl() {
		return getURLPrefix() +PREVIEW_PACKAGE_SERVLET_RELATIVE_URL;
	}

	public static String getWordPreviewPackageServletRelativeUrl() {
		return getURLPrefix() +WORD_PREVIEW_PACKAGE_SERVLET_RELATIVE_URL;
	}
	
	public static String getEDMSPreviewServletURL() {
		return EDMS_PREVIEW_SERVLET_RELATIVE_URL;
	}
	
	public static String getFileUploadServletName() {
		return DGF_FILE_UPLOAD_SERVLET_NAME;
	}

}
