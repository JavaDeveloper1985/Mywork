package com.swissre.ipa.integration.mdm;

/**
 * @author <a href="mailto:Sergey_Trasko@rcomext.com">Sergey Trasko</a>
 */
public class RestException extends Exception {

    public RestException(String message) {
        super(message);
    }

    public RestException(String message, Throwable cause) {
        super(message, cause);
    }
}
