package com.swissre.ipa.util;

import java.util.Properties;

import com.swissre.cmd.util.AppException;

/**
 * A simple extension of {@code java.util.Properties} designed to be used for
 * application configuration. Utility methods are provided to simplify working
 * with the contained properties.
 */
public class Config extends Properties
{
    private static final long serialVersionUID = 1L;

    /**
     * Returns an instance of the class configured in the given {@code propertyName}.
     * 
     * @param <T> The expected type of the new instance.
     * @param type The expected class (or supertype) of the new instance.
     * @param propertyName The property name to read the full classname from.
     * @return A new instance of the given type.
     * @throws AppException 
     */
    @SuppressWarnings("unchecked")
    public <T> T getInstanceOfType(Class<T> type, String propertyName) throws AppException
    {
        String className = getProperty(propertyName);
        try
        {
            return (T) Class.forName(className).newInstance();
        }
        catch (Exception e)
        {
            throw new AppException(
                    String.format(
                            "Failed to instantiate the class %s (specified in property %s)",
                            className, propertyName), e);
        }
    }
}
