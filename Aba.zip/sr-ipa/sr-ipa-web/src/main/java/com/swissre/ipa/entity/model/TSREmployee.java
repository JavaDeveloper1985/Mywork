package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TSR_EMPLOYEE database table.
 * 
 */
@Entity
@Table(name="TSR_EMPLOYEE")
@NamedQuery(name="TSREmployee.findAll", query="SELECT t FROM TSREmployee t")
public class TSREmployee implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TSR_EMPLOYEE_SREMPNO_GENERATOR", sequenceName="SREMP_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TSR_EMPLOYEE_SREMPNO_GENERATOR")
	@Column(name="SREMP_NO")
	private long srempNo;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	private BigDecimal rowversion;

	@Column(name="SREMP_EMAIL")
	private String srempEmail;

	@Column(name="SREMP_FIRST_NAME")
	private String srempFirstName;

	@Column(name="SREMP_JOB_TITLE")
	private String srempJobTitle;

	@Column(name="SREMP_LAST_NAME")
	private String srempLastName;

	@Column(name="SREMP_PHONENO")
	private BigDecimal srempPhoneno;

	private String srid;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	//bi-directional many-to-one association to TSREmployeeRole
	@OneToMany(mappedBy="tsrEmployee",cascade = CascadeType.PERSIST)
	private List<TSREmployeeRole> tsrEmployeeRoles;

	public TSREmployee() {
	}

	public long getSrempNo() {
		return this.srempNo;
	}

	public void setSrempNo(long srempNo) {
		this.srempNo = srempNo;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public String getSrempEmail() {
		return this.srempEmail;
	}

	public void setSrempEmail(String srempEmail) {
		this.srempEmail = srempEmail;
	}

	public String getSrempFirstName() {
		return this.srempFirstName;
	}

	public void setSrempFirstName(String srempFirstName) {
		this.srempFirstName = srempFirstName;
	}

	public String getSrempJobTitle() {
		return this.srempJobTitle;
	}

	public void setSrempJobTitle(String srempJobTitle) {
		this.srempJobTitle = srempJobTitle;
	}

	public String getSrempLastName() {
		return this.srempLastName;
	}

	public void setSrempLastName(String srempLastName) {
		this.srempLastName = srempLastName;
	}

	public BigDecimal getSrempPhoneno() {
		return this.srempPhoneno;
	}

	public void setSrempPhoneno(BigDecimal srempPhoneno) {
		this.srempPhoneno = srempPhoneno;
	}

	public String getSrid() {
		return this.srid;
	}

	public void setSrid(String srid) {
		this.srid = srid;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

	public List<TSREmployeeRole> getTsrEmployeeRoles() {
		return this.tsrEmployeeRoles;
	}

	public void setTsrEmployeeRoles(List<TSREmployeeRole> tsrEmployeeRoles) {
		this.tsrEmployeeRoles = tsrEmployeeRoles;
	}

	public TSREmployeeRole addTsrEmployeeRole(TSREmployeeRole tsrEmployeeRole) {
		getTsrEmployeeRoles().add(tsrEmployeeRole);
		tsrEmployeeRole.setTsrEmployee(this);

		return tsrEmployeeRole;
	}

	public TSREmployeeRole removeTsrEmployeeRole(TSREmployeeRole tsrEmployeeRole) {
		getTsrEmployeeRoles().remove(tsrEmployeeRole);
		tsrEmployeeRole.setTsrEmployee(null);

		return tsrEmployeeRole;
	}

}