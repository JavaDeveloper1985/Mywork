package com.swissre.ipa.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.swissre.cmd.rest.resources.AppInfoResource;
import com.swissre.cmd.rest.resources.DBActionResource;
import com.swissre.cmd.rest.resources.RefDataResource;
import com.swissre.cmd.rest.resources.ScreenResource;
import com.swissre.cmd.rest.resources.SearchScreenResource;
import com.swissre.ipa.rest.resources.EmployeeResource;
import com.swissre.ipa.rest.resources.IPAPartnerResource;
import com.swissre.ipa.rest.resources.MDMResource;
import com.swissre.ipa.rest.resources.PolicyResource;
import com.swissre.ipa.rest.resources.ProgramResource;



/**
 * Per the JAX-RS API, this extension of the JAX-RS {@code Application} class
 * defines the REST resource classes to the JAX-RS runtime. In the Manhattan
 * Services architecture, our resource classes are Service Facades.
 * 
 * @see javax.ws.rs.core.Application
 */
@ApplicationPath("/api/")
public class RestApplication extends Application
{

    /**
     * This method should return all of the REST Service Facade classes defined
     * by this application.
     * 
     * @see javax.ws.rs.core.Application#getClasses()
     */
    @Override
    public Set<Class<?>> getClasses()
    {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(RefDataResource.class);
        classes.add(IPAPartnerResource.class);
        classes.add(AppInfoResource.class);
        classes.add(ScreenResource.class);
        classes.add(DBActionResource.class);
        classes.add(SearchScreenResource.class);
        classes.add(ProgramResource.class);
        classes.add(EmployeeResource.class);
        classes.add(MDMResource.class);
        classes.add(PolicyResource.class);
        return classes;
    }

}
