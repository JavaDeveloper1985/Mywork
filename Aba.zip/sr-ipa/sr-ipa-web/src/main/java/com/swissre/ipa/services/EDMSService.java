package com.swissre.ipa.services;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.swissre.cmd.data.access.DataAccessService;
import com.swissre.cmd.util.AppException;
import com.swissre.ipa.entity.model.TdocumentTracker;
import com.swissre.ipa.integration.edms.DocumentPersistenceProvider;
import com.swissre.ipa.util.DataSourceImpl;

@Stateless
@LocalBean
public class EDMSService {

	private static final Logger logger = Logger.getLogger(EDMSService.class.getName());

	@EJB
	private DocumentPersistenceProvider documentPersistenceProvider;
	@EJB
	private DataAccessService dataAccessService;

	@Resource
	private EJBContext ejbContext;

	public String getLoggedInUserId() {
		Principal identity = ejbContext.getCallerPrincipal();
		return (identity.getName());
	}

	public String createDocTypeEntry(String programNo, String contractNo, String docTypeNo) {

		TdocumentTracker docTracker = new TdocumentTracker();
		docTracker.setIbProgramNo(new BigDecimal(programNo));
		docTracker.setContractNo(new BigDecimal(contractNo));
		docTracker.setDocumentTypeNo(new BigDecimal(docTypeNo));
		dataAccessService.create(docTracker);
		EntityManager em = dataAccessService.getEntityManager();
		em.refresh(docTracker);
		TdocumentTracker tracker = dataAccessService.find(TdocumentTracker.class, docTracker.getDocumentTrackerNo());
		String strRowVersion = "";
		if (null != tracker.getRowversion()) {
			strRowVersion = tracker.getRowversion().toString();
		}
		JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
		jsonObjectBuilder.add("documentId", Long.toString(docTracker.getDocumentTrackerNo()));
		jsonObjectBuilder.add("rowversion", strRowVersion);
		JsonObject obj = jsonObjectBuilder.build();
		return obj.toString();
	}

	public String uploadDocument(HttpServletRequest httpServletRequest, String documentTrackerNo, String env,
			String prefix) {
		String documentId = null;
		DataSourceImpl ds = new DataSourceImpl();
		ServletFileUpload upload = new ServletFileUpload();
		FileItemIterator iter;
		try {
			iter = upload.getItemIterator(httpServletRequest);
			while (iter.hasNext()) {
				FileItemStream item = iter.next();
				ds.setContentType(item.getContentType());
				ds.setInputStream(item.openStream());
				DataHandler dataHandler = new DataHandler(ds);
				String fileName = item.getName();
				logger.info("File Name : " + fileName);
				if (!item.isFormField()) {
					documentId = uploadDocumentEDMS(dataHandler, fileName, documentTrackerNo, env, prefix);
				}

			}
		} catch (FileUploadException e) {
			throw new AppException("Error occured while uploading the document", e);
		} catch (IOException e) {
			throw new AppException("Error occured while itreating over the FileItemStream", e);
		}
		JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
		jsonObjectBuilder.add("documentId", documentId);
		jsonObjectBuilder.add("addedBy", getLoggedInUserId());
		JsonObject obj = jsonObjectBuilder.build();
		return obj.toString();
	}

	private String uploadDocumentEDMS(DataHandler dataHandler, String fileName, String documentTrackerNo, String env,
			String prefix) {
		String documentId = null;
		InputStream inputStream = null;
		String contentType = null;
		try {
			inputStream = dataHandler.getInputStream();
			contentType = dataHandler.getContentType();
			documentId = documentPersistenceProvider.upload(inputStream, contentType, fileName, documentTrackerNo, env,
					prefix);
		} catch (IOException e) {
			logger.log(Level.SEVERE, e.getMessage());
			throw new AppException(e.getMessage(), e.getCause());
		}
		return documentId;
	}

}
