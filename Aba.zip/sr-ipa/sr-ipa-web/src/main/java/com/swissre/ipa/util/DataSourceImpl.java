package com.swissre.ipa.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DataSourceImpl implements javax.activation.DataSource{

	private InputStream inputStream;
	private String contentType;
	
	@Override
	public String getContentType() {
				return contentType;
	}

	@Override
	public InputStream getInputStream() throws IOException {
		return inputStream;
	}

	@Override
	public String getName() {
		return "File Dataource";
	}

	@Override
	public OutputStream getOutputStream() throws IOException {
		return null;
	}
	
	public void setContentType(String contentType) {
		this.contentType =  contentType;
	}


	public void setInputStream(InputStream inputStream){
		this.inputStream =  inputStream;
	}
	
}