package com.swissre.ipa.integration.edms;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.swissre.cmd.data.access.DataAccessService;
import com.swissre.cmd.util.AppException;
import com.swissre.ipa.entity.model.VEDMSPolicyAttr;
import com.swissre.ipa.integration.edms.mapper.DocumentSingleValueMapper;
import com.swissre.ipa.services.wsclient.upload.SingleValsType;
import com.swissre.ipa.services.wsclient.upload.UploadDocumentRequest;
import com.swissre.ipa.services.wsclient.upload.UploadDocumentResponse;
import com.swissre.ipa.util.AbstractConfigurableService;
/*import com.swissre.iba.util.DataAccessService;*/
import com.swissre.ipa.util.DataSourceImpl;
import com.swissre.ipa.util.ServiceConstants;
import com.swissre.ipa.util.ServiceFactory;

import ma.glasnost.orika.MapperFacade;

@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.MANDATORY)
public class DocumentPersistenceProvider extends AbstractConfigurableService {

	private static final Logger logger = Logger.getLogger(DocumentPersistenceProvider.class.getName());

	@EJB
	DataAccessService dataAccessService;

	public static final String EDMS_DATE_FORMAT = "yyyy-MM-dd";
	public static final String EDMS_INDUCTION_DATE_FORMAT = "yyyy-MM-dd-HH.mm.ss.SSS";

	public String upload(InputStream inputStream, String contentType, String docName, String documentTrackerNo,
			String env, String prefix) {
		UploadDocumentRequest request = new UploadDocumentRequest();
		DataSourceImpl ds = new DataSourceImpl();
		ds.setContentType(contentType);
		ds.setInputStream(inputStream);
		DataHandler dh = new DataHandler(ds);
		request.setFilestream(dh);
		request.setObjectName(docName);
		SingleValsType singleVals = createSingleValsType(documentTrackerNo);
		singleVals.setFileName(docName.replaceFirst("[.][^.]+$", ""));
		singleVals.setFileType(contentType);
		request.setSingleVals(singleVals);
		logger.info("Upload Document");
		UploadDocumentResponse response;
		response = ServiceFactory.getInstance().getDocumentUploadService(env, prefix).uploadDocument(request);
		if (!ServiceConstants.EDMS_OPERATION_SUCCESS.equalsIgnoreCase(response.getExecutionStatus())) {
			throw new AppException("Uploading failed => " + response.getErrorDescription());
		}
		String documentId = response.getDocumentId();
		logger.info("Documnet Id: " + documentId);
		return documentId;
	}

	private SingleValsType createSingleValsType(String documentTrackerNo) {
		VEDMSPolicyAttr policyAttr = dataAccessService.find(VEDMSPolicyAttr.class, new BigDecimal(documentTrackerNo));
		SingleValsType singleVals = convertToJaxbObject(policyAttr);
		return singleVals;
	}

	private SingleValsType convertToJaxbObject(VEDMSPolicyAttr policyAttr) {
		MapperFacade singleValueMapper = new DocumentSingleValueMapper();
		SingleValsType singleValsType = singleValueMapper.map(policyAttr, SingleValsType.class);
		return singleValsType;
	}

}
