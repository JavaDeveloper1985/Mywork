package com.swissre.ipa.util;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;

import com.swissre.ws.security.WASSecurity;

public class AppUtils {
		
	private static final String APPPREFIX = "app-prefix";
	private static final String MAINAPPPREFIX = "main-app-prefix";
	private static final String propertyFileName = "application.properties";
	private static final String MANCTURL = "URL";
	
	
	public static String decodeURL(String urlCode) { 	 	
		return null;	
	}
	
	public static void createBindingProvider(Object portType,
			String endPointURL) {
		BindingProvider bindingProvider = (BindingProvider) portType;
		bindingProvider.getRequestContext().put(
				BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endPointURL);
		Map<String, List<String>> headers = new HashMap<String, List<String>>();
		headers.put("Cookie", Collections.singletonList("LtpaToken2="
						+ WASSecurity.getSecurityToken()));
		bindingProvider.getRequestContext().put(
				MessageContext.HTTP_REQUEST_HEADERS, headers);
	}

	public static String covertDateToString(Date date, String inputFormat) {
		if (date != null) {
			return new SimpleDateFormat(inputFormat).format(date);
		}
		return "";
	}
	
	public static String generateParamsJSONString(MultivaluedMap<String, String> queryParamsMap) {
		return null;
	}
		
}
