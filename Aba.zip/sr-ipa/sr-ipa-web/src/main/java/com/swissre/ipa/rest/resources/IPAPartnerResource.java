package com.swissre.ipa.rest.resources;


import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.util.logging.Logger;

import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.swissre.cmd.interceptors.AppService;
import com.swissre.ipa.rest.AppRestURIs;
import com.swissre.ipa.services.ProgramService;

@Stateless
@LocalBean
@AppService
@RolesAllowed({"AuthenticatedUser","AppUser","AppUpdateUser"})
@Path(AppRestURIs.PARTNERS)
public class IPAPartnerResource {
	
	private static final Logger logger = Logger.getLogger(IPAPartnerResource.class.getName());
	
	@EJB
	ProgramService programService;
	
	@POST	
	@Consumes({APPLICATION_JSON})
	@Path("/{partnerRole}/{contractNo}/{partnerSdlId}")
	public Response createNewPartnerEntry(
			@PathParam("partnerRole") String partnerRole,
			@PathParam("contractNo") String contractNo,
			@PathParam("partnerSdlId") String partnerSdlId)
	{		
		if(contractNo == null || contractNo.length() == 0) {
			return Response.serverError().entity("Contract No cannot be blank").build();
		}
		if(partnerRole == null || partnerRole.length() == 0) {
			return Response.serverError().entity("Partner Role Name cannot be blank").build();
		}
		if(partnerSdlId == null || partnerSdlId.length() == 0) {
			return Response.serverError().entity("Partner SDL ID cannot be blank").build();
		}
		Long partnerNo = programService.savePartnerDetails(partnerRole,contractNo,partnerSdlId);
		return Response.created(URI.create(AppRestURIs.PARTNERS+"/"+partnerNo)).entity(partnerNo).build();
	}	
}