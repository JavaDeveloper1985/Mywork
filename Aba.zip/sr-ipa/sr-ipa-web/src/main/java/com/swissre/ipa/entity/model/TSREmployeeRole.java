package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TSR_EMPLOYEE_ROLE database table.
 * 
 */
@Entity
@Table(name="TSR_EMPLOYEE_ROLE")
@NamedQuery(name="TSREmployeeRole.findAll", query="SELECT t FROM TSREmployeeRole t")
public class TSREmployeeRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TSR_EMPLOYEE_ROLE_SREMPROLENO_GENERATOR", sequenceName="SREMP_ROLE_NO",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TSR_EMPLOYEE_ROLE_SREMPROLENO_GENERATOR")
	@Column(name="SREMP_ROLE_NO")
	private long srempRoleNo;

	@Column(name="IB_PROGRAM_NO")
	private BigDecimal ibProgramNo;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	private BigDecimal rowversion;

	@Column(name="SREMP_ROLE_NAM")
	private String srempRoleNam;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	//bi-directional many-to-one association to TSREmployee
	@ManyToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name="SREMP_NO")
	private TSREmployee tsrEmployee;

	public TSREmployeeRole() {
	}

	public long getSrempRoleNo() {
		return this.srempRoleNo;
	}

	public void setSrempRoleNo(long srempRoleNo) {
		this.srempRoleNo = srempRoleNo;
	}

	public BigDecimal getIbProgramNo() {
		return this.ibProgramNo;
	}

	public void setIbProgramNo(BigDecimal ibProgramNo) {
		this.ibProgramNo = ibProgramNo;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public String getSrempRoleNam() {
		return this.srempRoleNam;
	}

	public void setSrempRoleNam(String srempRoleNam) {
		this.srempRoleNam = srempRoleNam;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

	public TSREmployee getTsrEmployee() {
		return this.tsrEmployee;
	}

	public void setTsrEmployee(TSREmployee tsrEmployee) {
		this.tsrEmployee = tsrEmployee;
	}

}