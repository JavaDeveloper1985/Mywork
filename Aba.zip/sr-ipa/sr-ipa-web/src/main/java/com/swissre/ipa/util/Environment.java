package com.swissre.ipa.util;

public enum Environment {

	DEVELOPMENT("DEVELOPMENT"), TRAINING("TRAINING"), PRODUCTION("PRODUCTION");

	private final String name;
		
	public String getName() {
		return name;
	}

	Environment(String name) {
		this.name = name;
	}
}
