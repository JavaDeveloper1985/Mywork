package com.swissre.ipa.util ;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import com.swissre.cmd.util.AppException;

/**
 * An abstract base class for configurable services.
 */
public abstract class AbstractConfigurableService
{
	private static final Logger LOGGER = Logger.getLogger(AbstractConfigurableService.class.getName());
	
	protected AbstractConfigurableService()
    {
    }

    /**
     * Called by the EJB container to complete initialization of this instance
     * after all dependency injects are complete on this instance.
     */
    @PostConstruct
    protected void onPostConstruct()
    {
        ServiceConfig serviceConfig =null;
		try {
			serviceConfig = ServiceConfig.getConfigFor(getClass());
		} catch (AppException ex) {			
			LOGGER.log(Level.SEVERE, ex.getMessage());
			throw new AppException(ex.getMessage(), ex.getCause());
		}
        
        // Give subclasses a chance to perform initialization.
        init(serviceConfig);
    }
    
    /**
     * Subclasses should override this method to perform any initialization
     * required after dependency injections are complete but before business
     * methods are invoked.
     */
    protected void init(ServiceConfig serviceConfig)
    {
    }
    
    
}
