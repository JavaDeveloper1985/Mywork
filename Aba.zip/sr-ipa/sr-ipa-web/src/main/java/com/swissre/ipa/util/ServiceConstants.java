package com.swissre.ipa.util;

public class ServiceConstants {
	
	public static final String POLICYTYPE_LOCAL = "LOCAL";
	public static final String POLICYTYPE_MASTER = "MASTER";
	public static final String COSTING_LINETYPE_LOCAL = "Local";
	public static final String COSTING_LINETYPE_MASTER = "Master";
	public static final String IS_AVAILABLE = "Y";
	public static final String PARTNER_ROLE_INSURED = "Insured";
	public static final String EDMS_OPERATION_SUCCESS = "SUCCESS...";
	public static final String IPA_ENV_DEV = "DEVELOPMENT";
	public static final String IPA_ENV_TRAIN = "TRAINING";
	public static final String CATEGORY_CLIENTS = "clients";
	public static final String CATEGORY_LEGALENTITIES = "legalentities";	
}
