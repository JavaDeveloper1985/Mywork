package com.swissre.ipa.integration.mdm;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.ws.rs.core.HttpHeaders;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.cmd.util.AppException;
import com.swissre.ws.security.WASSecurity;

public class RestUtil {
	 private RequestMethod method = RequestMethod.GET;
	 private String accepts = "application/json";
     private String contentType = "application/json";
     private Map<String, Collection<String>> headers = new HashMap<String, Collection<String>>();
     private Object request;
     private ObjectMapper objectMapper;
     private final static Logger logger = Logger.getLogger(RestUtil.class.getName());
     
     public String execute(String url) throws AppException{
	    	String response = null;
	       	HttpURLConnection connection = createConnection(url);
	       	WASSecurity.preauthenticateWithLTPACookie(connection);
	       	setRequestParameters(connection);
	       	logger.info(connection.getRequestProperty("Cookie"));
	       	response = performRequest(connection);
	       	connection.disconnect();
	       	return response;
    	   
        }
     
     private String performRequest(HttpURLConnection connection) {
    	logger.fine("Performing request");
         int responseCode = 0;
         try {
             responseCode = connection.getResponseCode();
         } catch (IOException e) {
             throw new AppException("Cannot get response code", e);
         }
         if (responseCode != 200) {
             throw new AppException("Unexpected response code " + responseCode + " received (expecting 200)");
         }
         String body;
         try {
             body = IOUtils.toString(connection.getInputStream());
         } catch (IOException e) {
             throw new AppException("Cannot read response", e);
         }
         return body;
     }
     
     
     private HttpURLConnection createConnection(String url) {
            HttpURLConnection connection;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
            } catch (IOException e) {
                throw new AppException("Cannot establish connection to " + url);
            }
            return connection;
        }
     
     public void setRequestParameters(HttpURLConnection connection) {
            try {
                connection.setRequestMethod(method.name());
            } catch (ProtocolException e) {
                throw new AppException("Invalid method name: " + method, e);
            }
           logger.fine("Accept is '" + accepts + "', content type is '" + contentType + "'");
            connection.setRequestProperty(HttpHeaders.ACCEPT, accepts);
            connection.setRequestProperty(HttpHeaders.CONTENT_TYPE, contentType);
            for (Map.Entry<String, Collection<String>> headerEntry : headers.entrySet()) {
                Collection<String> values = headerEntry.getValue();
                for (String value : values) {
                    if (value != null && !value.trim().isEmpty()) {
                        connection.setRequestProperty(headerEntry.getKey(), value);
                    }
                }
            }

            if (request != null) {
            	logger.fine("Request body is not empty");
                try {
                    OutputStream outputStream = connection.getOutputStream();
                    PrintWriter writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outputStream)));
                    objectMapper.writeValue(writer, request);
                    writer.print("\n");
                } catch (IOException e) {
                    throw new AppException("Cannot write request body", e);
                }
            }
        }
     
	public RestUtil() {
		super();
	}
	

}