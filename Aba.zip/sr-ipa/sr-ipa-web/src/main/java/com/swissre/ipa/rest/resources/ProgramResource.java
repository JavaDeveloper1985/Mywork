package com.swissre.ipa.rest.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;

import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.swissre.cmd.interceptors.AppService;
import com.swissre.ipa.rest.AppRestURIs;
import com.swissre.ipa.services.ProgramService;

@Stateless
@LocalBean
@AppService
@RolesAllowed({"AuthenticatedUser","AppUser","AppUpdateUser"})
@Path(AppRestURIs.PROGRAMS)
public class ProgramResource {
	
	@EJB
	ProgramService programService;
	
	@POST
	@Produces({APPLICATION_JSON})
	public Response createNewProgramEntry() 
	{				
		Long programNo = programService.createNewProgramEntry();
		return Response.created(URI.create(AppRestURIs.PROGRAMS+"/"+programNo)).entity(programNo).build();
	}
	
	@POST	
	@Consumes({APPLICATION_JSON})
	@Path("/{corflowDealId}")
	public Response createNewDealEntry(@PathParam("corflowDealId") String corflowDealId) 
	{		
		if(corflowDealId == null || corflowDealId.trim().length() == 0){
			return Response.serverError().entity("Corflow DealId cannot be blank").build();
		}
		Long dealNo = programService.createNewDealEntry(corflowDealId);
		return Response.created(URI.create(AppRestURIs.PROGRAMS+"/"+dealNo)).entity(dealNo).build();
	}	
}
