package com.swissre.ipa.rest.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.util.logging.Logger;

import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import com.swissre.cmd.interceptors.AppService;
import com.swissre.ipa.rest.AppRestURIs;
import com.swissre.ipa.services.MDMService;

@Stateless
@LocalBean
@AppService
@RolesAllowed({"AuthenticatedUser","AppUser","AppUpdateUser"})
@Path(AppRestURIs.MDMRESOURCE)
public class MDMResource {
	
	private static final Logger logger = Logger.getLogger(MDMResource.class.getName());
	@EJB
	MDMService mdmService;
	
	@GET
	@Produces({ APPLICATION_JSON })
	public Response fetchMdmData(@QueryParam("resourceType") String resourceType,
							   @QueryParam("searchQuery") String searchQuery,
							   @QueryParam("queryType") String queryType,
							   @QueryParam("url") String env,
							   @QueryParam("option1") String option1)  {
		if(resourceType == null || resourceType.length() == 0){
			return Response.serverError().entity("Resource Type cannot be blank").build();
		}
		
		boolean codeSearchOnly = StringUtils.isBlank(queryType)?false:true; 
		String mdmResponse = "";
		if(resourceType.equalsIgnoreCase("Carrier")){
			mdmResponse = mdmService.getCarriers(searchQuery,codeSearchOnly,env,option1);
		}else if(resourceType.equalsIgnoreCase("Insured")){
			mdmResponse = mdmService.getInsured(searchQuery,codeSearchOnly,env);
		}else{
			return Response.status(Response.Status.BAD_REQUEST).entity("Unknown resource type").build();
		}
		return Response.created(URI.create(AppRestURIs.MDMRESOURCE)).entity(mdmResponse).build();
	}
}