package com.swissre.ipa.rest;

/**
 * Defines the base resource URIs supported by the RESTful services. URIs are relative
 * to the web path of the REST servlet (i.e., {@code javax.ws.rs.core.Application}).
 */
public interface AppRestURIs
{
    final String PROGRAMS = "/programs";
    final String PARTNERS = "/partners";
    final String MDMRESOURCE = "/mdmresource";
    final String EMPLOYEES = "/employees";
    final String POLICY = "/policy";
}
