package com.swissre.ipa.services;

import java.math.BigDecimal;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.swissre.cmd.data.access.DataAccessService;
import com.swissre.cmd.data.access.QueryParameter;
import com.swissre.ipa.entity.model.TIBProgram;
import com.swissre.ipa.entity.model.TSREmployee;
import com.swissre.ipa.entity.model.TSREmployeeRole;
import com.swissre.ipa.entity.model.Tdeal;
import com.swissre.ipa.entity.model.Tpartner;
import com.swissre.ipa.entity.model.TpartnerRole;

@Stateless
@LocalBean
public class ProgramService {

	private static final Logger logger = Logger.getLogger(ProgramService.class.getName());
	@EJB
	DataAccessService dataAccessService;

	public long createNewProgramEntry() {
		TIBProgram tibProgram = new TIBProgram();
		dataAccessService.create(tibProgram);
		return tibProgram.getIbProgramNo();
	}

	public long createNewDealEntry(String corflowDealId) {
		Tdeal tdeal = new Tdeal();
		tdeal.setDealId(corflowDealId);
		dataAccessService.create(tdeal);
		return tdeal.getDealNo();
	}

	public long saveEmpDetails(String empFName, String empRole, String programNo) {
		TSREmployee employee = new TSREmployee();
		employee.setSrempFirstName(empFName);
		TSREmployeeRole employeeRole = new TSREmployeeRole();
		employeeRole.setSrempRoleNam(empRole);
		employeeRole.setIbProgramNo(new BigDecimal(programNo));
		employeeRole.setTsrEmployee(employee);
		dataAccessService.create(employeeRole);
		return employee.getSrempNo();
	}

	public long savePartnerDetails(String role, String contractNo, String partnerSdlId) {
		Tpartner tpartner = dataAccessService.findSingleResultWithNamedQuery(Tpartner.class, "Tpartner.findBySDLId",
				QueryParameter.with("partnerSdlId", partnerSdlId).parameters());
		if (null == tpartner) {
			tpartner = new Tpartner();
			dataAccessService.create(tpartner);
		}
		TpartnerRole tpartnerRole = new TpartnerRole();
		tpartnerRole.setPartnerRoleName(role);
		tpartnerRole.setContractNo(new BigDecimal(contractNo));
		tpartnerRole.setTpartner(tpartner);
		dataAccessService.create(tpartnerRole);
		return tpartner.getPartnerNo();
	}
}
