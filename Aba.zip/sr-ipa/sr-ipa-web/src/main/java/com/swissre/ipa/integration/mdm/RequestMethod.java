package com.swissre.ipa.integration.mdm;

/**
 * @author <a href="mailto:Sergey_Trasko@rcomext.com">Sergey Trasko</a>
 */
public enum RequestMethod {
    GET,
    POST,
    PUT,
    DELETE
}
