package com.swissre.ipa.util;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

import javax.xml.ws.BindingProvider;

import com.swissre.cmd.util.AppException;
import com.swissre.ipa.services.wsclient.upload.DocumentUploadService;
import com.swissre.ipa.services.wsclient.upload.DocumentUploadService_Service;
import com.swissre.ws.security.SRCookieHandler;
import com.swissre.ws.security.WASSecurity;
import com.swissre.ws.security.WasLtpaCookieRetrievalCallback;

public class ServiceFactory {

	private static final Logger LOGGER = Logger.getLogger(ServiceFactory.class.getName());
	private String previewServletURL;
	private String uploadServletURL;
	private static ServiceFactory instance;
	private String emdsEnvPrefix;

	private ServiceFactory() {
		SRCookieHandler.addCookieRetrievalCallback(new WasLtpaCookieRetrievalCallback());
		SRCookieHandler.setAsDefault();

		Properties edmsServiceProps = new Properties();
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		try {
			edmsServiceProps.load(classLoader.getResourceAsStream("CorSoEDMSServiceConfig.properties"));
		} catch (IOException e) {
			throw new AppException(e.getMessage(), e.getCause());
		}

	}

	private String getEnvPath(String env) {
		String envPath = "";
		if (env.equalsIgnoreCase("DEVELOPMENT")) {
			envPath = "http://ws-dev.swissre.com/webapp/";
		} else if (env.equalsIgnoreCase("TRAINING")) {
			envPath = "http://ws-ite.swissre.com/webapp/";
		} else {
			envPath = "http://ws.swissre.com/webapp/";
		}
		return envPath;
	}

	private String getEmdsEnvPrefix() {
		return emdsEnvPrefix;
	}

	private void setEndPoint(Object service, String serviceName, String env) {
		String envPath = getEnvPath(env);
		String urlPrefix = envPath + getEmdsEnvPrefix() + "/service/" + serviceName;
		LOGGER.info("env is:  " + env);
		LOGGER.info("CorSo EDMS Service URL prefix is:  " + urlPrefix);
		((BindingProvider) service).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, urlPrefix);
		WASSecurity.preauthenticateWithLTPACookie((BindingProvider) service);
	}

	public DocumentUploadService getDocumentUploadService(String env, String prefix) {
		DocumentUploadService_Service _service = new DocumentUploadService_Service();
		DocumentUploadService documentUploadService = _service.getDocumentUploadServicePortInternal();
		emdsEnvPrefix = prefix;
		setEndPoint(documentUploadService, "DocumentUploadServiceInternal", env);
		LOGGER.info("Return document UploadService");
		return documentUploadService;
	}

	public String getPreviewServletURL() {
		return previewServletURL;
	}

	public static Logger getLogger() {
		return LOGGER;
	}

	public String getUploadServletURL() {
		return uploadServletURL;
	}

	public static ServiceFactory getInstance() {
		if (instance == null) {
			instance = new ServiceFactory();
		}
		return instance;
	}
}
