package com.swissre.ipa.entity.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TDOCUMENT_TRACKER database table.
 * 
 */
@Entity
@Table(name="TDOCUMENT_TRACKER")
@NamedQuery(name="TdocumentTracker.findAll", query="SELECT t FROM TdocumentTracker t")
public class TdocumentTracker implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDOCUMENT_TRACKER_DOCUMENTTRACKERNO_GENERATOR", sequenceName="DOCUMENT_TRACKER_NO", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDOCUMENT_TRACKER_DOCUMENTTRACKERNO_GENERATOR")
	@Column(name="DOCUMENT_TRACKER_NO")
	private long documentTrackerNo;

	@Column(name="CONTRACT_NO")
	private BigDecimal contractNo;

	@Column(name="DEAL_NO")
	private BigDecimal dealNo;

	@Column(name="DOC_ADDED_BY")
	private String docAddedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="DOC_ADDED_ON")
	private Date docAddedOn;

	@Column(name="DOCUMENT_ID")
	private BigDecimal documentId;

	@Column(name="DOCUMENT_NAME")
	private String documentName;

	@Column(name="DOCUMENT_TYPE_NO")
	private BigDecimal documentTypeNo;

	@Column(name="IB_PROGRAM_NO")
	private BigDecimal ibProgramNo;

	@Temporal(TemporalType.DATE)
	private Date insdate;

	private String insuser;

	@Column(name="POLICY_SYS")
	private String policySys;

	@Column(name="POLICY_SYS_NO")
	private String policySysNo;

	private BigDecimal rowversion;

	@Temporal(TemporalType.DATE)
	private Date upddate;

	private String upduser;

	public TdocumentTracker() {
	}

	public long getDocumentTrackerNo() {
		return this.documentTrackerNo;
	}

	public void setDocumentTrackerNo(long documentTrackerNo) {
		this.documentTrackerNo = documentTrackerNo;
	}

	public BigDecimal getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(BigDecimal contractNo) {
		this.contractNo = contractNo;
	}

	public BigDecimal getDealNo() {
		return this.dealNo;
	}

	public void setDealNo(BigDecimal dealNo) {
		this.dealNo = dealNo;
	}

	public String getDocAddedBy() {
		return this.docAddedBy;
	}

	public void setDocAddedBy(String docAddedBy) {
		this.docAddedBy = docAddedBy;
	}

	public Date getDocAddedOn() {
		return this.docAddedOn;
	}

	public void setDocAddedOn(Date docAddedOn) {
		this.docAddedOn = docAddedOn;
	}

	public BigDecimal getDocumentId() {
		return this.documentId;
	}

	public void setDocumentId(BigDecimal documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return this.documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public BigDecimal getDocumentTypeNo() {
		return this.documentTypeNo;
	}

	public void setDocumentTypeNo(BigDecimal documentTypeNo) {
		this.documentTypeNo = documentTypeNo;
	}

	public BigDecimal getIbProgramNo() {
		return this.ibProgramNo;
	}

	public void setIbProgramNo(BigDecimal ibProgramNo) {
		this.ibProgramNo = ibProgramNo;
	}

	public Date getInsdate() {
		return this.insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}

	public String getInsuser() {
		return this.insuser;
	}

	public void setInsuser(String insuser) {
		this.insuser = insuser;
	}

	public String getPolicySys() {
		return this.policySys;
	}

	public void setPolicySys(String policySys) {
		this.policySys = policySys;
	}

	public String getPolicySysNo() {
		return this.policySysNo;
	}

	public void setPolicySysNo(String policySysNo) {
		this.policySysNo = policySysNo;
	}

	public BigDecimal getRowversion() {
		return this.rowversion;
	}

	public void setRowversion(BigDecimal rowversion) {
		this.rowversion = rowversion;
	}

	public Date getUpddate() {
		return this.upddate;
	}

	public void setUpddate(Date upddate) {
		this.upddate = upddate;
	}

	public String getUpduser() {
		return this.upduser;
	}

	public void setUpduser(String upduser) {
		this.upduser = upduser;
	}

}