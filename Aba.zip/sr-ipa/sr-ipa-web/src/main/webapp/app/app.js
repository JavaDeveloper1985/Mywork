var ipaWebApp = angular.module('ipa.ui', ['cmd.ui.framework']);

ipaWebApp.controller('AppController', ['$scope', '$location', '$rootScope', '$q', '$http', '$state', '$templateCache', 
                                       function($scope, $location, $rootScope, $q, $http, $state, $templateCache) {
	var urlParams = $location.search();
	$rootScope.debug = 'false';
	if(angular.isDefined(urlParams['debug']))
	{
		$rootScope.debug = urlParams['debug'];
	}
    $rootScope.policySuggestions = function(searchText){  
            var options = ['Under Construction..'];
            return options;
    };
    $rootScope.onPolicySelected = function(selectedPolicy) {
    };

    $templateCache.put('ui_mdmlookup.html',
            '<md-autocomplete class="mui-autocomplete" md-input-name="{{::field.name}}" md-selected-item="field.selectedItem" ' +
            	'md-search-text="field.searchText" md-items="item in queryOptions()" md-item-text="::getItemText(item)" ' + 
                'md-floating-label="{{::field.label}}" md-no-cache="true" ng-disabled="!field.updateable" ' +
                'mui-bind-actions invoke-action="invokeAction(action)" field-actions="::field.actions" ' + 
                'ipa-mdm-lookup md-min-length="minLength" md-delay="250" mui-validator validation-constraints="{{field.validation}}" ' +
                'mui-model="data[getEntityName(field.model)][getAttributeName(field.model,field.id)]" ' +
                'ng-class="{\'mui-mandatory-select\':field.mandatory}" ' +
                'ng-style="getCustomStyle(field.customStyle)"> ' +
        '<md-item-template><span md-highlight-text="field.searchText" ' +
                           'md-highlight-flags="i">{{::getItemLabel(item)}}</span> ' +
        '</md-item-template> ' +
        '<md-not-found>No matches found.</md-not-found> ' +
        '</md-autocomplete>');
    $templateCache.put('grid_mdmlookup.html',
    	    '<md-autocomplete class="mui-autocomplete" md-input-name="{{::field.name}}" md-selected-item="field.selectedItem"' +
    	                     'md-search-text="field.searchText" md-items="item in queryOptions()" md-item-text="::getItemText(item)"' + 
    	                     'md-floating-label="{{::field.label}}" md-no-cache="true" ng-disabled="!field.updateable"' +
    	                     'mui-bind-actions field-actions="::field.actions"' + 
    		                 'ipa-mdm-lookup md-min-length="minLength" md-delay="250" mui-validator validation-constraints="{{field.validation}}"' +
    	    'mui-model="::editData[field.model]" ng-class="{\'mui-mandatory-select\':field.mandatory}" ng-style="getCustomStyle(field.customStyle)">' +
    	        '<md-item-template><span md-highlight-text="field.searchText"' +
    	                                'md-highlight-flags="i">{{::getItemLabel(item)}}</span>' +
    	        '</md-item-template>' +
    	        '<md-not-found>No matches found.</md-not-found>' +
    	    '</md-autocomplete>');
    
    $scope.onInsuredSubmitted = function (eventData) {                
        $rootScope.reqCoSubmitted = true;        
        $rootScope.corpartInsuredId = eventData.insuredId;
        $rootScope.corpartInsuredName =  eventData.insuredName;        
        $state.go('newdraft.info', {programNo:$rootScope.firstStepData.Program.programNo});
    }
    
}]);

ipaWebApp.run(function(){
	
});

var frameWorkAppUrl = '/webapp/i12/ipa/';
var frameWorkLibUrl = '/webapp/i12/ipa/fw/';
