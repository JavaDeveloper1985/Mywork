dynPageGenModule.factory('ipasuggestions', ['$http',function($http) {
	var factory = {};
    
	factory.get = function(fieldConfig, queryString, queryType) {
        if(MUIUtils.isBlank(queryType)){
            queryType = '';
        }
        var resourceurl = frameWorkAppUrl + 'api/mdmresource?resourceType=' + fieldConfig.resourceType 
        + '&url=' + fieldConfig.url + '&searchQuery=' + queryString + '&queryType=' + queryType + '&blockingUI=false'; 
        if(MUIUtils.isNotBlank(fieldConfig.option1)){
            resourceurl = resourceurl + '&option1=' + fieldConfig.option1;
        }
        return $http.get(resourceurl);
    };
    
    return factory;
}]);    

