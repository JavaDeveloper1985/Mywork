ipaWebApp.directive('ipaMdmLookup', ['ipasuggestions', '$parse', '$q', '$timeout', '$filter', 
                                         function($ipasuggestions, $parse, $q, $timeout, $filter) {
    return {
        restrict: 'A',
        require: '?muiModel',
        link: function (scope, elem, attrs) {
            scope.field.selectedItems = [];
            var getItemCode = function(item){
                if(item == undefined){
                    return undefined;
                }
                return item['code'];
            };
            var selectedCodes = function(){
                var selecteItems = '';
                if(scope.field.selectedItems != undefined){
                    angular.forEach(scope.field.selectedItems, function(selectedItem){
                        if(selecteItems != '')
                            selecteItems = selecteItems + ',';
                        selecteItems = selecteItems + getItemCode(selectedItem);
                    });
                }
                return selecteItems;
            };
            var areSuggestionsEnabled = function(){
                return true;
            };
            var getElementScope = function() {
                var elementScope = scope;
                while(angular.isUndefined(elementScope.viewForm)){
                    elementScope = elementScope.$parent;
                }
                return elementScope;
            };
            var elementScope = getElementScope();            
            $timeout(function(){
                var inputElement = angular.element(elem[0].querySelector("input.md-input"));
                inputElement.bind("blur", function(){
                    $timeout(function() {
                       if(document.activeElement != inputElement[0] && scope.field.selectedItem == null){
                           scope.field.searchText = '';
                       }
                    }, 250);
                });    
                if(!attrs.muiMultiple){
                    var button = angular.element('<md-button>').addClass('clear-autocomplete');
                    button.append('<i class="material-icons">clear</i>');
                    elem.append(button);
                    scope.$watch('field.searchText', function(searchText) {
                        if (searchText && searchText !== '' && searchText !== null && scope.field.updateable) {
                            button.addClass('visible');
                        } else {
                            button.removeClass('visible');
                        }
                    });
                    button.on('click', function() {
                        $timeout(function() {
                            if(scope.formScope != undefined){
                               scope.formScope.viewForm.$setDirty();
                            } else {
                                scope.invokeAction.apply(null,[{action:{actionType:"SETDIRTY"}}]);
                            }
                            scope.field.searchText = '';
                            scope.field.selectedItem = undefined;
                        }, 0);
                    });                
                }
            },0);
            scope.minLength = 3; 
            scope.getItemText = function(item){
                return item['desc'];
            };
            scope.getItemLabel = function(item){
                return item['desc'];
            };
            scope.setSelectionToModel = function(){
                var modelSetter = $parse(attrs.muiModel).assign;   
                if(attrs.muiMultiple){                    
                    var selecteItems = selectedCodes();
                    modelSetter(scope,selecteItems);   
                } else {
                    if(scope.field.selectedItem != undefined){
                        modelSetter(scope,getItemCode(scope.field.selectedItem).toString());
                    } else {
                        modelSetter(scope,'');
                    }
                }
            };
            scope.$watch(function(){
                return attrs.muiMultiple?scope.field.selectedItems:scope.field.selectedItem;
            }, function(newVal, oldVal){
                   if(newVal != oldVal) {
                        scope.setSelectionToModel(); 
                   }
            }, true);
            scope.fieldConfig = {};
            scope.fieldConfig.resourceType = angular.fromJson(scope.field.lookupFieldConfig).resourceType;
            scope.fieldConfig.url = angular.fromJson(scope.field.lookupFieldConfig).url;
            scope.queryOptions = function(){
                    var deferred = $q.defer();
                    $ipasuggestions.get(scope.fieldConfig, scope.field.searchText, '').then(function (response){
                        deferred.resolve(response.data.filter(function(option){
                        var filterObject = {};
                        filterObject['code'] = getItemCode(option);
                        if(attrs.muiMultiple && $filter('filter')(scope.field.selectedItems,filterObject).length > 0)
                        	return false;
                        else return true;    
                        }));
                    });
                    return deferred.promise;
            };
            scope.$watch(attrs.muiModel,function(newVal, oldVal){
                var inputElement = angular.element(elem[0].querySelector("input.md-input"));
                if(!attrs.muiMultiple){
                    if(MUIUtils.isNotBlank(newVal) && (scope.field.selectedItem == undefined 
                                                   || newVal != getItemCode(scope.field.selectedItem))){
                        $ipasuggestions.get(scope.fieldConfig, newVal, 'CODE').then(function (response){
                            if(response.data[0] != undefined){
                                scope.field.selectedItem = response.data[0];
                            } 
                        });
                    }                     
                    if(MUIUtils.isNotBlank(oldVal) && MUIUtils.isBlank(newVal)){
                        scope.field.selectedItem = undefined;
                        if(document.activeElement != inputElement[0]){
                            scope.field.searchText = '';
                        }
                    }
                } else {
                    if(MUIUtils.isNotBlank(newVal) && newVal != selectedCodes()){ 
                        $ipasuggestions.get(scope.fieldConfig, newVal, 'CODE').then(function (response){ 
                            scope.field.selectedItems.length = 0;
                            scope.field.selectedItems = scope.field.selectedItems.concat(response.data);
                        });
                    }
                    if(MUIUtils.isNotBlank(oldVal) && MUIUtils.isBlank(newVal)){
                        scope.field.selectedItems = [];
                        if(document.activeElement != inputElement[0]){
                            scope.field.searchText = '';
                        }
                    }                    
                }
            }, true);
            scope.evaluateModel = function(model){
                var result = '';
                if(MUIUtils.isNotBlank(model)){
                    if(model.indexOf('editData.') == -1 && (model.slice(0,1) != "'" && model.slice(-1) != "'")){
                        return scope.$eval('data.'+model);
                    } else {
                        return scope.$eval(model);
                    }
                }
                return result;
            };
            scope.updateFieldConfig = function(){
               var fieldConfig = angular.fromJson(scope.field.lookupFieldConfig);
               scope.fieldConfig.resourceType = fieldConfig.resourceType;
               scope.fieldConfig.url = fieldConfig.url;
               scope.fieldConfig.option1 = scope.evaluateModel(fieldConfig.option1);
               scope.fieldConfig.option2 = scope.evaluateModel(fieldConfig.option2);
               scope.fieldConfig.option3 = scope.evaluateModel(fieldConfig.option3);
            };
            if(MUIUtils.isNotBlank(scope.field.lookupFieldConfig)){
               var fieldConfig = angular.fromJson(scope.field.lookupFieldConfig);
               scope.$watch(function(){
                   var option1 = scope.evaluateModel(fieldConfig.option1);
                   var option2 = scope.evaluateModel(fieldConfig.option2);
                   var option3 = scope.evaluateModel(fieldConfig.option3);
                   return option1+option2+option3;
               },function(newVal, oldVal){
            	   console.log(newVal);
            	   console.log(oldVal);
                   if(MUIUtils.isNotBlank(newVal) || newVal != oldVal){
                        scope.updateFieldConfig();
                        var searchString = scope.field.searchText;
                        var code = '';
                        if(MUIUtils.isNotBlank(scope.$eval(attrs.muiModel))){
                        	code = 'CODE';
                        	searchString = scope.$eval(attrs.muiModel);
                        }
                        
                        $ipasuggestions.get(scope.fieldConfig, searchString, code).then(function (response){
                            if(!angular.equals(scope.field.options, response.data)){
                                scope.field.options= angular.copy(response.data);
                                if(MUIUtils.isNotBlank(scope.$eval(attrs.muiModel)) && !attrs.muiMultiple){
                                    var filterObject = {};                                   
                                    filterObject['code'] = getItemCode(scope.field.selectedItem);
                                    if($filter('filter')(scope.field.options,filterObject).length == 0) {
                                        scope.field.selectedItem = undefined;
                                        scope.field.selectedItems = [];
                                        scope.field.searchText = '';
                                    }
                                }
                            }
                        });
                   }
               },true);    
               
            }            
        }
    };
}]);
