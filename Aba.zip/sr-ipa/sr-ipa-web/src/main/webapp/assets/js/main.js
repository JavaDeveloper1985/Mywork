System.register('boot', [
                         '@angular/upgrade', 
                         '@angular/core',                          
                         './insured-app/insured.form.component.js', 
                         './insured-app/app.module.js'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var upgrade_1, core_1, dist_1, app_module_1;
    var adapter;
    return {
    	setters:[
            function (upgrade_1_1) {
                upgrade_1 = upgrade_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (dist_1_1) {
                dist_1 = dist_1_1;
            },
            function (app_module_1_1) {
                app_module_1 = app_module_1_1;
            }],
        execute: function() {
        	adapter = new upgrade_1.UpgradeAdapter(core_1.forwardRef(function () { return app_module_1.AppModule; }));
            angular.module('ipa.ui').directive('insured', adapter.downgradeNg2Component(dist_1.InsuredFormComponent));
          
            bootstrapApp('ipa.ui');
            
            //adapter.bootstrap(document.body, ['integrationApp']);
        }
    }
    
    function bootstrapAng2Application() {
    	angular.element(document).ready(function () {
    		//angular.bootstrap(document, [frameWorkApp.mainAppName], {strictDi: true});
    		
    		adapter.bootstrap(document.body, [frameWorkApp.mainAppName]);
    	});
    }

    function bootstrapApp(appName, appSpecificLocales)
    {	
    	/* IE9 Hack */
    	if (!window.console) window.console = {};
    	if (!window.console.log) window.console.log = function () { };
    	/* IE9 Hack */
        if(MUIUtils.isNotBlank(appSpecificLocales)){
            supportedLocales = appSpecificLocales;
        }
    	frameWorkApp.mainAppName = appName;
        var appTheme = MUIUtils.getUrlParameter('theme');
        var appLocale = MUIUtils.getUrlParameter('locale');
        var appSettings = {appTheme:appTheme, appLocale:appLocale, supportedLocales: ['en-us']};
        var finalAppSettings = populateAppSettings(appSettings);
    	fetchAppConfig(finalAppSettings).then(bootstrapAng2Application);
    }
});
