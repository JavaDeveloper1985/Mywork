package com.swissre.prodcfg.jpa.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.CascadeType;

@Entity
@Table(name = "TPRODUCT")
@NamedQueries({
				@NamedQuery(name = "findproddetails", query = "select p from Product p where p.prodTypeCd = :pType "),
				@NamedQuery(name="findproddetailsbyid",query="select p from Product p where p.prodTypeCd = :pType and p.prodId = :pId")
				//@NamedQuery(name="maxprodid",query="select max(c.id.configver) from Configuration c where c.id.configId= :cId"),
				//@NamedQuery(name="deleteconfig",query="delete from Product c where c.id.configId= :cId")
})
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PROD_ID")
	@GeneratedValue(generator = "ProdSeq", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "ProdSeq", sequenceName = "SEQ_PROD_ID", allocationSize = 1)
	private long prodId;

	@Column(name = "PROD_NAME")
	private String prodName;

	@Column(name = "PROD_TYPE_CD")
	private String prodTypeCd;

	// bi-directional one-to-one association to TProductConfig
	@OneToOne(/*mappedBy = "product",*/ cascade=CascadeType.ALL)
	@JoinColumn(name="PROD_ID", referencedColumnName="PROD_ID")
		private ProductConfig productConfig;

	public Product() {
	}

	public long getProdId() {
		return this.prodId;
	}

	public void setProdId(long prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return this.prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdTypeCd() {
		return this.prodTypeCd;
	}

	public void setProdTypeCd(String prodTypeCd) {
		this.prodTypeCd = prodTypeCd;
	}

	public ProductConfig getProductConfig() {
		return this.productConfig;
	}

	public void setProductConfig(ProductConfig productConfig) {
		this.productConfig = productConfig;
	}

}