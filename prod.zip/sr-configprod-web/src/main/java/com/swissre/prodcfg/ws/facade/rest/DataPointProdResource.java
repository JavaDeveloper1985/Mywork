package com.swissre.prodcfg.ws.facade.rest;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.swissre.prodcfg.models.ProductData;

@Stateless
@LocalBean
@Path("/") 
public class DataPointProdResource {
	
	@EJB
	DataPointProdService datapointProdService;
	
	@POST
	@Path("/app/DataPointProducts")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addProductData(ProductData product) {
		System.out.println("inside path");
		ProductData  prod= datapointProdService.addProductData(product);
		return Response.status(200).entity(prod).build();
		
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/api/DataPointProducts")
	public Response getProductData() {
		System.out.println("inside get path");
		List<ProductData> configData = datapointProdService.getDataPointProd();
		return Response.status(200).entity(configData).build();

	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/api/DataPointProducts/{id}")
	public Response getProductDataById(@PathParam("id") String id) {
		System.out.println("inside get path");
		ProductData pData = datapointProdService.getDataPointProdById(Long.parseLong(id));
		return Response.status(200).entity(pData).build();

	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/app/DataPointProducts/{id}")
	public Response updateProductData(@PathParam("id") String id, ProductData product) {
		System.out.println("inside put path");
		product.setProductId(id);
		ProductData prod  = datapointProdService.putProductData(product);
		return Response.status(200).entity(prod).build();
		
	}
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/app/DataPointProducts/{id}")
	public Response deleteProductData(@PathParam("id") String id) {
		System.out.println("inside delete path");
		datapointProdService.deleteProductData(Long.parseLong(id));
		return Response.status(200).entity(id).build();
		
		
	}
}