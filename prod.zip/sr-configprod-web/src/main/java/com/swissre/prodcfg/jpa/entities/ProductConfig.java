package com.swissre.prodcfg.jpa.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TPRODUCT_CONFIG")
public class ProductConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PROD_ID",insertable=false, updatable=false)
	private long prodId;
	
	@Lob
	@Column(name = "PROD_CFG")
	private String prodCfg;

	// bi-directional one-to-one association to TProduct
	/*@MapsId("prodcId")
	@OneToOne
	@JoinColumn(name = "PROD_ID")
	private Product product;
*/
	public ProductConfig() {
	}

	public String getProdCfg() {
		return this.prodCfg;
	}

	public void setProdCfg(String prodCfg) {
		this.prodCfg = prodCfg;
	}

	/*public Product getProduct() {
		return this.product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}*/

}