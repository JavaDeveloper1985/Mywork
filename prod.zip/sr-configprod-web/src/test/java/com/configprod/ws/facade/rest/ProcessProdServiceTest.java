package com.configprod.ws.facade.rest;

import java.util.List;

import org.junit.Test;

public class ProcessProdServiceTest {
	
	@Test
	public void testgetProcessProd() {
		
	}

}
