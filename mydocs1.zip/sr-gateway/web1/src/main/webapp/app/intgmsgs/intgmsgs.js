var detailsModule = angular.module('mgw.admin.msgs', []);

detailsModule.controller('IntgmsgsCtrl', ['$scope','$http','$state', '$q', function($scope, $http, $state, $q) {
			$scope.query = {
				limit : 10,
				page : 1,
				filter: 'Failed'
			};
			$scope.filterOptions = { debounce: 500 };
			$scope.rowLimitOptions = [10,20,50];
			$scope.showFilter = true;
		  $scope.removeFilter = function () {
		    $scope.query.filter = '';	
		    $scope.showFilter = false;	    
		  };			
			$scope.showMessageDetails = function(msgId) {
				$state.go("intgmsgs.msgdetails", {
					msgId : msgId
				});
			};
			$scope.loadMessages = function(){
				 $scope.deferred = $http.get("api/messages" + '?' + jQuery.param($scope.query, true))
						.success(function(response) {
							$scope.failedMsgs = response.messages;
							$scope.totalCount = response.count;
						}).error(function(error) {
							console.log('Failed to load data for view - ' + error);
						});
			};
			$scope.getDataForExport = function(){
				 var tempQuery = {
					  limit : $scope.totalCount,
						page : 1,
						filter: $scope.query.filter,
						order: $scope.query.order
				 };
				 var deferred = $q.defer();
				 $http.get("api/messages" + '?' + jQuery.param(tempQuery, true)).success(function(response) {
				 			var dataForExport	= [];						
							dataForExport.push(['Message Id #','Source System','Integration Type','Status','Creation Date']);
							angular.forEach(response.messages, function (message) {
								dataForExport.push([message.messageId,message.sysName,message.integrationType,message.status,message.insdate]);
							});
							deferred.resolve(dataForExport);
						}).error(function(error) {
							deferred.reject(error);
						});
				 return deferred.promise;	
			};
			$scope.loadMessages();	
			$scope.onPaginationChange = function(){
					$scope.loadMessages();								
			};
			$scope.onOrderChange = function(){
				$scope.query.page = 1;
					$scope.loadMessages();								
			};
			$scope.$watch('query.filter', function (newValue, oldValue) {
				    if(newValue !== oldValue) {
				      $scope.query.page = 1;
				      $scope.loadMessages();			
				    }				    
			});
	}
]);

detailsModule.controller('MsgCtrl', ['$scope','$http','$stateParams','$rootScope','$state', 
																	function($scope, $http, $stateParams, $rootScope, $state) {
			$rootScope.$state.label = 'Integration Message - (' + $stateParams.msgId + ')';
			$scope.custom = {};
			$scope.requestDocSpec = {
									elements : {
										"messageId"   : { oneliner : true },
										"srcAppId"    : { oneliner : true },
										"user"        : { oneliner : true },
										"messageType" : { oneliner : true },
										"correlationId" : { oneliner : true },
										"att"		  : { oneliner : true }
									}
								};
								
			$http.get("api/messages/"+$stateParams.msgId).success(
							function(response) {
								$scope.messageDetails = response;
								$scope.renderXML('payload');
							}).error(function(error) {
						console.log('Failed to load data for view - ' + error);
					});
			
					$scope.click = function() {
								$scope.messageDetails.sample_response = Xonomy.harvest();
								return $http.post('api/messages/' + $scope.messageDetails.messageId,
										$scope.messageDetails).success(function(response) {
												$state.go('home');
										});
							};
							
			$scope.renderXML = function(xmlType) {
					if($scope.messageDetails != undefined){
						var rootElement=$(".xonomy .element").first().toArray()[0];
						if(rootElement !== undefined){
							rootElement.remove();
						}
						setTimeout(function(){
						   if(xmlType == 'payload') {
						   		Xonomy.editable = false;
									Xonomy.render($scope.messageDetails.payload,"payloadDiv", $scope.requestDocSpec);
						   } else if(xmlType == 'readOnlyResponse'){
						   		Xonomy.editable = false;
									Xonomy.render($scope.messageDetails.response,"readOnlyResponseDiv", $scope.requestDocSpec);
						   } else if(xmlType == 'response'){
						   		Xonomy.editable = true;
									Xonomy.render($scope.messageDetails.sample_response, "responseDiv", null);
						   }				    
						},0);
					}				
			};
	 } 
]);