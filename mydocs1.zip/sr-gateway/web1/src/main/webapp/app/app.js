var app = angular.module('mgw.admin', ['ngMaterial','ui.router','md.data.table',
                                       ,'mgw.admin.statistics','mgw.admin.msgs', 'ngCsv']);

app.controller('AppCtrl', ['$scope', '$mdSidenav', function ($scope, $mdSidenav) {
    $scope.buildToggler = function(navID) {
        $mdSidenav(navID).toggle();
    };
}]);

app.run(['$rootScope', function($rootScope){
    $rootScope.$on('$stateChangeSuccess',
        function(event, toState, toParams, fromState, fromParams){
            $rootScope.$state = toState;
        });
    $rootScope.appStates = appStates;
}]);

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider,   $urlRouterProvider) {
    $urlRouterProvider.otherwise('/');
    angular.forEach(appStates, function(appState){
     $stateProvider.state(appState.name,appState);
    });
}]);