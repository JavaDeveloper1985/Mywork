var statsModule = angular.module('mgw.admin.statistics', []);

statsModule.controller('StatisticsCtrl', ['$scope','$http', function ($scope,$http) {

			$scope.getDataForExport = function(){
		 			var dataForExport	= [];						
					dataForExport.push(['Source System','Integration Type','Target System','Inprogress(#)','Completed(#)','Failed(#)','Abandoned(#)']);
					angular.forEach($scope.statistics, function (info) {
								dataForExport.push([info.sysName,info.integrationType,info.targetSystem,info.inprogress,info.completed,info.failed,info.abandoned]);
					});
				 return dataForExport;	
			};
	
      $http.get("api/statistics/").success(function(response) {
    				  $scope.statistics = response;
			}).error(function(error) {
						console.log('Failed to load data for view - '  + error);
			});
}]);