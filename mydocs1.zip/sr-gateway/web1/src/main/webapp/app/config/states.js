var appStates = 
	[
	 	{
	 		name:"home",
	 		url:"/",
	 		templateUrl:"app/statistics/statistics.html",
	 		controller:"StatisticsCtrl",
	 		label:"Statistics",
	 		showInLeftMenu:true	
	 	},
	 	{
	 		name:"intgmsgs",
	 		url:"/intgmsgs",
	 		template:"<ui-view/>",
	 		abstract:true
	 	},
	 	{
	 		name:"intgmsgs.list",
	 		url:"",
	 		templateUrl:"app/intgmsgs/intgmsgs.html",
	 		controller:"IntgmsgsCtrl",
		 	label:"Integration Messages",
	 		showInLeftMenu:true	
	 	},
	 	{
	 		name:"intgmsgs.msgdetails",
	 		url:"/{msgId}",
	 		templateUrl:"app/intgmsgs/msgdetails.html",
	 		controller:"MsgCtrl",
	 		label:"Integration Message"
	 	}    
	 ];