package wasdev.sample.jms.web;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.annotation.Resource.AuthenticationType;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@Singleton
@Startup
@LocalBean
public class TestJMSClient {
	
/*	 @Resource(name = "jndi_JMS_BASE_QCF", type = javax.jms.ConnectionFactory.class, authenticationType = AuthenticationType.CONTAINER, mappedName = "jms/FOS/FOSJobResponseQueue_CF", shareable = true)
	QueueConnectionFactory qcf;

	  @Resource(name = "jms/FOS/jndi_INPUT_Q", type = javax.jms.Queue.class)
	Queue queue;
*/	
	@PostConstruct
	public void sendMessage() {// create a queue connection factory
		QueueConnectionFactory cf1;
		try {
			cf1 = (QueueConnectionFactory) new InitialContext()
			.lookup("jms/jmsQueueConnectionFactory");
		
		// create a queue by performing jndi lookup
		Queue queue = (Queue) new InitialContext()
		.lookup("jndi_INPUT_Q");

		// create a queue connection
		QueueConnection con = cf1.createQueueConnection();
		con.start();
		// create a queue sender
		QueueSession sessionSender = con.createQueueSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);

		QueueSender send = sessionSender.createSender(queue);

		TextMessage msg = sessionSender.createTextMessage();
		msg.setStringProperty("COLOR", "BLUE");
		String testMessage = "<?xml version=\"1.0\"?>" +
				"<integrationMessage>" +
					"<header>" +
						"<messageId>1230001</messageId>" +
						"<srcAppId>IPA</srcAppId>" +
						"<messageType>CREATE_LINE</messageType>" +
					"</header>	" +
					"<payload>" +
						"<sourceSystemKey>1234.1</sourceSystemKey>" +
						"<insuredNo>1111</insuredNo>" +
					"</payload>" +
				"</integrationMessage>";
		msg.setText(testMessage);

		send.send(msg);
		System.out.println("Message sent successfuly");

		if (con != null)
			con.close();
		System.out.println("SendMessage Completed");
		
		
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

}
