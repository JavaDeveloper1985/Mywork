package com.swissre.gateway.admin.rest;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

/**
 * Provides utility functionality to support REST Service Facades.
 */
public class RestParamUtils
{
    public static final String OUTPUT_PARAM = "output";

    private RestParamUtils()
    {
    }
    
    /**
     * "Collapse" the parameters in the given {@code UriInfo} by taking only the
     * first value of multi-valued parameters. Return the result as a
     * {@code Map} of name/value pairs.
     * 
     * @param uriInfo
     *            A JAX-RS representation of the request URI (including
     *            parameters).
     * @return A {@code Map} of name/value pairs.
     */
    public static Map<String, String> collapseParams(UriInfo uriInfo)
    {
        return collapseParams(uriInfo.getQueryParameters());
    }
    
    /**
     * "Collapse" the parameters in the given {@code MultivaluedMap} by taking
     * only the first value of multi-valued parameters. Return the result as a
     * {@code Map} of name/value pairs.
     * 
     * @param uriInfo
     *            A JAX-RS representation of the (potentially multi-valued)
     *            parameters in a request URI.
     * @return A {@code Map} of name/value pairs.
     */
    public static Map<String, String> collapseParams(MultivaluedMap<String, String> params)
    {
        Map<String, String> collapsedParams = new HashMap<String, String>();
        for (String key : params.keySet())
        {
            if (!params.get(key).isEmpty())
            {
                collapsedParams.put(key, params.getFirst(key));
            }
        }
        return collapsedParams;
    }

}
