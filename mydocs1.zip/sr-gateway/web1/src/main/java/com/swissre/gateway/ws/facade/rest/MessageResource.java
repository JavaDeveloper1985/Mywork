package com.swissre.gateway.ws.facade.rest;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import com.swissre.gateway.admin.rest.RestErrorHandlingInterceptor;
import com.swissre.gateway.admin.rest.RestParamUtils;
import com.swissre.gateway.admin.rest.RestURIs;
import com.swissre.gateway.jpa.entities.MessageDetail;
import com.swissre.gateway.rest.domain.MessagesList;
import com.swissre.gateway.service.IntegrationMessageService;
import com.swissre.gateway.util.AppException;


/**
 * A Service Facade that exposes {@code LineInfoService} functionality through a
 * RESTful web service.
 */
@Stateless
@LocalBean
@Path(RestURIs.Message) /* Also list this class in RestApplication.getClasses()! */
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
@Interceptors({RestErrorHandlingInterceptor.class})
public class MessageResource {
	
	@EJB
	IntegrationMessageService messageService;

	@GET
	@Produces({APPLICATION_JSON})
	public MessagesList getfailedMessages(@Context UriInfo uriInfo) throws AppException {
		Map<String, String> queryParams = RestParamUtils.collapseParams(uriInfo);
		
		return messageService.getfailedMessage(queryParams);
	}
	
	
	@GET
	@Produces({APPLICATION_JSON})
	@Path("/{messageId}")
	public MessageDetail getMessageDetail(@PathParam("messageId") String messageId) throws AppException{
		return messageService.getMessageDetail(messageId);
	}
	
	
	@POST
	@Produces({APPLICATION_JSON})
	@Path("/{messageId}")
	public void processFailedMessage(@PathParam("messageId") String messageId, final MessageDetail messageDetail) throws AppException{
		messageService.processFailedMessage(messageDetail);
	}
}
