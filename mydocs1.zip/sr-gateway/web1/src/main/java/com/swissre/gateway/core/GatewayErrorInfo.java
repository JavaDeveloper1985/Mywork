package com.swissre.gateway.core;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import com.swissre.gateway.rest.domain.Namespace;

/**
 * Holds information about an error that occurred during the processing of a
 * request. All properties of this class are returned in SOAP faults and REST
 * error responses.
 * 
 * @see com.swissre.gateway.core.rest.RestError
 * @see com.swissre.gateway.core.soap.GatewayFault
 */
@XmlType(name="GatewayFaultDetail", namespace=Namespace.GATEWAY, propOrder = {
        "timestamp",
        "msgId",
        "opSeqNo",
        "operationId",
        "stackTrace",
        "format"
})
public class GatewayErrorInfo implements Serializable
{
    private static final long serialVersionUID = 1L;
    
    private Date timestamp;
    private String msgId;
    private int opSeqNo = 1;
    private BigInteger operationId;
    private String stackTrace;
    @XmlTransient
    private String format;
    
    public GatewayErrorInfo()
    {
        this(new Date(), null);
    }
    
    public GatewayErrorInfo(Throwable throwable)
    {
        this(new Date(), throwable);
    }

    public GatewayErrorInfo(Date timestamp, Throwable throwable)
    {
        this.timestamp = timestamp; 
        this.stackTrace = toStackTrace(throwable);
    }

    public Date getTimestamp()
    {
        return timestamp;
    }

    public void setTimestamp(Date timestamp)
    {
        this.timestamp = timestamp;
    }

    public String getMsgId()
    {
        return msgId;
    }

    public void setMsgId(String msgId)
    {
        this.msgId = msgId;
    }

    public int getOpSeqNo()
    {
        return opSeqNo;
    }

    public void setOpSeqNo(int opSeqNo)
    {
        this.opSeqNo = opSeqNo;
    }

    public BigInteger getOperationId()
    {
        return operationId;
    }

    public void setOperationId(BigInteger operationId)
    {
        this.operationId = operationId;
    }

    public String getStackTrace()
    {
        return stackTrace;
    }
    
    public void setStackTrace(String stackTrace)
    {
        this.stackTrace = stackTrace;
    }

    private String toStackTrace(Throwable throwable)
    {
        String trace = null;
        
        if (throwable != null)
        {
            String[] stackFrames = ExceptionUtils.getStackFrames(throwable);
            return StringUtils.join(stackFrames, '\n');
        }
        
        return trace;
    }

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

}
