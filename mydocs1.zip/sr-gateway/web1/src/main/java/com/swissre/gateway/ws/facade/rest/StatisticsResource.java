package com.swissre.gateway.ws.facade.rest;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.swissre.gateway.admin.rest.RestErrorHandlingInterceptor;
import com.swissre.gateway.admin.rest.RestURIs;
import com.swissre.gateway.jpa.entities.IntegrationData;
import com.swissre.gateway.service.StatisticsService;
import com.swissre.gateway.util.AppException;


/**
 * A Service Facade that exposes {@code LineInfoService} functionality through a
 * RESTful web service.
 */
@Stateless
@LocalBean
@Path(RestURIs.STATISTICS) /* Also list this class in RestApplication.getClasses()! */
@Interceptors({RestErrorHandlingInterceptor.class})
public class StatisticsResource {
	
	@EJB
	StatisticsService statisticsService;

	@GET
	@Produces({APPLICATION_JSON})
	public List<IntegrationData> getStatistics() throws AppException {
		return statisticsService.getStatistics();
	}
	

	
}
