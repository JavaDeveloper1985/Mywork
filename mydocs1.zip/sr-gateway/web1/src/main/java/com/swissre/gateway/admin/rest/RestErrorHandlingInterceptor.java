package com.swissre.gateway.admin.rest;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.swissre.gateway.core.GatewayErrorFactory;
import com.swissre.gateway.core.GatewayErrorInfo;
import com.swissre.gateway.core.GatewayErrorProcessor;
import com.swissre.gateway.core.GatewayValidationException;

/**
 * An interceptor used to centralize error handling for all RESTful services.
 */
@Interceptor
public class RestErrorHandlingInterceptor
{
    private GatewayErrorProcessor<RestError> errorProcessor;
    
    // Interceptors MUST have a public no-arg constructor.
    public RestErrorHandlingInterceptor()
    {
    	GatewayErrorFactory<RestError> errorFactory = new RestErrorFactory();
        this.errorProcessor = new GatewayErrorProcessor<RestError>(errorFactory);
    }
    
    /**
     * An "around-invoke" interceptor method that converts any {@code Throwable}
     * thrown by the target object into a {@code WebApplicationException}, which
     * will be used by the JAX-RS runtime to construct a suitable response.
     * 
     * @param context
     *            The interceptor chain's context.
     * @return The return value of the targeted method.
     * @throws Exception
     *             Should only ever throw a {@code WebApplicationException} (but
     *             the method signature must declare {@code throws Exception}).
     */
    @AroundInvoke
    public Object errorHandlingInvocation(InvocationContext context) throws Exception
    {
        try
        {
            return context.proceed();
        }
        catch (Throwable t)
        {
            RestError error = errorProcessor.createErrorObject(t);
            
            ResponseBuilder responseBuilder;
            
            // Use a status code of 400 for validation errors and 500 for all others.
            if (error.isValidationError())
            {
                responseBuilder = Response.status(BAD_REQUEST);
            }
            else
            {
                responseBuilder = Response.serverError();
            }
            Response response ;
            if (null != error.getDetail().getFormat()
					&& error.getDetail().getFormat().equalsIgnoreCase("JSON")) {
            	response = responseBuilder
                .type(APPLICATION_JSON)
                .entity(error)
                .build();	
            }else{
            // Now build the response using the error XML.
            response = responseBuilder
                    .type(APPLICATION_XML)
                    .entity(error)
                    .build();
            }
            
            // Wrap and throw in a JAX-RS exception...
            throw new WebApplicationException(t, response);
        }
    }

    /**
     * A class that we'll use in conjunction with the {@code GatewayErrorProcessor}
     * to create {@code RestError} objects.
     */
    private static class RestErrorFactory implements GatewayErrorFactory<RestError>
    {
        @Override
        public RestError create(String errorMessage, GatewayErrorInfo errorDetail,
                Throwable baseCause, Throwable rootCause)
        {
            RestError restError = new RestError(errorMessage, errorDetail);
            restError.setValidationError(baseCause instanceof GatewayValidationException);
            return restError;
        }
    }
}
