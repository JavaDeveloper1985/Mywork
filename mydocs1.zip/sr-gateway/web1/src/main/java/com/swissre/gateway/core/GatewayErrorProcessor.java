package com.swissre.gateway.core;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.EJBException;

import com.swissre.gateway.util.AppException;

/**
 * Contains centralized error handling logic for all gateway services.
 * 
 * @param <T>
 *            The type of object used to hold information about an error, which
 *            differs between the SOAP and RESTful services.
 * 
 * @see com.swissre.gateway.core.GatewayErrorFactory
 * @see com.swissre.gateway.core.rest.RestErrorHandlingInterceptor
 * @see com.swissre.gateway.core.soap.interceptors.SoapErrorHandlingInterceptor
 */
public class GatewayErrorProcessor<T>
{
    private static final Logger logger = Logger.getLogger(GatewayErrorProcessor.class.getName());

    private static final int ORA_CODE_MIN = 20000;
    private static final int ORA_CODE_MAX = 20999;
    
    /** Offset of gateway error codes relative to Oracle error codes. */
    private static final int Gateway_CODE_OFFSET = 20000;
    
    private static final String ORA_ERR_REGEX = "ORA-(\\d+):\\s(.*)";
    private static final Pattern oracleErrorPattern = Pattern.compile(ORA_ERR_REGEX);

    private final GatewayErrorFactory<T> errorFactory;
    
    public GatewayErrorProcessor(GatewayErrorFactory<T> errorFactory)
    {
        this.errorFactory = errorFactory;
    }
    
    /**
     * Create an object of type {@code T} to provide a client view of the given
     * error.
     * 
     * @param throwable
     *            An exception that was thrown while processing a request.
     * @return An object holding the information we'll return to the client.
     *         (Different types for SOAP vs. REST.)
     */
    public T createErrorObject(Throwable throwable)
    {
        Throwable cause = null;     // the top-level Throwable that we'll report to clients
        Throwable rootCause = null; // the last Throwable in the chain
        
        while (throwable != null)
        {
            rootCause = throwable;
            
            try
            {
                throw throwable;
            }
            catch (EJBException e)
            {
                // Don't treat an EJBException as the cause
                // unless it's the end of the exception chain.
                if (cause == null && e.getCausedByException() == null)
                {
                    cause = e;
                }
                
                // Use the getCausedByException() method to get the next exception in
                // the chain, since the getCause() method of EJBException sometimes
                // returns null even though other exceptions are still in the chain.
                throwable = e.getCausedByException();
            }
            catch (Throwable t)
            {
                if (cause == null)
                {
                    cause = t;
                }
                
                throwable = t.getCause();
            }
        }
        
        return createErrorObject(cause, rootCause);
    }
    
    private T createErrorObject(Throwable cause, Throwable rootCause)
    {
        logger.fine("CAUSE:      [" + cause + "]");
        logger.fine("ROOT CAUSE: [" + rootCause + "]");

        String faultMessage = null;
        boolean businessError = false;
                
        if (rootCause instanceof SQLException)
        {
            String rootCauseMsg = new Scanner(rootCause.getMessage()).nextLine();
            Matcher matcher = oracleErrorPattern.matcher(rootCauseMsg);
            
            if (matcher.matches())
            {
                int oracleErrorCode = Integer.parseInt(matcher.group(1));
                String errorMsg = matcher.group(2);
                faultMessage = rootCauseMsg;
            }
        }
        
        if (faultMessage == null)
        {
            faultMessage = cause.toString();
        }
        
        // Show the stack trace in the detail section of the fault *unless* it's a
        // GatewayValidationException or a business error with a Gateway error code.
        Throwable stackTraceToShow = null;
        if (!businessError && !(cause instanceof GatewayValidationException))
        {
            stackTraceToShow = cause;
        }
        
        GatewayErrorInfo faultBean = new GatewayErrorInfo(stackTraceToShow);
        
        if (cause instanceof AppException)
        {
        	AppException me = (AppException) cause;
            faultBean.setMsgId(me.getMsgId());
            faultBean.setOpSeqNo(me.getOpSeqNo());
            faultBean.setOperationId(me.getOperationId());
            faultBean.setFormat(me.getFormat());
        }
        
        return errorFactory.create(faultMessage, faultBean, cause, rootCause);
    }
    
}
