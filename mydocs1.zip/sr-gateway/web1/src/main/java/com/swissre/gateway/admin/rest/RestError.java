package com.swissre.gateway.admin.rest;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import com.swissre.gateway.core.GatewayErrorInfo;
import com.swissre.gateway.rest.domain.Namespace;

/**
 * The top-level JAXB type for reporting error information from the RESTful
 * services. Each service returns XML marshaled from an instance of this type
 * whenever an error occurs.
 */
@XmlType(name="RestError", namespace=Namespace.GATEWAY, propOrder = {
        "message",
        "detail"
})
@XmlRootElement(name="error", namespace=Namespace.GATEWAY)
public class RestError
{
    private String message;
    private GatewayErrorInfo detail;

    @XmlTransient
    private boolean validationError;
    
    public RestError()
    {
        this("");
    }

    public RestError(String message)
    {
        this(message, null);
    }

    public RestError(String message, GatewayErrorInfo detail)
    {
        this.message = message;
        this.detail = detail;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public GatewayErrorInfo getDetail()
    {
        return detail;
    }

    public void setDetail(GatewayErrorInfo detail)
    {
        this.detail = detail;
    }

    @XmlTransient
    public boolean isValidationError()
    {
        return validationError;
    }

    public void setValidationError(boolean validationError)
    {
        this.validationError = validationError;
    }

}
