package com.swissre.gateway.service;

import static javax.ejb.TransactionAttributeType.MANDATORY;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;

import com.swissre.gateway.data.access.DataAccessService;
import com.swissre.gateway.jpa.entities.IntegrationData;

@Stateless
@LocalBean
@TransactionAttribute(MANDATORY)
public class StatisticsService {

	@EJB
	DataAccessService dataAccessService;

	public List<IntegrationData> getStatistics() {
		List<IntegrationData> integrationDatas = dataAccessService
				.findWithNamedQuery(IntegrationData.class,
						"IntegrationMessage.getStatistics");
		return integrationDatas;
	}

}
