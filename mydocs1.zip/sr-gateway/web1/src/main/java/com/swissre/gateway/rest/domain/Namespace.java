package com.swissre.gateway.rest.domain;


/**
 * Enumerates the XML namespaces used in the Gateway domain model.
 */
public interface Namespace
{
    final String GATEWAY  = "http://www.swissre.com/gateway";
}
