package com.swissre.gateway.admin.rest;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.apache.wink.server.handlers.HandlersChain;
import org.apache.wink.server.handlers.MessageContext;
import org.apache.wink.server.handlers.RequestHandler;
import org.apache.wink.server.handlers.ResponseHandler;

/**
 * An Apache Wink request/response handler that logs information about each request and
 * response. This class must be returned by the {@code RestHandlersFactory} to plug it
 * into the Wink handler chain.
 * 
 * NOTE: This class makes use of Apache Wink APIs, which is not ideal.  However, the
 * version of JAX-RS supported by WebSphere Application Server v8 does not support handlers.
 * Support for handlers will be added to JAX-RS in a future release of the specification.
 * When standard JAX-RS handlers are supported on WebSphere, this class should be refactored
 * to use the standard APIs.
 * 
 * @see RestHandlersFactory
 * @see org.apache.wink.server.handlers.RequestHandler
 * @see org.apache.wink.server.handlers.ResponseHandler
 */
public class RestLoggingHandler implements RequestHandler, ResponseHandler
{
    private static final Logger logger = Logger.getLogger(RestLoggingHandler.class.getName());
    
    private Level messageLogLevel = Level.INFO; // TODO Make the message log level configurable.

    /* (non-Javadoc)
     * @see org.apache.wink.server.handlers.Handler#init(java.util.Properties)
     */
    @Override
    public void init(Properties initProps)
    {
    }

    /**
     * Logs information about a RESTful request.
     * 
     * @see org.apache.wink.server.handlers.RequestHandler#handleRequest(org.apache.wink.server.handlers.MessageContext, org.apache.wink.server.handlers.HandlersChain)
     */
    @Override
    public void handleRequest(MessageContext messageCtx, HandlersChain chain)
            throws Throwable
    {
        logUri("REQUEST", messageCtx);
        logHeaders(messageCtx);
        
        chain.doChain(messageCtx);
    }

    /**
     * Logs information about a RESTful response.
     * 
     * @see org.apache.wink.server.handlers.ResponseHandler#handleResponse(org.apache.wink.server.handlers.MessageContext, org.apache.wink.server.handlers.HandlersChain)
     */
    @Override
    public void handleResponse(MessageContext messageCtx, HandlersChain chain)
            throws Throwable
    {
        logUri("RESPONSE", messageCtx);
        logStatus(messageCtx);
        
        chain.doChain(messageCtx);
    }

    private void logUri(String messageType, MessageContext messageCtx)
    {
        UriInfo info = messageCtx.getUriInfo();
        
        logger.log(
                messageLogLevel,
                String.format("[REST %s] %s %s", messageType,
                        messageCtx.getHttpMethod(), info.getRequestUri()));
    }

    private void logHeaders(MessageContext messageCtx)
    {
        HttpHeaders headers = messageCtx.getHttpHeaders();
        if (headers != null)
        {
            MultivaluedMap<String, String> headerMap = headers.getRequestHeaders();
            for (String name : headerMap.keySet())
            {
                String values = StringUtils.join(headerMap.get(name), ',');
                logger.log(messageLogLevel, String.format("[HEADER] %s: %s", name, values));
            }
        }
    }

    private void logStatus(MessageContext messageCtx)
    {
        String status;
        int code = messageCtx.getResponseStatusCode();
        Response.Status responseStatus = Response.Status.fromStatusCode(code);

        if (responseStatus == null)
        {
            status = Integer.toString(code);
        }
        else
        {
            status = String.format("%d %s", code, responseStatus.getReasonPhrase());
        }
        
        logger.log(messageLogLevel, "[STATUS] " + status);
    }

}
