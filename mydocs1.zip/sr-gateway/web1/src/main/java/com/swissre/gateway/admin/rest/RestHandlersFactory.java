package com.swissre.gateway.admin.rest;

import java.util.Arrays;
import java.util.List;

import org.apache.wink.server.handlers.HandlersFactory;
import org.apache.wink.server.handlers.RequestHandler;
import org.apache.wink.server.handlers.ResponseHandler;

/**
 * Extends the Apache Wink {@code HandlersFactry} class to plug in the
 * {@code RestLoggingHandler} to log REST requests and responses.
 * 
 * This class must be specified in the {@code rest.properties} file.
 * 
 * NOTE: Future versions of the JAX-RS spec will allow us to accomplish
 * the same thing without relying on Wink APIs.
 * 
 * @see rest.properties
 * @see RestLoggingHandler
 * @see org.apache.wink.server.handlers.HandlersFactory
 */
public class RestHandlersFactory extends HandlersFactory
{
    public RestHandlersFactory()
    {
    }
    
    /* (non-Javadoc)
     * @see org.apache.wink.server.handlers.HandlersFactory#getRequestHandlers()
     */
    @Override
    public List<? extends RequestHandler> getRequestHandlers()
    {
        return Arrays.asList(new RestLoggingHandler());
    }
    
    /* (non-Javadoc)
     * @see org.apache.wink.server.handlers.HandlersFactory#getResponseHandlers()
     */
    @Override
    public List<? extends ResponseHandler> getResponseHandlers()
    {
        return Arrays.asList(new RestLoggingHandler());
    }
    
}
