package com.swissre.gateway.rest.domain;

import java.util.List;

import com.swissre.gateway.jpa.entities.IntegrationMessageDetail;

public class MessagesList {
	
	private int count;
	
	private List<IntegrationMessageDetail> messages;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<IntegrationMessageDetail> getMessages() {
		return messages;
	}

	public void setMessages(List<IntegrationMessageDetail> messages) {
		this.messages = messages;
	}

}
