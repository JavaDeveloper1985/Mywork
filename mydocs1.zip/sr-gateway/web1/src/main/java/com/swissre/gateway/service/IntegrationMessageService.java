package com.swissre.gateway.service;

import static com.swissre.gateway.data.access.QueryParameter.with;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.StringUtils;

import com.swissre.gateway.data.access.DataAccessService;
import com.swissre.gateway.jpa.entities.IntegrationMessage;
import com.swissre.gateway.jpa.entities.IntegrationMessageDetail;
import com.swissre.gateway.jpa.entities.MessageDetail;
import com.swissre.gateway.jpa.entities.MessageResponse;
import com.swissre.gateway.jpa.entities.MessageStatusEnum;
import com.swissre.gateway.rest.domain.IntegrationMsgResponse;
import com.swissre.gateway.rest.domain.MessagesList;
import com.swissre.gateway.service.helper.MessageServiceHelper;
import com.swissre.gateway.util.AppException;
import com.swissre.gateway.util.ServiceConstants;

@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IntegrationMessageService {

	@EJB
	DataAccessService dataAccessService;

	@EJB
	MessageServiceHelper serviceHelper;

	
	@SuppressWarnings("unchecked")
	public MessagesList getfailedMessage(Map<String, String> queryParams) {
		MessagesList messagesList = new MessagesList();
		String namedQuery = "IntegrationMessage.getIntegrationMessagesDesc";
		if(StringUtils.isBlank(queryParams.get(ServiceConstants.FILTER))){
			queryParams.put(ServiceConstants.FILTER,"");
		}
		String orderBy = "insdate";
		String order = queryParams.get(ServiceConstants.ORDER);
		if(StringUtils.isNotBlank(order)){
			if(order.startsWith("-"))
			{
				order = order.substring(1);			
			}
			else
			{
				namedQuery = "IntegrationMessage.getIntegrationMessagesAsc";				
			}
			orderBy = order;
		}
		int pageNum = Integer.parseInt(queryParams.get(ServiceConstants.PAGE));
		int limit = Integer.parseInt(queryParams.get(ServiceConstants.LIMIT));
		int firstResultCount = ((pageNum - 1) * limit); 
		Query query = dataAccessService.getEntityManager()
					.createNamedQuery(namedQuery, IntegrationMessageDetail.class)
					.setParameter(ServiceConstants.FILTER, "%"+queryParams.get(ServiceConstants.FILTER).toUpperCase()+"%")
					.setParameter("field", orderBy);
		query.setFirstResult(firstResultCount);
		query.setMaxResults(limit);
		List<IntegrationMessageDetail> failedMessages = query.getResultList();
		int totoalReusltCount = ((Number)dataAccessService.getEntityManager()
						.createNamedQuery("IntegrationMessage.getIntegrationMessagesCount")
						.setParameter(ServiceConstants.FILTER, "%"+queryParams.get(ServiceConstants.FILTER).toUpperCase()+"%")
						.getSingleResult()).intValue();
		messagesList.setCount(totoalReusltCount);
		messagesList.setMessages(failedMessages);
		return messagesList;
	}
	
	public MessageDetail getMessageDetail(String messageId){
		MessageDetail messageDetail = dataAccessService
		.findSingleResultWithNamedQuery(MessageDetail.class,
				"IntegrationMessage.getIntegrationMessageDetail",
				with("messageId", messageId).parameters());
		return messageDetail;
	}
	
	public void processFailedMessage(MessageDetail messageDetail) {
		IntegrationMsgResponse msgResponse = serviceHelper
				.createResponseMsg(messageDetail);
		JAXBContext jaxbContext;
		StringWriter writer = new StringWriter();
		String responseXML = null;
		try {
			jaxbContext = JAXBContext.newInstance(IntegrationMsgResponse.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.marshal(msgResponse, writer);
			responseXML = serviceHelper.updateResponseXML(writer.toString(),messageDetail);
		} catch (JAXBException e) {
			throw new AppException("Error occured while marshalling data");
		}
		serviceHelper.sendMessageToQueue(responseXML,messageDetail);
		updateMessageStatus(responseXML,messageDetail);
	}


	private void updateMessageResponse(String responseXML,
			MessageDetail messageDetail, IntegrationMessage integrationMessage) {
		MessageResponse messageResponse = dataAccessService.find(MessageResponse.class, messageDetail.getMessageId());
		if(null != messageResponse){
			messageResponse.setResponse(responseXML);
			dataAccessService.update(messageResponse);
		}else{
			messageResponse = new MessageResponse();
			messageResponse.setMessageId(messageDetail.getMessageId());
			messageResponse.setResponse(responseXML);
			messageResponse.setIntegrationMessage(integrationMessage);
			dataAccessService.create(messageResponse);
		}
	}

	private void updateMessageStatus(String responseXML, MessageDetail messageDetail) {
		IntegrationMessage integrationMessage = dataAccessService.find(IntegrationMessage.class, messageDetail.getMessageId());
		integrationMessage.setMessageStatus(MessageStatusEnum.COMPLETED.getId());
		dataAccessService.update(integrationMessage);
		updateMessageResponse(responseXML,messageDetail,integrationMessage);
	}
}
