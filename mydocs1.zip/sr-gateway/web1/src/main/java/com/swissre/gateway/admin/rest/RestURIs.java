package com.swissre.gateway.admin.rest;

/**
 * Defines the base resource URIs supported by the RESTful services. URIs are relative
 * to the web path of the REST servlet (i.e., {@code javax.ws.rs.core.Application}).
 */
public interface RestURIs
{
    final String STATISTICS = "/statistics";
    final String Message = "/messages";    
}
