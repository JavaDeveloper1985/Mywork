package com.swissre.gateway.service.helper;

import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultCamelContext;
import org.json.JSONObject;

import com.swissre.gateway.jpa.entities.MessageDetail;
import com.swissre.gateway.rest.domain.Header;
import com.swissre.gateway.rest.domain.IntegrationMsgResponse;
import com.swissre.gateway.service.UserService;
import com.swissre.gateway.util.ServiceConstants;

@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class MessageServiceHelper {
	

	private static final Logger logger = Logger.getLogger(MessageServiceHelper.class.getName());
	
	
	@EJB
	UserService userService;
	
	public IntegrationMsgResponse createResponseMsg(MessageDetail messageDetail) {
		IntegrationMsgResponse msgResponse = new IntegrationMsgResponse();
		Header header = new Header();
		header.setMessageType(messageDetail.getResponseType());
		header.setMessageId(UUID.randomUUID().toString());
		header.setCorrelationId(messageDetail.getMessageId());
		header.setSrcAppId(messageDetail.getSrcAppId());
		header.setUser(userService.getLoggedInUserId());
		msgResponse.setHeader(header);
		return msgResponse;
	}

	public void sendMessageToQueue(String responseXML, MessageDetail messageDetail) {
		JSONObject jsonObject = new JSONObject(messageDetail.getEndpoint());
		logger.info(responseXML);
		StringBuffer endpointUrl = null;
		if(jsonObject.has(ServiceConstants.ENDPOINT_URL)){
			endpointUrl = new StringBuffer(jsonObject.getString(ServiceConstants.ENDPOINT_URL));
		}
/*		addOptionalParam(endpointUrl, ServiceConstants.USERNAME,
				SecurityUtils.getTechUserId());
		addOptionalParam(endpointUrl, ServiceConstants.PASSWORD,
				SecurityUtils.getTechPassword());
		addOptionalParam(endpointUrl, ServiceConstants.CACHELEVELNAME,
				ServiceConstants.CACHENONE);
*/		CamelContext camelContext = new DefaultCamelContext();
		try {
			camelContext.start();
			ProducerTemplate template = camelContext.createProducerTemplate();
			template.sendBody(endpointUrl.toString(), responseXML);
			camelContext.stop();
		} catch (Exception ex) {
			logger.log(Level.SEVERE,
					"An error occurred while stopping the camel context.", ex);
		}
	}

	public String updateResponseXML(String responseXML,
			MessageDetail messageDetail) {
		String header = responseXML.substring(0,
				responseXML.lastIndexOf(ServiceConstants.HEADER)
						+ ServiceConstants.HEADER.length());
		header = header
				+ messageDetail.getSample_response()
				+ responseXML.substring(
						responseXML.lastIndexOf(ServiceConstants.HEADER)
								+ ServiceConstants.HEADER.length(),
						responseXML.length());
		return header;
	}

	private void addOptionalParam(StringBuffer endpointUrl, String paramName,
			String paramValue) {
		endpointUrl.append(ServiceConstants.AMPERSAND).append(paramName)
				.append(ServiceConstants.EQUAL).append(paramValue);
	}
}
