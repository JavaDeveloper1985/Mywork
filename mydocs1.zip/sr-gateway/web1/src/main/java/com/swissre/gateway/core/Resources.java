package com.swissre.gateway.core;

/**
 * Defines constants for the JNDI names of resources needed by this application.
 */
public interface Resources
{
    final String DATABASE = "java:comp/env/jdbc/gateway";
}
