package com.swissre.gateway.core;

/**
 * A generic interface for creating error objects of type {@code T}, given
 * information about the error. This interface is used by
 * {@code GatewayErrorProcessor}, which contains error-handling logic that is shared
 * across the SOAP and RESTful services. These service types report error
 * information through different types of objects, hence the need for this
 * generic interface.
 * 
 * The SOAP service code implements this interface to create {@code GatewayFault}
 * exceptions, while the RESTful service code implements this interface to
 * create {@code RestError} JAXB objects.
 * 
 * @param <T>
 *            The type of error object to create.
 * 
 * @see com.swissre.gateway.core.GatewayErrorProcessor
 * @see com.swissre.gateway.core.rest.RestErrorHandlingInterceptor
 * @see com.swissre.gateway.core.soap.interceptors.SoapErrorHandlingInterceptor
 */
public interface GatewayErrorFactory<T>
{
    /**
     * Create an object of type {@code T} with the given error information.
     * 
     * @param errorMessage The error message.
     * @param errorDetail The error detail.
     * @param cause The top-level exception of the exception chain.
     * @param rootCause The root of the exception chain.
     * @return An instance of {@code T}.
     */
    T create(String errorMessage, GatewayErrorInfo errorDetail, Throwable cause, Throwable rootCause);
}
