package com.swissre.gateway.core;

import com.swissre.gateway.util.AppException;

/**
 * An exception class used to indicate that the client's request was in some way
 * invalid.
 */
public class GatewayValidationException extends AppException
{
    private static final long serialVersionUID = 1L;

    public GatewayValidationException(String detail)
    {
        super(detail);
    }

    public GatewayValidationException(String detail, Throwable rootCause)
    {
        super(detail, rootCause);
    }
    
    public GatewayValidationException(String detail, Throwable rootCause,String format)
    {
        super(detail, rootCause, format);
    }
}
