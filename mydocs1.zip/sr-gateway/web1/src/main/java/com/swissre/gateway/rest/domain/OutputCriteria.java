package com.swissre.gateway.rest.domain;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Specifies criteria for the desired output of a search. This class has
 * mappings to XML (via JAXB).
 */
@XmlType
public class OutputCriteria
{
    @XmlElement(name="item")
    private List<String> items;

    /** Constructs an empty {@code OutputCriteria} instance. */
    public OutputCriteria()
    {
    }

    /**
     * Constructs an {@code OutputCriteria} instance containing the given list
     * of desired output attributes.
     */
    public OutputCriteria(List<String> items)
    {
        this.items = items;
    }

    /**
     * Gets the value of the items property. This property holds a
     * list of all attributes of each found entity that should appear
     * in a search's results.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a {@code set} method for the items property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getItems().add(newItem);
     * </pre>
     */
    public List<String> getItems()
    {
        if (items == null)
        {
            items = new ArrayList<String>(20);
        }
        
        return items;
    }

}
