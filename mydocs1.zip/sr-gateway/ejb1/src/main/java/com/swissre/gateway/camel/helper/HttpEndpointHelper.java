package com.swissre.gateway.camel.helper;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.Builder;
import org.apache.camel.model.ProcessorDefinition;

import com.swissre.gateway.jpa.entities.SystemEndpoint;
import com.swissre.gateway.util.JSONUtils;
import com.swissre.gateway.util.SecurityUtils;
import com.swissre.gateway.util.ServiceConstants;

public class HttpEndpointHelper implements AppEndpointHelper {

	@Override
	public void addEndpoint(ProcessorDefinition<?> processDefinition, SystemEndpoint systemEndpoint,
			Direction direction) {
		String endPointInfo = systemEndpoint.getEndpoint();
		String endPointUrl = JSONUtils.getParamValue(endPointInfo, ServiceConstants.URL);
		String httpMethod = JSONUtils.getParamValue(endPointInfo, ServiceConstants.HTTP_METHOD);
		String contentType = JSONUtils.getParamValue(endPointInfo, ServiceConstants.CONTENT_TYPE);
		processDefinition.setHeader(Exchange.HTTP_METHOD, Builder.constant(httpMethod));
		processDefinition.setHeader(Exchange.CONTENT_TYPE, Builder.constant(contentType));
		processDefinition.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				exchange.getIn().setHeader("Cookie", Builder.constant("LtpaToken2=" + SecurityUtils.getTechUserLtpaToken()));
			}
		});
		processDefinition.to(endPointUrl);
	}
}
