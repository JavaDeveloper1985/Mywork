package com.swissre.gateway.service;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.swissre.gateway.util.AppException;

/**
 * A simple extension of {@code java.util.Properties} designed to be used for
 * application configuration. Utility methods are provided to simplify working
 * with the contained properties.
 */
public class Config extends Properties
{
    private static final long serialVersionUID = 1L;

	/**
	 * Returns the value of the given property as a {@code String}, throwing an
	 * exception if it doesn't exist.
	 * 
	 * @param propertyName
	 *            The property name.
	 * @return The property value.
	 * @throws ManException
	 *             Thrown if the property does not exist.
	 */
    public String getMandatoryProperty(String propertyName) {
    	String propertyValue = getProperty(propertyName);
    	if (propertyValue == null) {
    		throw new AppException("Missing property: " + propertyName);
    	}
		return propertyValue;
	}

    /**
     * Returns an instance of the class configured in the given {@code propertyName}.
     * 
     * @param <T> The expected type of the new instance.
     * @param type The expected class (or supertype) of the new instance.
     * @param propertyName The property name to read the full classname from.
     * @return A new instance of the given type.
     */
    @SuppressWarnings("unchecked")
    public <T> T getInstanceOfType(Class<T> type, String propertyName)
    {
        String className = getProperty(propertyName);
        try
        {
            return (T) Class.forName(className).newInstance();
        }
        catch (Exception e)
        {
            throw new AppException(
                    String.format(
                            "Failed to instantiate the class %s (specified in property %s)",
                            className, propertyName), e);
        }
    }
    
	/**
	 * Returns the given property as a {@code boolean}.
	 * 
	 * @param propertyName
	 *            Name of the property.
	 * @return {@code true} if the property value is {@code true}; {@code false}
	 *         if it is any other value.
	 */
	public boolean getBooleanProperty(String propertyName)
	{
        String propertyValue = getProperty(propertyName);
		return Boolean.parseBoolean(propertyValue);
	}
    
	/**
	 * Returns the given property as an {@code Integer}.
	 * 
	 * @param propertyName
	 *            Name of the property.
	 * @return The property value as an {@code Integer}.
	 */
	public Integer getIntegerProperty(String propertyName) {
		Integer intValue = null;
        String propertyValue = getProperty(propertyName);
        if (StringUtils.isNotBlank(propertyValue)) {
        	try {
				intValue = Integer.parseInt(propertyValue);
			} catch (NumberFormatException e) {
				throw new AppException("Property '" + propertyName + "' has invalid integer value '" + propertyValue
						+ "'", e);
			}
        }
        return intValue;
	}

	/**
	 * Returns the given property as an {@code int}.
	 * 
	 * @param propertyName
	 *            Name of the property.
	 * @return The property value as an {@code int}.
	 */
	public int getIntProperty(String propertyName) {
		Integer value = getIntegerProperty(propertyName);
		if (value == null) {
			throw new AppException("Property '" + propertyName + "' is null and cannot be parsed as an int");
		}
		return value.intValue();
	}
	
}
