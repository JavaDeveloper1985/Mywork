package com.swissre.gateway.service;

import static com.swissre.gateway.data.access.QueryParameter.with;

import java.io.InputStream;
import java.io.StringWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.json.JSONObject;

import com.swissre.gateway.data.access.DataAccessService;
import com.swissre.gateway.jpa.entities.Mapping;
import com.swissre.gateway.jpa.entities.TransformationDetail;
import com.swissre.gateway.jpa.entities.TransformationDirectionEnum;
import com.swissre.gateway.util.AppException;
import com.swissre.gateway.util.JSONUtils;
import com.swissre.gateway.util.ServiceConstants;
import com.swissre.gateway.util.XPathUtils;

@Stateless
@LocalBean
public class TransformationService {

	@EJB
	DataAccessService dataAccessService;

	public Object transformXml(String body, long integrationId, TransformationDirectionEnum direction)
			throws AppException {
		List<TransformationDetail> transformationDetails = fetchTransformationDetails(integrationId, direction);
		String requestXML = body;
		for (TransformationDetail transformationDetail : transformationDetails) {
			requestXML = transformXml(requestXML, transformationDetail, direction);
		}
		return requestXML;
	}

	private List<TransformationDetail> fetchTransformationDetails(long integrationId,
			TransformationDirectionEnum direction) throws AppException {
		return dataAccessService.findWithNamedQuery(TransformationDetail.class, ServiceConstants.TRANFORMATION_DETAILS,
				with(ServiceConstants.INTEGRATION_ID, integrationId)
						.and(ServiceConstants.TRANSFORMATION_DIRECTION, direction.getValue()).parameters());
	}

	public String transformXml(String requestXML, TransformationDetail transformationDetail,
			TransformationDirectionEnum direction) throws AppException {
		String transformedXML = "";
		if (StringUtils.isNotBlank(transformationDetail.getTransformationtypeName())) {
			if (transformationDetail.getTransformationtypeName().equalsIgnoreCase("XSLT_TRANSFORMATION")) {
				transformedXML = xsltTransformation(requestXML, transformationDetail, direction);
			} else {
				transformedXML = xmlDataTransformation(requestXML, transformationDetail, direction);
			}
		}
		return transformedXML;
	}

	@SuppressWarnings("rawtypes")
	private String xmlDataTransformation(String requestXML, TransformationDetail transformationDetail,
			TransformationDirectionEnum direction) {
		String inputValue = null;
		String mappingValue = null;
		try {
			Document document = DocumentHelper.parseText(requestXML);
			String xPathStr = JSONUtils.getParamValue(transformationDetail.getTransformationParams(),
					ServiceConstants.XPATH);
			String defaultValue = JSONUtils.getParamValue(transformationDetail.getTransformationParams(),
					ServiceConstants.DEFAULT_VALUE);
			List nodes = document.selectNodes(xPathStr);
			if (null != nodes && nodes.size() > 0) {
				for (Object object : nodes) {
					Node node = (Node) object;
					if (null != node) {
						inputValue = node.getStringValue();
						mappingValue = getMappingValue(transformationDetail, inputValue);
						if (StringUtils.isNotBlank(inputValue) && StringUtils.isNotBlank(mappingValue)) {
							node.setText(mappingValue);
						}
					}
					requestXML = document.asXML();
				}
			} else if (StringUtils.isNotBlank(defaultValue)) {
				addElementToParent(document, xPathStr, defaultValue);
				requestXML = document.asXML();
			}
		} catch (Exception e) {
			throw new AppException("Error occured while parsing the XML", e);
		}
		return requestXML;
	}

	private String getMappingValue(TransformationDetail transformationDetailView, String inputValue)
			throws AppException {
		JSONObject transformationObject = new JSONObject(transformationDetailView.getTransformationParams());
		String mappingValue = null;

		Mapping mapping = dataAccessService.findSingleResultWithNamedQuery(Mapping.class,
				ServiceConstants.TRANFORMATION_MAPPING,
				with(ServiceConstants.FROM_VALUE, inputValue)
						.and(ServiceConstants.FROM_CODE_TYPE_ID,
								transformationObject.get(ServiceConstants.FROM_CODE_TYPE_ID))
						.and(ServiceConstants.TO_CODE_TYPE_ID,
								transformationObject.get(ServiceConstants.TO_CODE_TYPE_ID))
						.parameters());
		if (null != mapping && StringUtils.isNotBlank(mapping.getToValue())) {
			mappingValue = mapping.getToValue();
		}
		return mappingValue;
	}

	private static Node addElementToParent(Document document, String xpath, String value) {
		String elementName = XPathUtils.getChildElementName(xpath);
		String parentXPath = XPathUtils.getParentXPath(xpath);
		String childElement = XPathUtils.getChildElement(xpath);
		Node parentNode = document.selectSingleNode(parentXPath);
		if (parentNode == null) {
			parentNode = addElementToParent(document, parentXPath, null);
		}
		Integer childIndex = XPathUtils.getChildElementIndex(xpath);
		if (childIndex > 1) {
			List<?> nodelist = document.selectNodes(XPathUtils.createPositionXpath(xpath, childIndex));
			int nodesToCreate = childIndex - nodelist.size() - 1;
			for (int i = 0; i < nodesToCreate; i++) {
				((Element) parentNode).addElement(elementName);
			}
		}
		Element created = ((Element) parentNode).addElement(elementName);
		if (null != value) {
			created.addText(value);
		}

		if (childElement.contains("@")) {
			XPathUtils.createAttributeName(created, childElement);
		}
		return created;
	}

	private String xsltTransformation(String requestXML, TransformationDetail transformationDetail,
			TransformationDirectionEnum direction) {
		TransformerFactory factory = TransformerFactory.newInstance();
		StringWriter writer = new StringWriter();
		StreamResult resultXML = new StreamResult(writer);
		InputStream xsltStream = IOUtils.toInputStream(transformationDetail.getTransformationXSLT());
		InputStream inputXMLStream = IOUtils.toInputStream(requestXML);
		Source xsltSrc = new StreamSource(xsltStream);
		Source inputXMLSrc = new StreamSource(inputXMLStream);
		Transformer transformer;
		try {
			transformer = factory.newTransformer(xsltSrc);
			transformer.transform(inputXMLSrc, resultXML);
		} catch (TransformerConfigurationException e) {
			throw new AppException("There is an error in your stylesheet.", e);
		} catch (TransformerException e) {
			throw new AppException("Exception thrown during the transformation process", e);
		}

		return writer.toString();

	}

}
