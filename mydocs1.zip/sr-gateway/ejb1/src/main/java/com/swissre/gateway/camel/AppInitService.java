package com.swissre.gateway.camel;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.security.RunAs;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Timer;
import javax.jms.QueueConnectionFactory;
import javax.naming.InitialContext;

import org.apache.camel.CamelContext;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;

import com.swissre.gateway.service.ServiceConfig;

@Singleton
@LocalBean
@RunAs("IPA_TECH_USER")
public class AppInitService {

	private static final Logger logger = Logger.getLogger(AppInitService.class.getName());

	private boolean serviceEnabled;

	CamelContext camelContext;

	@EJB
	AppRouteBuilder appRouteBuilder;

	/**
	 * Called by the EJB container to complete initialization of this instance
	 * after all dependency injections are complete.
	 */
	@PostConstruct
	protected void onPostConstruct() {
		ServiceConfig serviceConfig = ServiceConfig.getConfigFor(getClass());
		this.serviceEnabled = serviceConfig.getBooleanProperty("service.enabled");
	}

	@Schedule(hour = "*", minute = "*", second = "*", persistent = false)
	public void init(Timer timer) {
		try {
			if (isServiceEnabled()) {
				camelContext = new DefaultCamelContext();
				QueueConnectionFactory connectionFactory;
				connectionFactory = (QueueConnectionFactory) new InitialContext()
						.lookup("jms/jmsQueueConnectionFactory");
				camelContext.addComponent("jms", JmsComponent.jmsComponentAutoAcknowledge(connectionFactory));
				camelContext.addRoutes(appRouteBuilder);
				camelContext.start();
			} else {
				logger.fine("Initialization of Camel Context is disabled.");
			}
			timer.cancel();
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "An error occurred while initializing camel context.", ex);
			// TODO: How do we know if the camel context fails to initialize
		}
	}

	@PreDestroy
	public void destroy() {
		if (null != camelContext) {
			try {
				camelContext.stop();
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "An error occurred while stopping the camel context.", ex);
			}
		}
	}

	public CamelContext getAppCamelContext() {
		return camelContext;
	}

	private boolean isServiceEnabled() {
		return this.serviceEnabled;
	}

}
