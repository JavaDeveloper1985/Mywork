package com.swissre.gateway.jpa.entities;

public enum TransformationDirectionEnum {
	
	SRC_TO_TARGET("SRC_TO_TARGET"),
	TARTGET_To_SRC("TARGET_TO_SRC");
	
	private String value;
	
	private TransformationDirectionEnum(String value)
	{
		this.value = value;
	}

	public String getValue()
	{
		return value;
	}

}
