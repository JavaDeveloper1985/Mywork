package com.swissre.gateway.util;

import java.math.BigInteger;

public class AppException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String errorCode;
	private String msgId;
	private int opSeqNo;
	private BigInteger operationId;
	public int getOpSeqNo() {
		return opSeqNo;
	}

	public void setOpSeqNo(int opSeqNo) {
		this.opSeqNo = opSeqNo;
	}

	public BigInteger getOperationId() {
		return operationId;
	}

	public void setOperationId(BigInteger operationId) {
		this.operationId = operationId;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	private String format;
	private int httpResponseStatus = ServiceConstants.INTERNAL_SERVER_ERROR;

	/**
	 * @param detail
	 *            The detail message.
	 */
	public AppException(String detail) {
		this(detail, null);
	}

	/**
	 * @param detail
	 *            The detail message.
	 */
	public AppException(String detail, int httpResponseStatus) {
		this(detail, null, httpResponseStatus);
	}

	/**
	 * @param detail
	 *            The detail message.
	 * @param rootCause
	 *            The Throwable that caused this exception to be thrown.
	 */
	public AppException(String detail, Throwable rootCause) {
		this(detail, rootCause, null);
	}

	/**
	 * @param detail
	 *            The detail message.
	 * @param rootCause
	 *            The Throwable that caused this exception to be thrown.
	 */
	public AppException(String detail, Throwable rootCause,
			int httpResponseStatus) {
		this(detail, rootCause, null, httpResponseStatus);
	}

	/**
	 * @param detail
	 *            The detail message.
	 * @param rootCause
	 *            The Throwable that caused this exception to be thrown.
	 * @param operationId
	 *            The operation's id.
	 */
	public AppException(String detail, Throwable rootCause, String errorCode) {
		super(detail, rootCause);
		setErrorCode(errorCode);
	}

	/**
	 * @param detail
	 *            The detail message.
	 * @param rootCause
	 *            The Throwable that caused this exception to be thrown.
	 * @param operationId
	 *            The operation's id.
	 */
	public AppException(String detail, Throwable rootCause, String errorCode,
			int httpResponseStatus) {
		super(detail, rootCause);
		setErrorCode(errorCode);
		setHttpResponseStatus(httpResponseStatus);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public int getHttpResponseStatus() {
		return httpResponseStatus;
	}

	public void setHttpResponseStatus(int httpResponseStatus) {
		this.httpResponseStatus = httpResponseStatus;
	}

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

}
