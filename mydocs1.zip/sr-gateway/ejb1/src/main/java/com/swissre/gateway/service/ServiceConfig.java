package com.swissre.gateway.service;

import java.io.IOException;
import java.io.InputStream;

import com.swissre.gateway.util.AppException;

/**
 * Holds configuration information for a Manhattan service. Each core Business Service
 * EJB has a properties file (e.g., {@code BookingService.properties},
 * {@code PolicyService.properties}, etc.) that contains configuration settings
 * for that service. A service configuration properties file can be read via the
 * {@code static ServiceConfig.getConfigFor()} method.
 */
public class ServiceConfig extends Config
{
    private static final long serialVersionUID = 1L;

    /**
     * Private constructor. Use the {@code static ServiceConfig.getConfigFor()}
     * method to obtain instances of this class.
     * 
     * @param configFileName
     *            The name of the service configuration properties file for this
     *            instance.
     */
    private ServiceConfig(String configFileName)
    {
    }

    /**
     * Reads the service configuration properties file for the given Business
     * Service. The service configuration properties file is named
     * {@code [classname].properties} and is loaded from the classpath.
     * 
     * For example, calling
     * {@code ServiceConfig.getConfigFor(PolicyService.class)} will load the
     * {@code PolicyService.properties} file.
     * 
     * @param serviceClass
     *            The class of the Manhattan Business Service EJB class.
     * @return A {@code ServiceConfig} instance with properties loaded from the
     *         service configuration properties file.
     */
    public static ServiceConfig getConfigFor(Class<?> serviceClass)
    {
        String fileName = String.format("/%s.properties", serviceClass.getSimpleName());
        InputStream configStream = ServiceConfig.class.getResourceAsStream(fileName);
        
        if (configStream == null)
        {
            throw new AppException("Could not load service config file from classpath: " + fileName);
        }
        
        ServiceConfig config = new ServiceConfig(fileName);

        try
        {
            config.load(configStream);
        }
        catch (IOException e)
        {
            throw new AppException("Failed to load service config file: " + fileName, e);
        }
        
        return config;
    }
}
