package com.swissre.gateway.service;

import java.security.Principal;

import javax.annotation.Resource;
import javax.ejb.EJBContext;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.commons.lang3.StringUtils;

@Stateless
@LocalBean
public class UserService {
    
	@Resource 
    private EJBContext ejbContext; 

	public String getLoggedInUserId()
	{
        Principal principal = ejbContext.getCallerPrincipal();
        if (principal == null || StringUtils.isBlank(principal.getName()))
        {
            throw new RuntimeException("Null principal or missing user name: could not determine user's identity");
        }
        String userId = principal.getName();
        return userId;
	}

}
