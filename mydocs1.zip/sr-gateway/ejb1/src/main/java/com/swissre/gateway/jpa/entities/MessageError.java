package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TMESSAGEERROR database table.
 * 
 */
@Entity
@Table(name="TMESSAGEERROR")
public class MessageError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MESSAGE_ID")
	private String messageId;

	private String errormessage;

    @Lob()
	private String errortrace;

	//bi-directional one-to-one association to IntegrationMessage
	@OneToOne
	@PrimaryKeyJoinColumn(name="MESSAGE_ID")
	private IntegrationMessage integrationMessage;

    public MessageError() {
    }

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getErrormessage() {
		return this.errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public String getErrortrace() {
		return this.errortrace;
	}

	public void setErrortrace(String errortrace) {
		this.errortrace = errortrace;
	}

	public IntegrationMessage getIntegrationMessage() {
		return this.integrationMessage;
	}

	public void setIntegrationMessage(IntegrationMessage integrationMessage) {
		this.integrationMessage = integrationMessage;
	}
	
}