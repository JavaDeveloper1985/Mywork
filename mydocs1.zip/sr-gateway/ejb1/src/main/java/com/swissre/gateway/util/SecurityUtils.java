package com.swissre.gateway.util;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyStoreException;
import java.security.PrivilegedAction;
import java.util.Properties;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;

import org.apache.commons.codec.binary.Base64;

import com.ibm.websphere.security.auth.WSSubject;
import com.ibm.websphere.security.auth.callback.WSCallbackHandlerImpl;
import com.ibm.ws.security.util.AccessController;
import com.ibm.wsspi.security.token.SingleSignonToken;

/**
 * Utility class used to retrieve technical user id, password and ltpa token.
 * Initialize method to be called to inititalize all these values.
 *
 */
public class SecurityUtils {

	private static String techUserId = null;
	private static String techPassword = null;

	public static void initialize() {
		try {
			InputStream inputStream = SecurityUtils.class.getClassLoader()
					.getResourceAsStream(ServiceConstants.TECH_USERINFO_PROPS);
			Properties properties = new Properties();
			properties.load(inputStream);
			String userIdJndiName = properties.getProperty(ServiceConstants.USERJNDINAME);
			String userPwdJndiName = properties.getProperty(ServiceConstants.PWDJNDINAME);
			techUserId = lookupJndiString(userIdJndiName);
			techPassword = lookupJndiString(userPwdJndiName);
		} catch (Exception e) {
			throw new SecurityException(e);
		}
	}

	public static String getTechUserId() {
		return techUserId;
	}

	public static String getTechPassword() {
		return techPassword;
	}

	public static String getTechUserLtpaToken() throws GeneralSecurityException {
		LoginContext loginContext = new LoginContext("WSLogin", new WSCallbackHandlerImpl(techUserId, techPassword));
		loginContext.login();
		final Subject subject = loginContext.getSubject();
		WSSubject.setRunAsSubject(subject);
		@SuppressWarnings("unchecked")
		Set<SingleSignonToken> privateCredentials = (Set<SingleSignonToken>) AccessController
				.doPrivileged(new PrivilegedAction<Set<SingleSignonToken>>() {
					@Override
					public Set<SingleSignonToken> run() {
						return subject.getPrivateCredentials(SingleSignonToken.class);
					}

				});
		for (SingleSignonToken singleSignonToken : privateCredentials) {
			if (singleSignonToken.getName().equals("LtpaToken") && singleSignonToken.getVersion() == 2) {
				return Base64.encodeBase64String(singleSignonToken.getBytes());
			}
		}
		return null;
	}

	private static String lookupJndiString(String name) throws AppException {
		try {
			Context jndiCtx = new InitialContext();
			return (String) jndiCtx.lookup(name);
		} catch (NamingException e) {
			throw new AppException("Failed to look up String with name '" + name + "' in JNDI", e);
		}
	}

}