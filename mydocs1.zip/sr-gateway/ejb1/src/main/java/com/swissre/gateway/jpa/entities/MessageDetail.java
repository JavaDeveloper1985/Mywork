package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the V_MESSAGE_DETAIL database table.
 * 
 */
@Entity
@Table(name="V_MESSAGE_DETAIL")
public class MessageDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	private String errormessage;

	@Column(name="INTEGRATION_TYPE")
	private String integrationType;

	@Id
	@Column(name="MESSAGE_ID")
	private String messageId;

    @Lob()
	private String payload;

	private String response;

	@Column(name="RESPONSE_TYPE")
	private String responseType;

	@Column(name="SRC_APP_ID")
	private String srcAppId;

	private String status;

	@Column(name="SYS_NAME")
	private String sysName;
	
	private String errorTrace;
	
	@Lob()
	private String sample_response;
	
	private String endpoint;
	
	private String userId;
	
	@Column(name="ACKNOWLEDGEMENT_REQ")
	private Boolean acknowledgementReq;
	

    public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public MessageDetail() {
    }

	public String getErrormessage() {
		return this.errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public String getIntegrationType() {
		return this.integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getResponseType() {
		return this.responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public String getSrcAppId() {
		return this.srcAppId;
	}

	public void setSrcAppId(String srcAppId) {
		this.srcAppId = srcAppId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSysName() {
		return this.sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

	public String getErrorTrace() {
		return errorTrace;
	}

	public void setErrorTrace(String errorTrace) {
		this.errorTrace = errorTrace;
	}

	public String getSample_response() {
		return sample_response;
	}

	public void setSample_response(String sample_response) {
		this.sample_response = sample_response;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getAcknowledgementReq() {
		return acknowledgementReq;
	}

	public void setAcknowledgementReq(Boolean acknowledgementReq) {
		this.acknowledgementReq = acknowledgementReq;
	}

}