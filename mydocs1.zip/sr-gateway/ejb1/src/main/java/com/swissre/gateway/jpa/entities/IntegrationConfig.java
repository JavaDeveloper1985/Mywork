package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TINTEGRATIONCONFIG database table.
 * 
 */
@Entity
@Table(name="TINTEGRATIONCONFIG")
public class IntegrationConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INETGRATIONCONFID_ID")
	private long inetgrationconfidId;

	@Column(name="SRC_TARGET_TRANSFORM_REQ")
	private Boolean srcTargetTransformReq;

	@Column(name="TARGET_SRC_TRANSFORM_REQ")
	private Boolean targetSrcTransformReq;

	//bi-directional many-to-one association to Integration
    @ManyToOne
    @PrimaryKeyJoinColumn(name="INTEGRATION_ID")
	private Integration integration;

	//uni-directional many-to-one association to SystemEndpoint
    @ManyToOne
    @PrimaryKeyJoinColumn(name="TARGET_ENDPOINT_ID")
	private SystemEndpoint targetEndpoint;

    public IntegrationConfig() {
    }

	public long getInetgrationconfidId() {
		return this.inetgrationconfidId;
	}

	public void setInetgrationconfidId(long inetgrationconfidId) {
		this.inetgrationconfidId = inetgrationconfidId;
	}

	public Boolean getSrcTargetTransformReq() {
		return this.srcTargetTransformReq;
	}

	public void setSrcTargetTransformReq(Boolean srcTargetTransformReq) {
		this.srcTargetTransformReq = srcTargetTransformReq;
	}

	public Boolean getTargetSrcTransformReq() {
		return this.targetSrcTransformReq;
	}

	public void setTargetSrcTransformReq(Boolean targetSrcTransformReq) {
		this.targetSrcTransformReq = targetSrcTransformReq;
	}

	public Integration getIntegration() {
		return this.integration;
	}

	public void setIntegration(Integration integration) {
		this.integration = integration;
	}
	
	public SystemEndpoint getTargetEndpoint() {
		return this.targetEndpoint;
	}

	public void setTargetEndpoint(SystemEndpoint targetEndpoint) {
		this.targetEndpoint = targetEndpoint;
	}
	
}