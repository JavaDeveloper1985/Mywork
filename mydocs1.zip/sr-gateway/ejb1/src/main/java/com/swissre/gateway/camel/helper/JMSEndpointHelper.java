package com.swissre.gateway.camel.helper;

import org.apache.camel.model.ProcessorDefinition;
import org.apache.camel.model.RouteDefinition;

import com.swissre.gateway.jpa.entities.SystemEndpoint;
import com.swissre.gateway.util.JSONUtils;
import com.swissre.gateway.util.SecurityUtils;
import com.swissre.gateway.util.ServiceConstants;

public class JMSEndpointHelper implements AppEndpointHelper {

	@Override
	public void addEndpoint(ProcessorDefinition<?> processDefinition,
			SystemEndpoint systemEndpoint, Direction direction) {
		String endPointInfo = systemEndpoint.getEndpoint();
		StringBuffer endpointUrl = new StringBuffer(JSONUtils.getParamValue(
				endPointInfo, ServiceConstants.URL));
		addOptionalParam(endpointUrl, ServiceConstants.USERNAME,
				SecurityUtils.getTechUserId());
		addOptionalParam(endpointUrl, ServiceConstants.PASSWORD,
				SecurityUtils.getTechPassword());
		if (AppEndpointHelper.Direction.FROM.getId() == direction.getId()) {
			if(processDefinition instanceof RouteDefinition){
				((RouteDefinition) processDefinition).from(endpointUrl.toString()).removeHeader(
						"JMS_IBM_System_MessageID");
			}
		} else if (AppEndpointHelper.Direction.TO.getId() == direction.getId()) {
			processDefinition.to(endpointUrl.toString());
		}
	}

	private void addOptionalParam(StringBuffer endpointUrl, String paramName,
			String paramValue) {
		endpointUrl.append(ServiceConstants.AMPERSAND).append(paramName)
				.append(ServiceConstants.EQUAL).append(paramValue);
	}

}
