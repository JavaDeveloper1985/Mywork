package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TINTEGRATION database table.
 * 
 */
@Entity
@Table(name="TINTEGRATION")
@NamedQueries({
		@NamedQuery(name = "GatewayIntegration.getEndPointDetails", query = "select distinct integrationDetails	FROM Integration integrationDetails	ORDER BY integrationDetails.sourceSystem.sysId , integrationDetails.integrationId")})
public class Integration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INTEGRATION_ID")
	private long integrationId;

	@Column(name="ACKNOWLEDGEMENT_REQ")
	private Boolean acknowledgementReq;

	@Column(name="INTEGRATION_TYPE")
	private String integrationType;

    @Lob()
	@Column(name="SAMPLE_RESPONSE")
	private String sampleResponse;

	//uni-directional many-to-one association to IntSystem
    @ManyToOne
    @PrimaryKeyJoinColumn(name="SOURCE_SYS_ID")
	private IntSystem sourceSystem;

	//uni-directional many-to-one association to SystemEndpoint
    @ManyToOne
    @PrimaryKeyJoinColumn(name="SRC_ENDPOINT_ID")
	private SystemEndpoint sourceEndpoint;

	//uni-directional many-to-one association to SystemEndpoint
    @ManyToOne
    @PrimaryKeyJoinColumn(name="ACKNOWLEDGE_ENDPOINT_ID")
	private SystemEndpoint ackEndpoint;

	//bi-directional many-to-one association to IntegrationConfig
	@OneToMany(mappedBy="integration")
	private List<IntegrationConfig> integrationConfigs;
	
	
	//bi-directional many-to-one association to TintegrationMessage
	@OneToMany(mappedBy="integration")
	private List<IntegrationMessage> Integrationmessages;

    public Integration() {
    }

	public long getIntegrationId() {
		return this.integrationId;
	}

	public void setIntegrationId(long integrationId) {
		this.integrationId = integrationId;
	}

	public Boolean getAcknowledgementReq() {
		return this.acknowledgementReq;
	}

	public void setAcknowledgementReq(Boolean acknowledgementReq) {
		this.acknowledgementReq = acknowledgementReq;
	}

	public String getIntegrationType() {
		return this.integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getSampleResponse() {
		return this.sampleResponse;
	}

	public void setSampleResponse(String sampleResponse) {
		this.sampleResponse = sampleResponse;
	}

	public IntSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(IntSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	public SystemEndpoint getSourceEndpoint() {
		return this.sourceEndpoint;
	}

	public void setSourceEndpoint(SystemEndpoint sourceEndpoint) {
		this.sourceEndpoint = sourceEndpoint;
	}
	
	public SystemEndpoint getAckEndpoint() {
		return this.ackEndpoint;
	}

	public void setAckEndpoint(SystemEndpoint ackEndpoint) {
		this.ackEndpoint = ackEndpoint;
	}
	
	public List<IntegrationConfig> getIntegrationConfigs() {
		return this.integrationConfigs;
	}

	public void setIntegrationConfigs(List<IntegrationConfig> integrationConfigs) {
		this.integrationConfigs = integrationConfigs;
	}

	public List<IntegrationMessage> getIntegrationmessages() {
		return Integrationmessages;
	}

	public void setIntegrationmessages(List<IntegrationMessage> integrationmessages) {
		Integrationmessages = integrationmessages;
	}
	
}