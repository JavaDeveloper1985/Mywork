package com.swissre.gateway.util;

public interface ServiceConstants {

	public static final String RESTFUL = "REST";

	public static final String HTTP_METHOD = "httpMethod";

	public static final String CONTENT_TYPE = "contentType";

	public static final String URL = "URL";

	public static final int INTERNAL_SERVER_ERROR = 500;

	public static final String MESSAGE_ID_XPATH = "//messageId/text()";
	
	public static final String INTEGRATION_TYPE_XPATH = "//messageType/text()";

	public static final String CORRELATION_ID_XPATH = "//correlationId/text()";

	public static final String AUTH_USER = "authUsername=";

	public static final String AUTH_PWD = "&authPassword=";

	public static final String FROM = "FROM";

	public static final String TO = "TO";

	public static final String ERROR_MSG_XPATH = "//message/text()";
	
	public static final String ERROR_TRACE_XPATH = "//stackTrace/text()";

	public static final String MESSAGE_TYPE_XPATH = "//messageType/text()";
	
	public static final String SRC_APP_XPATH = "//srcAppId/text()";
	
	public static final String TECH_USERINFO_PROPS = "techuserinfo.properties";
	
	public static final String KEYSETNAME = "service.keySetName";
	
	public static final String IV = "service.initializationVector";
	
	public static final String USERJNDINAME = "service.userIdJndiName";
	
	public static final String PWDJNDINAME = "service.userPwdJndiName";
	
	public static final String STARNET_ENV_NAME = "starnet.environment-name";
	
	public static final String ENDPOINT_CONFIG_PROPS = "endpointconfig.properties";
	
	public static final String AMPERSAND = "&";

	public static final String USERNAME = "username";
	
	public static final String EQUAL = "=";
	
	public static final String PASSWORD = "password";	

	public static final String CACHELEVELNAME = "cacheLevelName";	

	public static final String CACHENONE = "CACHE_NONE";	
	
	public static final String TRANSFORMATION_DIRECTION = "transformationDirection";
	
	public static final String INTEGRATION_ID = "integrationId";
	
	public static final String XPATH = "xPath";

	public static final String DEFAULT_VALUE = "defaultValue";
	
	public static final String FROM_VALUE = "fromValue";
	
	public static final String FROM_CODE_TYPE_ID = "fromCodetypeId";
	
	public static final String TO_CODE_TYPE_ID = "toCodetypeId";
	
	public static final String TRANFORMATION_MAPPING = "GatewayIntegration.getTransformationMapping";
	
	public static final String TRANFORMATION_DETAILS = "GatewayIntegration.getTransformationDetails";
	
	//Search Query constants
	public static final String LIMIT = "limit";
	
	public static final String PAGE = "page";
	
	public static final String FILTER = "filter";

	public static final String ORDER = "order";


	public static final String CREATE_BOOKING = "CREATE_BOOKING";
	
	public static final String CREATE_LINE = "CREATE_LINE";

	public static final String BOOKING_NO = "BOOKING_NO";

	public static final String OTHER_REF = "OTHER_REF";

	public static final String POLICYLINENUMBER = "POLICYLINENUMBER";
	
	public static final String EXTERNALREFSYSTEM = "EXTERNALREFSYSTEM";

	public static final String BOOKING = "BOOKING";
	
	public static final String LINE = "LINE";

	public static final String HEADER = "</header>";

	public static final String ENDPOINT_URL = "URL";

	public static final int COMPLETE = 3;
	
	public static final String SRC_SYS_REFERENCE_ID_XPATH = "//srcSystemReferenceId/text()";
	
	public static final String PREVIOUS_MESSAGE_ID_XPATH = "//prevMessageId/text()";

	public static final String TYPE = "type";

	public static final String JMS = "JMS";
	
	public static final String SRC_SYSTEM_MAN = "MAN";

	public static final String ERROR_RESPONSE = "ERROR_RESPONSE";
}
