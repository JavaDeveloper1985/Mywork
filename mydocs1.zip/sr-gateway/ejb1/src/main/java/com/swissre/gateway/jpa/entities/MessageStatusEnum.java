package com.swissre.gateway.jpa.entities;

public enum MessageStatusEnum
{
	INPROGRESS(1),
	FAILED(2),
	COMPLETED(3),
	ABANDONED(4);
	
	private int id;
	
	private MessageStatusEnum(int id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code MessageStatus}
	 */
	public int getId()
	{
		return id;
	}
}
