package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the V_INTEGRATION_DATA database table.
 * 
 */
@Entity
@Table(name="V_INTEGRATION_DATA")
public class IntegrationData implements Serializable {
	private static final long serialVersionUID = 1L;

	private long completed;

	private long failed;

	private long inprogress;
	
	private long abandoned;

	@Id
	@Column(name="INTEGRATION_TYPE")
	private String integrationType;

	@Column(name="SYS_NAME")
	private String sysName;

	@Column(name="TARGET_SYSTEM")
	private String targetSystem;

    public IntegrationData() {
    }

	public long getCompleted() {
		return this.completed;
	}

	public void setCompleted(long completed) {
		this.completed = completed;
	}

	public long getFailed() {
		return this.failed;
	}

	public void setFailed(long failed) {
		this.failed = failed;
	}

	public long getInprogress() {
		return this.inprogress;
	}

	public void setInprogress(long inprogress) {
		this.inprogress = inprogress;
	}

	public String getIntegrationType() {
		return this.integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getSysName() {
		return this.sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

	public String getTargetSystem() {
		return this.targetSystem;
	}

	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}

	public long getAbandoned() {
		return abandoned;
	}

	public void setAbandoned(long abandoned) {
		this.abandoned = abandoned;
	}

	

}