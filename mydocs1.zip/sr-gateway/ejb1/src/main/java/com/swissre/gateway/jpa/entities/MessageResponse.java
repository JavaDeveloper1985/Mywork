package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TMESSAGERESPONSE database table.
 * 
 */
@Entity
@Table(name="TMESSAGERESPONSE")
public class MessageResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MESSAGE_ID")
	private String messageId;

	private String response;

	//bi-directional one-to-one association to IntegrationMessage
	@OneToOne
	@PrimaryKeyJoinColumn(name="MESSAGE_ID")
	private IntegrationMessage integrationMessage;

    public MessageResponse() {
    }

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public IntegrationMessage getIntegrationMessage() {
		return this.integrationMessage;
	}

	public void setIntegrationMessage(IntegrationMessage integrationMessage) {
		this.integrationMessage = integrationMessage;
	}
	
}