package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TINTEGRATION_TYPE database table.
 * 
 */
@Entity
@Table(name="TINTEGRATION_TYPE")
public class IntegrationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INETGRATION_TYPE_ID")
	private long inetgrationTypeId;

	@Column(name="INTEGRATION_TYPE_NAME")
	private String integrationTypeName;

    public IntegrationType() {
    }

	public long getInetgrationTypeId() {
		return this.inetgrationTypeId;
	}

	public void setInetgrationTypeId(long inetgrationTypeId) {
		this.inetgrationTypeId = inetgrationTypeId;
	}

	public String getIntegrationTypeName() {
		return this.integrationTypeName;
	}

	public void setIntegrationTypeName(String integrationTypeName) {
		this.integrationTypeName = integrationTypeName;
	}

}