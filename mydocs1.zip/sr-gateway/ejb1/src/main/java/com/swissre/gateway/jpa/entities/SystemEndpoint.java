package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TSYSTEMENDPOINT database table.
 * 
 */
@Entity
@Table(name="TSYSTEMENDPOINT")
public class SystemEndpoint implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYS_ENDPOINT_ID")
	private long sysEndpointId;

	private String endpoint;

	//uni-directional many-to-one association to EndpointType
    @ManyToOne
    @PrimaryKeyJoinColumn(name="ENDPOINTTYPE_ID")
	private EndpointType endpointType;

	//uni-directional many-to-one association to IntSystem
    @ManyToOne
    @PrimaryKeyJoinColumn(name="SYS_ID")
	private IntSystem system;

    public SystemEndpoint() {
    }

	public long getSysEndpointId() {
		return this.sysEndpointId;
	}

	public void setSysEndpointId(long sysEndpointId) {
		this.sysEndpointId = sysEndpointId;
	}

	public String getEndpoint() {
		return this.endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public EndpointType getEndpointType() {
		return this.endpointType;
	}

	public void setEndpointType(EndpointType endpointType) {
		this.endpointType = endpointType;
	}
	
	public IntSystem getSystem() {
		return this.system;
	}

	public void setSystem(IntSystem system) {
		this.system = system;
	}
	
}