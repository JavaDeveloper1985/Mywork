package com.swissre.gateway.util;

import java.io.StringReader;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

public class XMLUtils {

	public static String getAttributeValue(String xPathStr, String requestXML)
			throws AppException {
		String nodeValue = null;
		XPath xpath = XPathFactory.newInstance().newXPath();
		InputSource source = new InputSource(new StringReader(requestXML));
		try {
			Document doc = (Document) xpath.evaluate("/", source, XPathConstants.NODE);
			nodeValue = xpath.evaluate(xPathStr, doc);

		} catch (Exception e) {
			throw new AppException("Error occured while fetching xml attribute value.", e);
		}
		return nodeValue;
	}
	
}
