package com.swissre.gateway.camel;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.camel.Predicate;
import org.apache.camel.builder.PredicateBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ChoiceDefinition;
import org.apache.camel.model.RouteDefinition;

import com.swissre.gateway.camel.helper.AppEndpointFactory;
import com.swissre.gateway.camel.helper.AppEndpointHelper;
import com.swissre.gateway.camel.helper.RouteProcessHelper;
import com.swissre.gateway.data.access.DataAccessService;
import com.swissre.gateway.jpa.entities.Integration;
import com.swissre.gateway.jpa.entities.IntegrationConfig;
import com.swissre.gateway.jpa.entities.TransformationDirectionEnum;
import com.swissre.gateway.util.ServiceConstants;

@Stateless
@LocalBean
public class AppRouteBuilder extends RouteBuilder {

	@EJB
	DataAccessService dataAccessService;
	
	@EJB
	RouteProcessHelper processHelper;
	

	@Override
	public void configure() throws Exception {
		List<Integration> integrationDetails = dataAccessService
				.findWithNamedQuery(Integration.class, "GatewayIntegration.getEndPointDetails");
		String prevSrcEndPoint = null;
		RouteDefinition routeDefinition = null;
		AppEndpointFactory endpointFactory = AppEndpointFactory.getInstance();
		int integrationCount = integrationDetails.size();
		Integration  integrationDetail = null;
		ChoiceDefinition validChoiceDefinition = null;
		for (int index = 0; index < integrationCount; index++) {

			integrationDetail = integrationDetails.get(index);
			if(prevSrcEndPoint == null || 
					!prevSrcEndPoint.equalsIgnoreCase(integrationDetail.getSourceEndpoint().getEndpoint())){
				routeDefinition = new RouteDefinition();				
				if(integrationDetail.getAcknowledgementReq()){
					processHelper.onExceptionSendErrorResponse(routeDefinition,integrationDetail);
				}else{
					processHelper.onException(routeDefinition,integrationDetail);
				}
				AppEndpointHelper srcEndpointHelper = endpointFactory.retrieveEndPointHelper(integrationDetail.getSourceEndpoint());			
				srcEndpointHelper.addEndpoint(routeDefinition, integrationDetail.getSourceEndpoint(), AppEndpointHelper.Direction.FROM);
				processHelper.persistIncomingMessage(routeDefinition,integrationDetail);
				validChoiceDefinition = routeDefinition.choice();
			}
			Predicate srcAppPredicate = constant(integrationDetail.getSourceSystem().getSysName()).isEqualTo(xpath(ServiceConstants.SRC_APP_XPATH));
			Predicate msgTypePredicate = PredicateBuilder.and(constant(integrationDetail.getIntegrationType()).isEqualTo(xpath(ServiceConstants.MESSAGE_TYPE_XPATH)));
			Predicate predicate = PredicateBuilder.and(srcAppPredicate, msgTypePredicate);
			validChoiceDefinition.when(predicate);
			IntegrationConfig integrationConfig = integrationDetail.getIntegrationConfigs().get(0);
			if(integrationConfig.getSrcTargetTransformReq()){
				processHelper.transformXml(validChoiceDefinition, integrationConfig, TransformationDirectionEnum.SRC_TO_TARGET);
			}
			AppEndpointHelper targetEndpointHelper = endpointFactory.retrieveEndPointHelper(integrationConfig.getTargetEndpoint());
			targetEndpointHelper.addEndpoint(validChoiceDefinition, integrationConfig.getTargetEndpoint(), AppEndpointHelper.Direction.TO);
			processHelper.persistOutgoingMessage(validChoiceDefinition);
			if (integrationDetail.getAcknowledgementReq()) {
				if(integrationConfig.getTargetSrcTransformReq()){
					processHelper.transformXml(validChoiceDefinition, integrationConfig, TransformationDirectionEnum.TARTGET_To_SRC);
				}
				AppEndpointHelper ackEndpointHelper = endpointFactory.retrieveEndPointHelper(integrationDetail.getAckEndpoint());
				ackEndpointHelper.addEndpoint(validChoiceDefinition, integrationDetail.getAckEndpoint(), AppEndpointHelper.Direction.TO);	
			}
			processHelper.persistReponseMessage(validChoiceDefinition, integrationDetail);
			prevSrcEndPoint = integrationDetail.getSourceEndpoint().getEndpoint();
			if(index == integrationCount-1 || !prevSrcEndPoint.equalsIgnoreCase(integrationDetails.get(index+1).getSourceEndpoint().getEndpoint())){
				processHelper.handleInvalidMessage(validChoiceDefinition);
				validChoiceDefinition.endChoice();
				routeDefinition.end();
				System.out.println(routeDefinition.toString());
				getRouteCollection().getRoutes().add(routeDefinition);				
			}
		
		}
	}

}
