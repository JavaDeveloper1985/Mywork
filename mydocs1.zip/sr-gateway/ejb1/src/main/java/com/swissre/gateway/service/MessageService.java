package com.swissre.gateway.service;

import java.io.StringWriter;
import java.util.UUID;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import com.swissre.gateway.data.access.DataAccessService;
import com.swissre.gateway.jpa.entities.IntSystem;
import com.swissre.gateway.jpa.entities.Integration;
import com.swissre.gateway.jpa.entities.IntegrationMessage;
import com.swissre.gateway.jpa.entities.MessageError;
import com.swissre.gateway.jpa.entities.MessageResponse;
import com.swissre.gateway.jpa.entities.MessageStatusEnum;
import com.swissre.gateway.rest.domain.Content;
import com.swissre.gateway.rest.domain.ErrorInfo;
import com.swissre.gateway.rest.domain.Header;
import com.swissre.gateway.rest.domain.IntegrationMsgResponse;
import com.swissre.gateway.util.AppException;
import com.swissre.gateway.util.ExceptionUtilityHelper;
import com.swissre.gateway.util.ServiceConstants;
import com.swissre.gateway.util.XMLUtils;

@Stateless
@LocalBean
public class MessageService {

	private static final Logger LOGGER = Logger.getLogger(MessageService.class.getName());

	private final String NEW_LINE_WITH_SPACES = "\n";

	@EJB
	DataAccessService dataAccessService;

	@EJB
	UserService userService;

	public String persistMessage(String requestXML, Integration integration) throws AppException {
		LOGGER.info("persisting incoming request XML - " + requestXML);
		String xPathStr = ServiceConstants.MESSAGE_ID_XPATH;
		String messageId = XMLUtils.getAttributeValue(xPathStr, requestXML);
		String previousMsgId = XMLUtils.getAttributeValue(ServiceConstants.PREVIOUS_MESSAGE_ID_XPATH, requestXML);
		IntegrationMessage integrationMessage = dataAccessService.find(IntegrationMessage.class, messageId);
		if (null != integrationMessage) {
			throw new AppException("The record already exists for the message id: " + messageId + ".");
		} else {
			integrationMessage = new IntegrationMessage();
		}
		integrationMessage.setIntegration(integration);
		integrationMessage
				.setIntegrationType(XMLUtils.getAttributeValue(ServiceConstants.MESSAGE_TYPE_XPATH, requestXML));
		integrationMessage.setMessageId(messageId);
		integrationMessage.setPayload(requestXML);
		IntSystem system = new IntSystem();
		system.setSysId(integration.getSourceSystem().getSysId());
		integrationMessage.setSystem(system);
		integrationMessage.setMessageStatus(MessageStatusEnum.INPROGRESS.getId());
		dataAccessService.create(integrationMessage);
		if (StringUtils.isNotBlank(previousMsgId)) {
			abandonePerviousMsg(previousMsgId);
		}
		return requestXML;
	}

	private void abandonePerviousMsg(String previousMsgId) {
		IntegrationMessage integrationMessage = dataAccessService.find(IntegrationMessage.class, previousMsgId);
		updateIntegrationMessage(integrationMessage, MessageStatusEnum.ABANDONED.getId());

	}

	public void updateMessage(Exception exception, String requestXML) throws Exception {
		LOGGER.info("RequestXML :- " + requestXML);
		LOGGER.info("Exception :- " + exception);
		String xPathStr = ServiceConstants.MESSAGE_ID_XPATH;
		String messageId = XMLUtils.getAttributeValue(xPathStr, requestXML);
		IntegrationMessage integrationMessage = dataAccessService.find(IntegrationMessage.class, messageId);
		if (null != integrationMessage && null == integrationMessage.getMessageError()) {
			MessageError messageError = new MessageError();
			messageError.setMessageId(messageId);
			messageError.setErrormessage(ExceptionUtilityHelper.getExceptionMessage(exception));
			messageError.setErrortrace(
					StringUtils.join(ExceptionUtils.getStackFrames(ExceptionUtilityHelper.getExceptionCause(exception)),
							NEW_LINE_WITH_SPACES));
			integrationMessage.setMessageError(messageError);
			dataAccessService.create(messageError);
			updateIntegrationMessage(integrationMessage, MessageStatusEnum.FAILED.getId());
		}
	}

	public String createErrorResponseMsg(Exception exception, String requestXML, Integration integration)
			throws Exception {
		IntegrationMsgResponse msgResponse = new IntegrationMsgResponse();
		Content content = new Content();
		ErrorInfo errorInfo = new ErrorInfo();
		String msgIdXPathStr = ServiceConstants.MESSAGE_ID_XPATH;
		Header header = new Header();
		header.setMessageType(ServiceConstants.ERROR_RESPONSE);
		header.setMessageId(UUID.randomUUID().toString());
		header.setCorrelationId(XMLUtils.getAttributeValue(msgIdXPathStr, requestXML));
		header.setSrcAppId(ServiceConstants.SRC_SYSTEM_MAN);
		header.setUser(userService.getLoggedInUserId());
		errorInfo.setMessage(ExceptionUtilityHelper.getExceptionMessage(exception));
		content.getError().add(errorInfo);
		msgResponse.setContent(content);
		msgResponse.setHeader(header);
		JAXBContext jaxbContext;
		StringWriter writer = new StringWriter();
		String responseXML = null;
		try {
			jaxbContext = JAXBContext.newInstance(IntegrationMsgResponse.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.marshal(msgResponse, writer);
			responseXML = writer.toString();
		} catch (JAXBException e) {
			LOGGER.info(e.toString());
			throw new AppException("Error occured while marshalling data", e);
		}
		LOGGER.info("Error Response: " + responseXML);
		return responseXML;
	}

	public void updateMessageResponse(String responseXml) throws AppException {
		LOGGER.info("Updating Response XML - " + responseXml);
		String xPathStr = ServiceConstants.CORRELATION_ID_XPATH;
		String msgIdXPathStr = ServiceConstants.MESSAGE_ID_XPATH;
		String messageId = XMLUtils.getAttributeValue(xPathStr, responseXml);
		if (StringUtils.isBlank(messageId)) {
			messageId = XMLUtils.getAttributeValue(msgIdXPathStr, responseXml);
		}
		MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessageId(messageId);
		messageResponse.setResponse(responseXml);
		dataAccessService.create(messageResponse);
	}

	public void updateResponseMessage(String requestXml, Integration integrationDetail) throws AppException {
		LOGGER.info(requestXml);
		String xPathStr = ServiceConstants.CORRELATION_ID_XPATH;
		String msgIdXPathStr = ServiceConstants.MESSAGE_ID_XPATH;
		String messageId = XMLUtils.getAttributeValue(xPathStr, requestXml);
		if (StringUtils.isBlank(messageId)) {
			messageId = XMLUtils.getAttributeValue(msgIdXPathStr, requestXml);
		}
		IntegrationMessage integrationMessage = dataAccessService.find(IntegrationMessage.class, messageId);
		dataAccessService.find(Integration.class, integrationDetail.getIntegrationId());
		updateIntegrationMessage(integrationMessage, MessageStatusEnum.COMPLETED.getId());
	}

	private void updateIntegrationMessage(IntegrationMessage integrationMessage, int messageStatusId) {
		integrationMessage.setMessageStatus(messageStatusId);
		dataAccessService.update(integrationMessage);
	}

}
