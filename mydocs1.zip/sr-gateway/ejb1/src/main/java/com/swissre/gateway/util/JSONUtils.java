package com.swissre.gateway.util;

import org.json.JSONObject;
import org.json.JSONTokener;

public class JSONUtils {
	
	public static String getParamValue(String jsonObjectString, String paramName) {
		Object json = new JSONTokener(jsonObjectString).nextValue();
		if (json instanceof JSONObject)
		{
			JSONObject paramsObject = new JSONObject(jsonObjectString);
			if(paramsObject.has(paramName)){
				return (String) paramsObject.get(paramName);							
			}else{
				return null;
			}
		}
		throw new AppException("Invalid configuration. Couldn't find param name - " + paramName + " in JSON string - "+ jsonObjectString);
	}

}
