package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TMESSAGESTATUS database table.
 * 
 */
@Entity
@Table(name="TMESSAGESTATUS")
public class MessageStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STATUS_ID")
	private int statusId;

	@Column(name="STATUS_DESC")
	private String statusDesc;

    public MessageStatus() {
    }

	public int getStatusId() {
		return this.statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public String getStatusDesc() {
		return this.statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

}