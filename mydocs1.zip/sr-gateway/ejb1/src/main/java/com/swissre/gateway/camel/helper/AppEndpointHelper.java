package com.swissre.gateway.camel.helper;

import org.apache.camel.model.ProcessorDefinition;

import com.swissre.gateway.jpa.entities.SystemEndpoint;


public interface AppEndpointHelper {
	
	public enum Direction {
        FROM(1),
        TO(2);
        
    	private int id;
    	
    	private Direction(int id)
    	{
    		this.id = id;
    	}

    	public int getId()
    	{
    		return id;
    	}
    }
	
	void addEndpoint(ProcessorDefinition<?> processDefinition, SystemEndpoint endpoint, Direction direction);
}
