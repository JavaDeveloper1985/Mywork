package com.swissre.gateway.util;

import javax.ejb.EJBException;

import org.apache.camel.component.http.HttpOperationFailedException;

public class ExceptionUtilityHelper {


	public static Exception getExceptionCause(Exception exception) {
		Throwable cause = null;
		while (exception != null) {
			try {
				throw exception;
			} catch (HttpOperationFailedException camelException) {
				 StackTraceElement element = new StackTraceElement( XMLUtils.getAttributeValue(
							ServiceConstants.ERROR_TRACE_XPATH,
							camelException.getResponseBody()),camelException.getLocalizedMessage(),camelException.getUri() ,camelException.getStatusCode());
				 StackTraceElement[] stackTraceElement = new StackTraceElement[]{element};
				 Exception ex = new Exception(camelException.getResponseBody());
				 ex.setStackTrace(stackTraceElement);
				 cause = ex;
				 exception=null;
			}catch (EJBException e) {
				if (cause == null && e.getCausedByException() == null) {
					cause = e;
				}
				exception = e.getCausedByException();
			} catch (Throwable t) {
				cause = t;
				exception = (Exception) t.getCause();
			}
		}
		return (Exception) cause;
	}

	public static String getExceptionMessage(Exception exception) throws Exception {
		String exceptionMsg = null;
		while (exception != null) {
			try {
				throw exception;
			} catch (HttpOperationFailedException camelException) {
				exceptionMsg = XMLUtils.getAttributeValue(
						ServiceConstants.ERROR_MSG_XPATH,
						camelException.getResponseBody());
			} catch (Exception e) {
				exceptionMsg = exception.getMessage();
			}
			break;
		}
		return exceptionMsg;

	}

}
