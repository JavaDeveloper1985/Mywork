package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the V_TRANSFORMATION_DETAILS database table.
 * 
 */
@Entity
@Table(name="V_TRANSFORMATION_DETAILS")
public class TransformationDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="INETGRATIONCONFID_ID")
	private long inetgrationConfidId;

	@Column(name="INTEGRATION_ID")
	private long integrationId;

	@Column(name="TRANSFORMATION_DIRECTION")
	private String transformationDirection;

	@Column(name="TRANSFORMATION_ID")
	private long transformationId;

	@Lob()
	@Column(name="TRANSFORMATION_STYLE")
	private String transformationXSLT;

	@Id
	@Column(name="TRANSFORMATIONRULE_ID")
	private long transformationruleId;

	@Column(name="TRANSFORMATION_PARAMS")
	private String transformationParams;
	
	@Column(name="TRANSFORMATIONTYPE_NAME")
	private String transformationtypeName;

    public TransformationDetail() {
    }

	public long getInetgrationConfidId() {
		return this.inetgrationConfidId;
	}

	public void setInetgrationConfidId(long inetgrationConfidId) {
		this.inetgrationConfidId = inetgrationConfidId;
	}

	public long getIntegrationId() {
		return this.integrationId;
	}

	public void setIntegrationId(long integrationId) {
		this.integrationId = integrationId;
	}

	public String getTransformationDirection() {
		return this.transformationDirection;
	}

	public void setTransformationDirection(String transformationDirection) {
		this.transformationDirection = transformationDirection;
	}

	public long getTransformationId() {
		return this.transformationId;
	}

	public void setTransformationId(long transformationId) {
		this.transformationId = transformationId;
	}

	public long getTransformationruleId() {
		return this.transformationruleId;
	}

	public void setTransformationruleId(long transformationruleId) {
		this.transformationruleId = transformationruleId;
	}

	public String getTransformationtypeName() {
		return this.transformationtypeName;
	}

	public void setTransformationtypeName(String transformationtypeName) {
		this.transformationtypeName = transformationtypeName;
	}
	public String getTransformationXSLT() {
		return transformationXSLT;
	}

	public void setTransformationXSLT(String transformationXSLT) {
		this.transformationXSLT = transformationXSLT;
	}

	public String getTransformationParams() {
		return transformationParams;
	}

	public void setTransformationParams(String transformationParams) {
		this.transformationParams = transformationParams;
	}

}