package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the V_INTEGRATION_MESSAGE database table.
 * 
 */
@Entity
@Table(name="V_INTEGRATION_MESSAGE")
public class IntegrationMessageDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="INTEGRATION_TYPE")
	private String integrationType;

	@Id
	@Column(name="MESSAGE_ID")
	private String messageId;

	private String status;

	@Column(name="SYS_NAME")
	private String sysName;
	
	private Date insdate;
	
    public IntegrationMessageDetail() {
    }

	public String getIntegrationType() {
		return this.integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSysName() {
		return this.sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

	public Date getInsdate() {
		return insdate;
	}

	public void setInsdate(Date insdate) {
		this.insdate = insdate;
	}
}