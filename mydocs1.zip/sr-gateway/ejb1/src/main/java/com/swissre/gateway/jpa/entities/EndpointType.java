package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TENDPOINTTYPE database table.
 * 
 */
@Entity
@Table(name="TENDPOINTTYPE")
public class EndpointType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ENDPOINTTYPE_ID")
	private long endpointtypeId;

	@Column(name="ENDPOINTTYPE_DESC")
	private String endpointtypeDesc;

	@Column(name="ENDPOINTTYPE_NAME")
	private String endpointtypeName;

    public EndpointType() {
    }

	public long getEndpointtypeId() {
		return this.endpointtypeId;
	}

	public void setEndpointtypeId(long endpointtypeId) {
		this.endpointtypeId = endpointtypeId;
	}

	public String getEndpointtypeDesc() {
		return this.endpointtypeDesc;
	}

	public void setEndpointtypeDesc(String endpointtypeDesc) {
		this.endpointtypeDesc = endpointtypeDesc;
	}

	public String getEndpointtypeName() {
		return this.endpointtypeName;
	}

	public void setEndpointtypeName(String endpointtypeName) {
		this.endpointtypeName = endpointtypeName;
	}

}