package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TSYSTEM database table.
 * 
 */
@Entity
@Table(name="TSYSTEM")
public class IntSystem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYS_ID")
	private String sysId;

	@Column(name="SYS_DESC")
	private String sysDesc;

	@Column(name="SYS_NAME")
	private String sysName;

    public IntSystem() {
    }

	public String getSysId() {
		return this.sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	public String getSysDesc() {
		return this.sysDesc;
	}

	public void setSysDesc(String sysDesc) {
		this.sysDesc = sysDesc;
	}

	public String getSysName() {
		return this.sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

}