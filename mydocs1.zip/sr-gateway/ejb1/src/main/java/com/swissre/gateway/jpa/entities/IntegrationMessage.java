package com.swissre.gateway.jpa.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TINTEGRATIONMESSAGE database table.
 * 
 */
@Entity
@Table(name="TINTEGRATIONMESSAGE")
public class IntegrationMessage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MESSAGE_ID")
	private String messageId;

	@Column(name="INTEGRATION_TYPE")
	private String integrationType;

    @Lob()
	private String payload;

	@Column(name="STATUS_ID")
	private int messageStatus;

	//uni-directional many-to-one association to IntSystem
    @ManyToOne
    @PrimaryKeyJoinColumn(name="SRC_SYS_ID")
	private IntSystem system;

	//bi-directional one-to-one association to MessageError
	@OneToOne(mappedBy="integrationMessage")
	private MessageError messageError;

	//bi-directional one-to-one association to MessageResponse
	@OneToOne(mappedBy="integrationMessage")
	private MessageResponse messageResponse;

	//bi-directional many-to-one association to Tintegration
    @ManyToOne
    @PrimaryKeyJoinColumn(name="INTEGRATION_ID")
	private Integration integration;
	
    public Integration getIntegration() {
		return integration;
	}

	public void setIntegration(Integration integration) {
		this.integration = integration;
	}

	public IntegrationMessage() {
    }

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getIntegrationType() {
		return this.integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public int getMessageStatus() {
		return this.messageStatus;
	}

	public void setMessageStatus(int messageStatus) {
		this.messageStatus = messageStatus;
	}
	
	public IntSystem getSystem() {
		return this.system;
	}

	public void setSystem(IntSystem system) {
		this.system = system;
	}
	
	public MessageError getMessageError() {
		return this.messageError;
	}

	public void setMessageError(MessageError messageError) {
		this.messageError = messageError;
	}
	
	public MessageResponse getMessageResponse() {
		return this.messageResponse;
	}

	public void setMessageResponse(MessageResponse messageResponse) {
		this.messageResponse = messageResponse;
	}
	
}