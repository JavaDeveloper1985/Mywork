package com.swissre.gateway.camel.helper;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.swissre.gateway.jpa.entities.SystemEndpoint;
import com.swissre.gateway.util.AppException;
import com.swissre.gateway.util.ServiceConstants;

public class AppEndpointFactory {

	private static final Logger logger = Logger.getLogger(AppEndpointFactory.class.getName());

	private static AppEndpointFactory instance = null;
	private Map<String, AppEndpointHelper> endPointHelperMap = null;
	
	public static AppEndpointFactory getInstance() {
		if (instance == null) {
			instance = new AppEndpointFactory();
		}
		return instance;
	}
	
	private void createEndpointHelpRegistry() {
		try {
			endPointHelperMap = new HashMap<String, AppEndpointHelper>();
			InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(ServiceConstants.ENDPOINT_CONFIG_PROPS);
			Properties properties = new Properties();
			properties.load(inputStream);
			Set<String> helpersSet = properties.stringPropertyNames();
			AppEndpointHelper endpointHelper = null;
			for (String helper : helpersSet) {
				helper = helper.toLowerCase();
				endpointHelper = (AppEndpointHelper)Class.forName(properties.getProperty(helper)).newInstance();
				endPointHelperMap.put(helper, endpointHelper);
			}
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "An error occurred while initializing endpoint helper registry.", ex);
			ex.printStackTrace();
		}
	}

	public AppEndpointHelper retrieveEndPointHelper(SystemEndpoint systemEndpoint) {
		if(endPointHelperMap == null || endPointHelperMap.isEmpty()) {
			createEndpointHelpRegistry();
		}
		String endPointType = systemEndpoint.getEndpointType()
				.getEndpointtypeName().toLowerCase();
		if (endPointHelperMap != null && endPointType != null
				&& endPointHelperMap.get(endPointType.toLowerCase()) != null) {
			return endPointHelperMap.get(endPointType);
		}
		throw new AppException("Invalid configuration. Couldn't retrieve endpoint helper type - " + endPointType);
	}

}
