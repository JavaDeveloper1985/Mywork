package com.swissre.gateway.camel.helper;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.model.ChoiceDefinition;
import org.apache.camel.model.ProcessorDefinition;

import com.swissre.gateway.jpa.entities.Integration;
import com.swissre.gateway.jpa.entities.IntegrationConfig;
import com.swissre.gateway.jpa.entities.SystemEndpoint;
import com.swissre.gateway.jpa.entities.TransformationDirectionEnum;
import com.swissre.gateway.service.MessageService;
import com.swissre.gateway.service.TransformationService;
import com.swissre.gateway.util.AppException;
import com.swissre.gateway.util.JSONUtils;
import com.swissre.gateway.util.ServiceConstants;
import com.swissre.ws.security.WASSecurity;

@Stateless
@LocalBean
public class RouteProcessHelper {
	
	@EJB
	MessageService messageService;
	
	@EJB
	TransformationService transformationService;
	
	public void onException(ProcessorDefinition<?> processDefinition,
			Integration integration) {
		processDefinition.onException(Exception.class).handled(true)
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String body = exchange.getIn().getBody(String.class);
						Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
						messageService.updateMessage(cause, body);
					}
				}).stop();
	}
	
	
	public void onExceptionSendErrorResponse(
			ProcessorDefinition<?> processDefinition,
			final Integration integration) {
		String endPointUrl = getEndPointURL(integration.getAckEndpoint());
		processDefinition.onException(Exception.class).handled(true)
				.process(new Processor() {
					@Override
					public void process(Exchange exchange) throws Exception {
						String body = exchange.getIn().getBody(String.class);
						Exception cause = exchange.getProperty(
								Exchange.EXCEPTION_CAUGHT, Exception.class);
						messageService.updateMessage(cause, body);
						exchange.getIn().setBody(messageService.createErrorResponseMsg(cause,body,integration));
						exchange.getIn().setHeader("Authorization", WASSecurity.getLTPACookie());
					}
				}).to(endPointUrl).stop();
	}
	
	
	
	private String getEndPointURL(SystemEndpoint systemEndpoint) {
		String endPointInfo = systemEndpoint.getEndpoint();
		StringBuffer endpointUrl = new StringBuffer(JSONUtils.getParamValue(
				endPointInfo, ServiceConstants.URL));
	/*	addOptionalParam(endpointUrl, ServiceConstants.CACHELEVELNAME,
				ServiceConstants.CACHENONE);*/
		return endpointUrl.toString();
	}
	
	
	private void addOptionalParam(StringBuffer endpointUrl, String paramName,
			String paramValue) {
		endpointUrl.append(ServiceConstants.AMPERSAND).append(paramName)
				.append(ServiceConstants.EQUAL).append(paramValue);
	}
	
	
	public String createErrorResponseMsg(Exception exception,
			String requestXML, Integration integration) throws Exception {
		String responseXML = null;
		return responseXML;
	}
	
	
	public void persistIncomingMessage(ProcessorDefinition<?> processDefinition,
			final Integration integration) {
		processDefinition.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws AppException {
				String body = exchange.getIn().getBody(String.class);
				exchange.getIn().setBody(messageService.persistMessage(body, integration));
			}
		});
	}
	
	
	
	public void transformXml(ProcessorDefinition<?> processDefinition,
			final IntegrationConfig integrationConfig, final TransformationDirectionEnum direction) {
		processDefinition.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws AppException {
				String body = exchange.getIn().getBody(String.class);
				exchange.getIn().setBody(transformationService.transformXml(body,integrationConfig.getInetgrationconfidId(),direction));
			}
		});
	}
	
	
	public void persistOutgoingMessage(ProcessorDefinition<?> processDefinition) {
		processDefinition.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String requestXml = exchange.getIn().getBody(String.class);
				messageService.updateMessageResponse(requestXml);
				exchange.getIn().setBody(requestXml);
			}
		});
	}
	
	public void persistReponseMessage(ProcessorDefinition<?> processDefinition, final Integration integrationDetail) {
		processDefinition.process(new Processor() {
			@Override
			public void process(Exchange exchange) throws Exception {
				String requestXml = exchange.getIn().getBody(String.class);
				messageService.updateResponseMessage(requestXml,integrationDetail);
				exchange.getIn().setBody(requestXml);
			}
		});
	}
	
	
	public void handleInvalidMessage(ProcessorDefinition<?> processDefinition) {
		if(processDefinition instanceof ChoiceDefinition){
			((ChoiceDefinition)processDefinition).otherwise().process(new Processor() {
				@Override
				public void process(Exchange exchange) throws Exception {
					throw new AppException("Invalid Source App Id & Integration Type combination.");
				}
			});			
		}		
	}
	
}
