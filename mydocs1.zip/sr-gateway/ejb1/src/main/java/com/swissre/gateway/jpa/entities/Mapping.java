package com.swissre.gateway.jpa.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TMAPPING database table.
 * 
 */
@Entity
@Table(name="TMAPPING")
public class Mapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MAPPING_ID")
	private long mappingId;

	@Column(name="FROM_CODETYPE_ID")
	private String fromCodetypeId;

	@Column(name="FROM_VALUE")
	private String fromValue;

	@Column(name="TO_CODETYPE_ID")
	private String toCodetypeId;

	@Column(name="TO_VALUE")
	private String toValue;

    public Mapping() {
    }

	public long getMappingId() {
		return this.mappingId;
	}

	public void setMappingId(long mappingId) {
		this.mappingId = mappingId;
	}

	public String getFromCodetypeId() {
		return this.fromCodetypeId;
	}

	public void setFromCodetypeId(String fromCodetypeId) {
		this.fromCodetypeId = fromCodetypeId;
	}

	public String getFromValue() {
		return this.fromValue;
	}

	public void setFromValue(String fromValue) {
		this.fromValue = fromValue;
	}

	public String getToCodetypeId() {
		return this.toCodetypeId;
	}

	public void setToCodetypeId(String toCodetypeId) {
		this.toCodetypeId = toCodetypeId;
	}

	public String getToValue() {
		return this.toValue;
	}

	public void setToValue(String toValue) {
		this.toValue = toValue;
	}

}