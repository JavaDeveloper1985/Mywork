package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TSYSTEM_ACTION database table.
 * 
 */
@Entity
@Table(name="TSYSTEM_ACTION")
public class SystemAction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACTION_ID")
	private int actionId;

	@Column(name="ACTION_DESC")
	private String actionDesc;

	//bi-directional many-to-one association to SystemActivity
	@OneToMany(mappedBy="systemAction")
	private Set<SystemActivity> systemActivities;

    public SystemAction() {
    }

	public int getActionId() {
		return this.actionId;
	}

	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	public String getActionDesc() {
		return this.actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public Set<SystemActivity> getSystemActivities() {
		return this.systemActivities;
	}

	public void setSystemActivities(Set<SystemActivity> systemActivities) {
		this.systemActivities = systemActivities;
	}
	
}