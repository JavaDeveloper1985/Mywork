package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TTRANSLATION_CONFIG database table.
 * 
 */
@Entity
@Table(name="TTRANSLATION_CONFIG")
public class TranslationConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSLATION_CONFIG_ID")
	private long translationConfigId;

	@Column(name="TRANS_KEY_XPATH")
	private String transKeyXpath;

	@Column(name="TRANS_VALUE_XPATH")
	private String transValueXpath;

	private String type;

	//bi-directional many-to-one association to SourceDataXmlType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="XML_TYPE_ID")
	private SourceDataXmlType sourceDataXmlType;

    public TranslationConfig() {
    }

	public long getTranslationConfigId() {
		return this.translationConfigId;
	}

	public void setTranslationConfigId(long translationConfigId) {
		this.translationConfigId = translationConfigId;
	}

	public String getTransKeyXpath() {
		return this.transKeyXpath;
	}

	public void setTransKeyXpath(String transKeyXpath) {
		this.transKeyXpath = transKeyXpath;
	}

	public String getTransValueXpath() {
		return this.transValueXpath;
	}

	public void setTransValueXpath(String transValueXpath) {
		this.transValueXpath = transValueXpath;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public SourceDataXmlType getSourceDataXmlType() {
		return this.sourceDataXmlType;
	}

	public void setSourceDataXmlType(SourceDataXmlType sourceDataXmlType) {
		this.sourceDataXmlType = sourceDataXmlType;
	}
	
}