package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TTRANSLATIONS database table.
 * 
 */
@Entity
@Table(name="TTRANSLATIONS")
public class Translation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSLATION_ID")
	private long translationId;

	private String code;

	@Column(name="SOURCE_SYSTEM_CODE_TYPE")
	private String sourceSystemCodeType;

	private String translation;

	private String type;

	//bi-directional many-to-one association to Language
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LANGUAGE_ID")
	private Language language;

    public Translation() {
    }

	public long getTranslationId() {
		return this.translationId;
	}

	public void setTranslationId(long translationId) {
		this.translationId = translationId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSourceSystemCodeType() {
		return this.sourceSystemCodeType;
	}

	public void setSourceSystemCodeType(String sourceSystemCodeType) {
		this.sourceSystemCodeType = sourceSystemCodeType;
	}

	public String getTranslation() {
		return this.translation;
	}

	public void setTranslation(String translation) {
		this.translation = translation;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Language getLanguage() {
		return this.language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
}