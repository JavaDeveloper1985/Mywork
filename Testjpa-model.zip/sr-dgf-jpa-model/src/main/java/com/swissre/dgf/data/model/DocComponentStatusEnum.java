package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocComponentStatus} by id.
 */
public enum DocComponentStatusEnum
{
	FORM_DATA_PENDING(1),
	TO_BE_GENERATED(2),
	GENERATING(6),
	EDITABLE(3),
	FINALIZING(4),
	FINAL(5);
	
	private int id;
	
	private DocComponentStatusEnum(int id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code DocComponentStatus}
	 */
	public int getId()
	{
		return id;
	}
}
