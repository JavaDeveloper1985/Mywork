package com.swissre.dgf.data.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TDOC_PACKAGE_PARTNER_ATTS database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_PARTNER_ATTS")
public class DocPackagePartnerAttr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTNERATTS_GENERATOR", sequenceName="SEQ_PARTNERATTS_NO", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTNERATTS_GENERATOR")
	private int id;

	@Column(name="PARTNER_MDM_ID")
	private Integer partnerMDMId;

	@Column(name="PARTNER_NAME")
	private String partnerName;

	@Column(name="PARTNER_TYPE")
	private String partnerType;

	//bi-directional many-to-one association to DocPackageBusinessAttributes
	@ManyToOne 
	@JoinColumn(name="BUS_ATTS_ID")
	private DocPackageBusinessAttributes docPackageBusAttr;

    public DocPackagePartnerAttr() {
    }

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
	public Integer getPartnerMDMId() {
		return partnerMDMId;
	}

	public void setPartnerMDMId(Integer partnerMDMId) {
		this.partnerMDMId = partnerMDMId;
	}

	public String getPartnerName() {
		return this.partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getPartnerType() {
		return this.partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public DocPackageBusinessAttributes getDocPackageBusAttr() {
		return this.docPackageBusAttr;
	}

	public void setDocPackageBusAttr(DocPackageBusinessAttributes docPackageBusAttr) {
		this.docPackageBusAttr = docPackageBusAttr;
	}
	
	
	
}