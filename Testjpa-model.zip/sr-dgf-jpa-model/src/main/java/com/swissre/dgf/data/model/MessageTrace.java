package com.swissre.dgf.data.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TMESSAGE_TRACE database table.
 * 
 */
@Entity
@Table(name="TMESSAGE_TRACE")
public class MessageTrace implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MSG_ID")
	private String msgId;

    @Lob()
	@Column(name="INCOMING_XML")
	private String incomingXml;

    @Lob()
	@Column(name="OUTGOING_XML")
	private String outgoingXml;

	//bi-directional one-to-one association to Message
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private Message message;

    public MessageTrace() {
    }

	public String getMsgId() {
		return this.msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public String getIncomingXml() {
		return this.incomingXml;
	}

	public void setIncomingXml(String incomingXml) {
		this.incomingXml = incomingXml;
	}

	public String getOutgoingXml() {
		return this.outgoingXml;
	}

	public void setOutgoingXml(String outgoingXml) {
		this.outgoingXml = outgoingXml;
	}

	public Message getMessage() {
		return this.message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
}