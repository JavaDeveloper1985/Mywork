package com.swissre.dgf.data.model;

public enum SystemActionEnum {

	DELETEPACKAGE(1),
	TEMPLATECONTENTREMINDER(2);	
	
	private int id;
	
	private SystemActionEnum(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}
}
