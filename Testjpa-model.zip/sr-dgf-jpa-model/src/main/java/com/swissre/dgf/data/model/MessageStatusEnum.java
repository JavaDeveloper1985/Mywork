package com.swissre.dgf.data.model;

/**
 * An enumeration of message statuses.
 */
public enum MessageStatusEnum {

	OPEN('O', "Open"),
    SUCCEEDED('S', "Succeeded"),
    FAILED('F', "Failed");
    
    private final Character code;
    private final String description;
    
	private MessageStatusEnum(Character code, String description) {
		this.code = code;
		this.description = description;
	}

    public Character getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}
}
