package com.swissre.dgf.data.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TMESSAGE_ERROR database table.
 * 
 */
@Entity
@Table(name="TMESSAGE_ERROR")
public class MessageError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MSG_ID")
	private String msgId;

	@Column(name="ERROR_MSG")
	private String errorMsg;

    @Lob()
	@Column(name="STACK_TRACE")
	private String stackTrace;

	//bi-directional one-to-one association to Message
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private Message message;

    public MessageError() {
    }

	public String getMsgId() {
		return this.msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getStackTrace() {
		return this.stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

	public Message getMessage() {
		return this.message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
}