package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TDOC_SOURCE_DATA database table.
 * 
 */
@Entity
@Table(name="TDOC_SOURCE_DATA")
public class DocSourceData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_PKG_ID")
	private long docPkgId;

    @Lob()
	@Column(name="SOURCE_DATA_XML")
	private String sourceDataXml;

    public DocSourceData() {
    }

	public long getDocPkgId() {
		return this.docPkgId;
	}

	public void setDocPkgId(long docPkgId) {
		this.docPkgId = docPkgId;
	}

	public String getSourceDataXml() {
		return this.sourceDataXml;
	}

	public void setSourceDataXml(String sourceDataXml) {
		this.sourceDataXml = sourceDataXml;
	}

}