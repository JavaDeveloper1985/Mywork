package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TUSER_ACTIVITY database table.
 * 
 */
@Entity
@Table(name="TUSER_ACTIVITY")
public class UserActivity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TUSER_ACTIVITY_AUDITID_GENERATOR", sequenceName="SEQ_AUDIT_ID", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TUSER_ACTIVITY_AUDITID_GENERATOR")
	@Column(name="AUDIT_ID")
	private long auditId;

	@Column(name="ACTION_DATE")
	private Timestamp actionDate;

	@Column(name="DOC_COMP_ID")
	private Long docCompId;

	@Column(name="USER_ID")
	private String userId;

	//bi-directional many-to-one association to DocPackage
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_ID")
	private DocPackage docPackage;

	//bi-directional many-to-one association to UserAction
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ACTION_ID")
	private UserAction userAction;

    public UserActivity() {
    }

	public long getAuditId() {
		return this.auditId;
	}

	public void setAuditId(long auditId) {
		this.auditId = auditId;
	}

	public Timestamp getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Timestamp actionDate) {
		this.actionDate = actionDate;
	}

	public Long getDocCompId() {
		return this.docCompId;
	}

	public void setDocCompId(Long docCompId) {
		this.docCompId = docCompId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public DocPackage getDocPackage() {
		return this.docPackage;
	}

	public void setDocPackage(DocPackage docPackage) {
		this.docPackage = docPackage;
	}
	
	public UserAction getUserAction() {
		return this.userAction;
	}

	public void setUserAction(UserAction userAction) {
		this.userAction = userAction;
	}
	
}