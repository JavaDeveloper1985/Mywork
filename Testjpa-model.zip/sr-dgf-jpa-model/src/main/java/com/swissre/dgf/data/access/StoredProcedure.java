package com.swissre.dgf.data.access;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

/**
 * Simplifies execution of stored procedures. Specify the stored procedure name and
 * formal parameters, then execute as many times as required using a {@code Map} of
 * actual parameters. The parameter {@code Map} will contain all OUT parameter values
 * after execution.
 */
public class StoredProcedure
{
    private static final Logger logger = Logger.getLogger(StoredProcedure.class.getName());
    
    public static String DEFAULT_SCHEMA = "DGF";
    
    static {
    	try {
    		Properties StoredProcedureProps = new Properties();
    		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();		
			StoredProcedureProps.load(classLoader.getResourceAsStream("StoredProcedure.properties"));
			DEFAULT_SCHEMA = StoredProcedureProps.getProperty("default.schema");
		} catch (IOException e) {
			logger.info(e.getMessage());
		}		
    	
    }
 
    private final String schemaName;
    
    private final StoredProcedureSpec procedureSpec;

    /**
     * Creates a new {@code StoredProcedure} object with the given name from the
     * default schema defined in the {@code StoredProcedure.properties} file.
     * 
     * @param procedureName
     *            The name of the stored procedure.
     * @return The {@code StoredProcedure} object.
     */
    public static StoredProcedure create(String procedureName)
    {
        return create(DEFAULT_SCHEMA, procedureName);
    }
    
    /**
     * Creates a new {@code StoredProcedure} object with the given name from the given
     * schema.
     * 
     * @param schemaName
     *            The name of the schema.
     * @param procedureName
     *            The name of the stored procedure.
     * @return A new {@code StoredProcedure} object if {@code procedureName} is
     *         not blank or {@code null}. Otherwise, returns {@code null}.
     */
    public static StoredProcedure create(String schemaName, String procedureName)
    {
        return (StringUtils.isBlank(procedureName))
                ? null
                : new StoredProcedure(schemaName, new StoredProcedureSpec(procedureName));
    }
    
    /**
     * Constructor. Defaults the schema based on the
     * {@code StoredProcedure.properties} file.
     * 
     * @param procedureSpec
     *            An object describing the stored procedure.
     */
    private StoredProcedure(StoredProcedureSpec procedureSpec)
    {
        this(DEFAULT_SCHEMA, procedureSpec);
    }

    /**
     * Constructor.
     * 
     * @param schemaName
     *            The name of the schema in which the stored procedure is
     *            defined.
     * @param procedureSpec
     *            An object describing the stored procedure.
     */
    private StoredProcedure(String schemaName, StoredProcedureSpec procedureSpec)
    {
        this.schemaName = schemaName;
        this.procedureSpec = procedureSpec;
    }
    
    public String getSchemaName()
    {
        return schemaName;
    }

    public StoredProcedureSpec getProcedureSpec()
    {
        return procedureSpec;
    }

    public String getFullName()
    {
        String name = procedureSpec.getStoredProcedureName();
        return (schemaName == null) ? (name) : (schemaName + "." + name);
    }

    /**
     * Execute the stored procedure with the given {@code entityManager} and parameters.
     * 
     * @param entityManager A JPA entity manager.
     * @param paramNames An array of parameter names.
     * @param paramValues An array of parameter values corresponding to {@code paramNames}.
     * @return A map from which the OUT parameters may be obtained.
     */
    public Map<String, Object> execute(EntityManager entityManager, String[] paramNames, Object[] paramValues)
    {
        // Put the given parameters in a Map.
        Map<String, Object> params = new HashMap<String, Object>();
        
        if (paramNames != null && paramValues != null)
        {
            if (paramNames.length != paramValues.length)
            {
                throw new RuntimeException(
                        "Failed to execute StoredProcedure: Number of parameter names " +
                        "does not match number of parameter values");
            }
            
            for (int i=0; i<paramNames.length; i++)
            {
                params.put(paramNames[i], paramValues[i]);
            }
        }
        
        execute(entityManager, params);
        
        // Return the param Map so the caller can access OUT parameters.
        return params;
    }

    /**
     * Execute the stored procedure with the given {@code entityManager} and {@code parameters}.
     * The {@code parameters} map will contain OUT parameters after this method returns.
     * 
     * @param entityManager A JPA entity manager.
     * @param parameters A map of name/value pairs.
     */
    public void execute(EntityManager entityManager, final Map<String, Object> parameters)
    {
        // Make sure all JPA statements have been sent to the database server before we execute
        // the stored procedure.
        entityManager.flush();

        // Get a connection from the JPA implementation and execute the stored procedure. This work *MUST*
        // be done over the same database session as any JPA work that is to be performed under the
        // same transaction.
        Connection connection = entityManager.unwrap(Connection.class);
        // Invoke the stored procedure. OUT parameters will be placed in the parameter Map.
        StoredProcedure.this.execute(connection, parameters);
    }

    /**
     * Executes the stored procedure using the given {@code Connection} and the
     * given actual parameters. Any {@code OUT} parameters will be placed in the
     * given parameter map before this method returns.
     * 
     * @param connection
     *            An open JDBC connection.
     * @param parameters
     *            A map of name/value pairs to be used as the stored procedure
     *            parameters.
     */
    public void execute(Connection connection, final Map<String, Object> parameters)
    {
        validateParameters(parameters);
        
        try
        {
            executeStoredProcedure(connection, parameters);
        }
        catch (Exception e)
        {
            throw new RuntimeException(String.format(
                    "Stored procedure execution failed; name=%s, params=%s",
                    getFullName(), parameters.toString()), e);
        }
    }
    
    private void validateParameters(Map<String, ?> parameters)
    {
        Collection<String> missingInParams = new ArrayList<String>();
        for (SqlParamSpec paramSpec : this.procedureSpec.getParamSpecs())
        {
            if (!paramSpec.isOut() && !parameters.containsKey(paramSpec.getName()))
            {
                missingInParams.add(paramSpec.getName());
            }
        }
        
        if (!missingInParams.isEmpty())
        {
            throw new IllegalArgumentException(
                    String.format(
                            "Invalid parameters for stored procedure %s; missing IN parameters: %s",
                            getFullName(), StringUtils.join(missingInParams, ',')));
        }
    }

    private void executeStoredProcedure(Connection conn, Map<String, Object> parameters)
    {
        CallableStatement statement = null;
        
        try
        {
            statement = conn.prepareCall(createCallSql());
            try
            {
                try
                {
                    // Set up the parameters
                    setUpParams(statement, parameters);

                    // Execute the stored procedure
                    statement.execute();

                    // Read the update count, OUT params values, etc.
                    populateOutParamValues(statement, parameters);
                }
                catch (SQLException e)
                {
                    throw new RuntimeException("Failed to execute stored procedure", e);
                }
            }
            finally
            {
                if (statement != null)
                {
                    statement.close();
                }
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Failed to get a CallableStatement", e);
        }
    }

    private String createCallSql()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append("{call ")
            .append(getFullName())
            .append("(")
            .append(StringUtils.repeat("?", ", ", procedureSpec.getParamSpecs().size()))
            .append(")}");
        
        String callSql = sb.toString();
        
        logger.info("SQL call statement: " + callSql);

        return callSql;
    }
    
    private void setUpParams(CallableStatement statement, Map<String, ?> parameters) throws SQLException
    {
        for (SqlParamSpec param : procedureSpec.getParamSpecs())
        {
            if (param.isOut())
            {
                logger.finer("Registering OUT parameter: " + param);
                statement.registerOutParameter(param.getName(), param.getType());
            }
            else
            {
                logger.finer("Registering IN parameter: " + param);
                statement.setObject(param.getName(), parameters.get(param.getName()), param.getType());
            }
        }
    }
    
    /**
     * Reads the OUT param values from the given statement and puts them in the
     * {@code Map} of parameters.
     */
    private void populateOutParamValues(CallableStatement statement,
            Map<String, Object> parameters) throws SQLException
    {
        for (SqlParamSpec param : procedureSpec.getParamSpecs())
        {
            if (param.isOut())
            {
                parameters.put(param.getName(), statement.getObject(param.getName()));
            }
        }
    }

}