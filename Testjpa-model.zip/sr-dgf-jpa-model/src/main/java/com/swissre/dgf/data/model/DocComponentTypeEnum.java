package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocComponentType} by id.
 */
public enum DocComponentTypeEnum
{
	FORM(1),
	MANUSCRIPT(2),
	ATTACHMENT(3);
	
	private int id;
	
	private DocComponentTypeEnum(int id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code DocComponentType}
	 */
	public int getId()
	{
		return id;
	}
}
