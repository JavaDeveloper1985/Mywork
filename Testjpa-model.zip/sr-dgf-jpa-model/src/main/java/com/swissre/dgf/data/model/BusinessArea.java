package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TBUSINESS_AREA_MAPPING database table.
 * 
 */
@Entity
@Table(name="TBUSINESS_AREA_MAPPING")
public class BusinessArea implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MAPPING_ID")
	private long mappingId;

	@Column(name="EDMS_BUS_AREA_CODE")
	private String edmsBusAreaCode;

	@Column(name="PRIMARY_LOB_CODE")
	private Integer primaryLobCode;

	@Column(name="SOURCE_SYSTEM_CODE_TYPE")
	private String sourceSystemCodeType;

    public BusinessArea() {
    }

	public long getMappingId() {
		return this.mappingId;
	}

	public void setMappingId(long mappingId) {
		this.mappingId = mappingId;
	}

	public String getEdmsBusAreaCode() {
		return this.edmsBusAreaCode;
	}

	public void setEdmsBusAreaCode(String edmsBusAreaCode) {
		this.edmsBusAreaCode = edmsBusAreaCode;
	}

	public Integer getPrimaryLobCode() {
		return this.primaryLobCode;
	}

	public void setPrimaryLobCode(Integer primaryLobCode) {
		this.primaryLobCode = primaryLobCode;
	}

	public String getSourceSystemCodeType() {
		return this.sourceSystemCodeType;
	}

	public void setSourceSystemCodeType(String sourceSystemCodeType) {
		this.sourceSystemCodeType = sourceSystemCodeType;
	}

}