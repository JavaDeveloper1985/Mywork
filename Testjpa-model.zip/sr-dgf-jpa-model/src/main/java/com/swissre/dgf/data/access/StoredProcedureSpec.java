package com.swissre.dgf.data.access;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;


/**
 * An enumeration of all the stored procedures used by the Manhattan web services.
 * Each enumeration value will hold a specification of the stored procedure sufficient
 * for the {@code StoredProcedure} class to execute it.
 */
public class StoredProcedureSpec
{
  
    private static ResourceBundle databaseTypeMappings = ResourceBundle
            .getBundle(StoredProcedureSpec.class.getPackage().getName() + ".TypeMappings");
    private static Pattern argumentLinePattern = Pattern.compile("\\s*(\\w+)\\s+(\\w+)\\s+(\\w+)");

    private final String storedProcedureName;
    private String describeFilePath;
    private List<SqlParamSpec> paramSpecs;
    
    public StoredProcedureSpec(String storedProcedureName)
    {
        this.storedProcedureName = storedProcedureName;
    }

    public String getStoredProcedureName()
    {
        return storedProcedureName;
    }
    
    /**
     * Returns a list of {@code SqlParamSpec}s for this procedure.
     * Parses the .describe file for the stored procedure with the given name.
     * 
     * @return A {@code List} of {@code SqlParamSpec} objects that hold metadata
     *         about the parameters of the stored procedure.
     */
    public List<SqlParamSpec> getParamSpecs()
    {
        if (paramSpecs == null)
        {
            paramSpecs = new ArrayList<SqlParamSpec>();
            Scanner scanner = new Scanner(openDescribeFile());
            
            try
            {
	            try
	            {
	                // Read up to and skip the line containing hyphens (that underline column headings).
	                scanner.skip("[^-]*");
	                scanner.nextLine();
	                
	                // Now read each remaining non-blank line and parse into a SqlParamSpec.
	                String line;
	                while (scanner.hasNextLine() && StringUtils.isNotBlank(line = scanner.nextLine()))
	                {
	                    paramSpecs.add(parseParamSpec(line));
	                }
	            }
	            catch (Exception e)
	            {
	                throw new RuntimeException(
	                        "Failed to parse the stored procedure .describe file; location on classpath: "
	                                + describeFilePath, e);
	            }
            }
            finally
            {
            	scanner.close();
            }
        }
        
        return paramSpecs;
    }
    
    private InputStream openDescribeFile()
    {
        InputStream is = getClass().getResourceAsStream(getPathToDescribeFile());
        
        if (is == null)
        {
            throw new IllegalArgumentException(
                    "Could not load stored procedure .describe file from the classpath: "
                            + getPathToDescribeFile());
        }
        
        return is;
    }
    
    private String getPathToDescribeFile()
    {
        if (describeFilePath == null)
        {
            String packagePath = StringUtils.replace(getClass().getPackage().getName(), ".", "/");
            describeFilePath = String.format("/%s/%s.describe", packagePath, storedProcedureName);
        }
        
        return describeFilePath;
    }

    private SqlParamSpec parseParamSpec(String line)
    {
        Matcher matcher = argumentLinePattern.matcher(line);
        
        if (!matcher.find())
        {
            throw new RuntimeException("Could not parse line: '" + line + "'");
        }
        
        String name = matcher.group(1);
        int type = mapToSqlType(matcher.group(2));
        boolean out = "OUT".equals(matcher.group(3));
        
        return new SqlParamSpec(name, type, out);
    }

    private int mapToSqlType(String databaseType)
    {
        try
        {
            String jdbcTypeName = databaseTypeMappings.getString(databaseType);
            Field jdbcTypeField = java.sql.Types.class.getField(jdbcTypeName);
            Integer jdbcType = (Integer) jdbcTypeField.get(null);
            return jdbcType.intValue();
        }
        catch (Exception e)
        {
            throw new RuntimeException(
                    "Unrecognized stored procedure parameter type '"
                            + databaseType + "' found in file "
                            + getPathToDescribeFile());
        }
    }

}
