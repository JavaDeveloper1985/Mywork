package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TDOC_COMPONENT database table.
 * 
 */
@Entity
@Table(name="TDOC_COMPONENT")
public class DocComponent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDOC_COMPONENT_ID_GENERATOR", sequenceName="SEQ_PKGCOMP_NO", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDOC_COMPONENT_ID_GENERATOR")
	@Column(name="DOC_COMP_ID")
	private Long id;

	@Column(name="DOC_COMP_DESC")
	private String docCompDesc;

	@Column(name="DOC_COMP_NAME")
	private String name;

	@Column(name="EDMS_DOC_ID_WORD")
	private String edmsSrDocIdWord;
	
	@Column(name="EDMS_DOC_ID_PDF")
	private String edmsSrDocIdPdf;

	@Column(name="EDMS_REPOSITORY")
	private String edmsRepository;

	@Column(name="INS_DATE")
	private Timestamp insertDate;

	@Column(name="INS_USER")
	private String insertUser;

	private Boolean mandatory;

	private Boolean paginated;

	@Version
	@Column(name="ROW_VERSION")
	private Long rowVersion;

	@Column(name="SEQ_NO")
	private Integer sequence;

	@Column(name="UPD_DATE")
	private Timestamp updateDate;

	@Column(name="UPD_USER")
	private String updateUser;

	//bi-directional many-to-one association to DocComponentStatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_COMP_STATUS_ID")
	private DocComponentStatus docComponentStatus;

	//uni-directional many-to-one association to DocComponentStatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STATUS_ID_BEF_MERGE")
	private DocComponentStatus docCompStatusBeforeMerge;

	//bi-directional many-to-one association to DocComponentType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_COMP_TYPE_ID")
	private DocComponentType docComponentType;

	//uni-directional many-to-one association to DocFormat
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_FORMAT_ID")
	private DocFormat docFormat;

	//bi-directional many-to-one association to DocPackageLang
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_LANG_ID")
	private DocPackageLang docPackageLang;

	//bi-directional many-to-one association to FormDefinitionLang
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FORM_DEF_LANG_ID")
	private FormDefinitionLang formDefinitionLang;

	//bi-directional one-to-one association to FormData
	@OneToOne(mappedBy="docComponent", cascade={CascadeType.REMOVE}, fetch=FetchType.LAZY)
	private FormData formData;

    public DocComponent() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocCompDesc() {
		return this.docCompDesc;
	}

	public void setDocCompDesc(String docCompDesc) {
		this.docCompDesc = docCompDesc;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEdmsSrDocIdWord() {
		return this.edmsSrDocIdWord;
	}

	public void setEdmsSrDocIdWord(String edmsSrDocIdWord) {
		this.edmsSrDocIdWord = edmsSrDocIdWord;
	}

	public String getEdmsRepository() {
		return this.edmsRepository;
	}

	public void setEdmsRepository(String edmsRepository) {
		this.edmsRepository = edmsRepository;
	}

	public Timestamp getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Timestamp insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertUser() {
		return this.insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public Boolean getMandatory() {
		return this.mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public Boolean getPaginated() {
		return this.paginated;
	}

	public void setPaginated(Boolean paginated) {
		this.paginated = paginated;
	}

	public Long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(Long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public Integer getSequence() {
		return this.sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public DocComponentStatus getDocComponentStatus() {
		return this.docComponentStatus;
	}

	public void setDocComponentStatus(DocComponentStatus docComponentStatus) {
		this.docComponentStatus = docComponentStatus;
	}
	
	public DocComponentStatus getDocCompStatusBeforeMerge() {
		return this.docCompStatusBeforeMerge;
	}

	public void setDocCompStatusBeforeMerge(DocComponentStatus docCompStatusBeforeMerge) {
		this.docCompStatusBeforeMerge = docCompStatusBeforeMerge;
	}
	
	public DocComponentType getDocComponentType() {
		return this.docComponentType;
	}

	public void setDocComponentType(DocComponentType docComponentType) {
		this.docComponentType = docComponentType;
	}
	
	public DocFormat getDocFormat() {
		return this.docFormat;
	}

	public void setDocFormat(DocFormat docFormat) {
		this.docFormat = docFormat;
	}
	
	public DocPackageLang getDocPackageLang() {
		return this.docPackageLang;
	}

	public void setDocPackageLang(DocPackageLang docPackageLang) {
		this.docPackageLang = docPackageLang;
	}
	
	public FormDefinitionLang getFormDefinitionLang() {
		return this.formDefinitionLang;
	}

	public void setFormDefinitionLang(FormDefinitionLang formDefinitionLang) {
		this.formDefinitionLang = formDefinitionLang;
	}
	
	public FormData getFormData() {
		return this.formData;
	}

	public void setFormData(FormData formData) {
		this.formData = formData;
	}

	public String getEdmsSrDocIdPdf() {
		return edmsSrDocIdPdf;
	}

	public void setEdmsSrDocIdPdf(String edmsSrDocIdPdf) {
		this.edmsSrDocIdPdf = edmsSrDocIdPdf;
	}
	
}