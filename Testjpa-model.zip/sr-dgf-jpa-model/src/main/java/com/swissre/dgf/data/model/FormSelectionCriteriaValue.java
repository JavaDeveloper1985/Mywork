package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TFORM_SELECT_CRITERIA_VALUES database table.
 * 
 */
@Entity
@Table(name="TFORM_SELECT_CRITERIA_VALUES")
public class FormSelectionCriteriaValue implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CRITERIA_VALUE_ID")
	private long id;

	@Column(name="CRITERIA_DESC")
	private String criteriaDesc;

	@Column(name="CRITERIA_TYPE")
	private String criteriaType;

	@Column(name="CRITERIA_VALUE")
	private String criteriaValue;

	//bi-directional many-to-one association to SourceSystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_SYSTEM_ID")
	private SourceSystem sourceSystem;

    public FormSelectionCriteriaValue() {
    }

	public long getId() {
		return this.id;
	}

	public void seId(long id) {
		this.id = id;
	}

	public String getCriteriaDesc() {
		return this.criteriaDesc;
	}

	public void setCriteriaDesc(String criteriaDesc) {
		this.criteriaDesc = criteriaDesc;
	}

	public String getCriteriaType() {
		return this.criteriaType;
	}

	public void setCriteriaType(String criteriaType) {
		this.criteriaType = criteriaType;
	}

	public String getCriteriaValue() {
		return this.criteriaValue;
	}

	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}

	public SourceSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
}