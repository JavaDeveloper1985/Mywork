package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocumentFormat} by id.
 */
public enum DocumentFormatEnum
{
	WORD("1"),
	PDF("2"),
	RTF("3");
	
	private String id;
	
	private DocumentFormatEnum(String id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code DocumentFormat}
	 */
	public String getId()
	{
		return id;
	}
}
