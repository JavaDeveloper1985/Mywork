package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocComponentType} by id.
 */
public enum UserActionEnum
{
	ADD(1),
	PACKAGEDATAUPDATE(2),
	FORMDATAUPDATE(3),
	GENERATE(4),
	CHECKOUT(5),
	CANCELCHECKOUT(6),
	CHECKIN(7),
	REVERT(8),
	DELETE(9),
	REOPEN(10),
	FINALIZE(11),
	REGENERATE(12),
	MARGEPACKAGE(13),
	REVERTPACKAGE(14),
	ADDMANUSCRIPT(15),
	UPLOADATTACHMENT(16),
	NEWLANGADDITION(17),
	LANGDELETION(18),
	DEACTIVATEPACKAGE(19);
	
	private int id;
	
	private UserActionEnum(int id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code DocComponentType}
	 */
	public int getId()
	{
		return id;
	}
}
