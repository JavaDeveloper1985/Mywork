package com.swissre.dgf.data.model;

/**
 * Holds information necessary to initialize a form (i.e., a
 * {@code DocComponent} of type form).
 */
public class FormInit {

	private FormDefinitionLang formDefinitionLang;
	private Boolean mandatory;
	private String dataPath;
	private String formDataIdentifier;
	
	public FormInit() {
	}
	
	public FormInit(FormDefinitionLang formDefinitionLang, Boolean mandatory, String dataPath, String formDataIdentifier) {
		setFormDefinitionLang(formDefinitionLang);
		setMandatory(mandatory);
		setDataPath(dataPath);
		setFormDataIdentifier(formDataIdentifier);
	}
	
	public FormDefinitionLang getFormDefinitionLang() {
		return formDefinitionLang;
	}
	
	public void setFormDefinitionLang(FormDefinitionLang formDefinitionLang) {
		this.formDefinitionLang = formDefinitionLang;
	}

	/**
	 * A property used to hold an additional field returned from the form selection
	 * module. This value indicates whether the form is considered mandatory for
	 * the given package type.
	 */
	public Boolean getMandatory() {
		return mandatory;
	}
	
	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public String getDataPath() {
		return dataPath;
	}

	public void setDataPath(String dataPath) {
		this.dataPath = dataPath;
	}

	public String getFormDataIdentifier() {
		return formDataIdentifier;
	}

	public void setFormDataIdentifier(String formDataIdentifier) {
		this.formDataIdentifier = formDataIdentifier;
	}	
}
