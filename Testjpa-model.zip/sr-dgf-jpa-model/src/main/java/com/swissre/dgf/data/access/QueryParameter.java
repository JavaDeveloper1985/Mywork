package com.swissre.dgf.data.access;

import java.util.HashMap;
import java.util.Map;

/**
 * A utility class that simplifies the specification of query parameters.  Typically, the static
 * methods would be imported statically and used as shown in the following example:
 * 
 * <code>
 * 		List<FormDefinition> formDefs = 
			dataAccessService.findSingleResultWithNamedQuery(
					FormDefinition.class,
					"FormDefinition.sampleNamedQuery",
					with("editable", Boolean.TRUE)
					and("approved", Boolean.TRUE).parameters());
 * </code>
 * 
 * See the <a href="http://www.adam-bien.com/roller/abien/entry/generic_crud_service_aka_dao">
 * Generic CRUD Service</a> article for more info.
 */
public class QueryParameter
{
	private Map<String, Object> parameters;

	private QueryParameter(String name, Object value)
	{
		this.parameters = new HashMap<String, Object>();
		this.parameters.put(name, value);
	}

	public static QueryParameter with(String name, Object value)
	{
		return new QueryParameter(name, value);
	}

	public QueryParameter and(String name, Object value)
	{
		this.parameters.put(name, value);
		return this;
	}

	public Map<String, Object> parameters()
	{
		return this.parameters;
	}
}