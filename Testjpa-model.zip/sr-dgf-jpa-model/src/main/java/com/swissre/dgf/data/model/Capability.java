package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TCAPABILITY database table.
 * 
 */
@Entity
@Table(name="TCAPABILITY")
public class Capability implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CAPABILITY_ID")
	private Integer id;

	@Column(name="CAPABILITY_DESC")
	private String description;

	@Column(name="CAPABILITY_NAME")
	private String name;

	//bi-directional many-to-one association to Authorization
	@OneToMany(mappedBy="capability")
	private Set<Authorization> authorizations;

    public Capability() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Authorization> getAuthorizations() {
		return this.authorizations;
	}

	public void setAuthorizations(Set<Authorization> authorizations) {
		this.authorizations = authorizations;
	}
	
}