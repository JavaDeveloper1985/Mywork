package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TUSER_ACTION database table.
 * 
 */
@Entity
@Table(name="TUSER_ACTION")
public class UserAction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACTION_ID")
	private int actionId;

	@Column(name="ACTION_DESC")
	private String actionDesc;

	//bi-directional many-to-one association to UserActivity
	@OneToMany(mappedBy="userAction")
	private Set<UserActivity> userActivities;

    public UserAction() {
    }

	public int getActionId() {
		return this.actionId;
	}

	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	public String getActionDesc() {
		return this.actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public Set<UserActivity> getUserActivities() {
		return this.userActivities;
	}

	public void setUserActivities(Set<UserActivity> userActivities) {
		this.userActivities = userActivities;
	}
	
}