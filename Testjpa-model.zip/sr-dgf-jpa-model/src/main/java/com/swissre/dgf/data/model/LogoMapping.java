package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TLOGO_MAPPING database table.
 * 
 */
@Entity
@Table(name="TLOGO_MAPPING")
public class LogoMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PROFIT_CENTER_ID")
	private String profitCenterId;

	@Column(name="LOGO_NAME")
	private String logoName;

    public LogoMapping() {
    }

	public String getProfitCenterId() {
		return this.profitCenterId;
	}

	public void setProfitCenterId(String profitCenterId) {
		this.profitCenterId = profitCenterId;
	}

	public String getLogoName() {
		return this.logoName;
	}

	public void setLogoName(String logoName) {
		this.logoName = logoName;
	}

}