package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Set;


/**
 * The persistent class for the TDOC_SUB_PACKAGE_TYPE database table.
 * 
 */
@Entity
@Table(name="TDOC_SUB_PACKAGE_TYPE")
public class DocSubPackageType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_SUB_PKG_TYP_ID")
	private Integer docSubPkgTypId;

	@Column(name="DFLT_MERGED_DOC_FORMAT_ID")
	private String dfltMergedDocFormatId;

	@Column(name="DOC_SUB_PKG_TYP_CODE")
	private String docSubPkgTypCode;

	@Column(name="DOC_SUB_PKG_TYP_DESC")
	private String docSubPkgTypDesc;

	@Column(name="EDMS_ACL_TYPE")
	private String edmsAclType;

	@Column(name="EDMS_BUS_FUN_CODE")
	private String edmsBusFunCode;

	@Column(name="EDMS_DOC_CATEGORY")
	private String edmsDocCategory;

	@Column(name="EDMS_DOC_TYPE")
	private String edmsDocType;

	@Column(name="EDMS_OBJECT_TYPE")
	private String edmsObjectType;
	
	//bi-directional many-to-one association to DocPackage
	@OneToMany(mappedBy="docSubPackageType")
	private Set<DocPackage> docPackages;
	
	//bi-directional many-to-one association to DocSubPackageType
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_TYP_ID")
	private DocPackageType docPackageType;

    public DocSubPackageType() {
    }

	public Integer getDocSubPkgTypId() {
		return this.docSubPkgTypId;
	}

	public void setDocSubPkgTypId(Integer docSubPkgTypId) {
		this.docSubPkgTypId = docSubPkgTypId;
	}

	public String getDfltMergedDocFormatId() {
		return this.dfltMergedDocFormatId;
	}

	public void setDfltMergedDocFormatId(String dfltMergedDocFormatId) {
		this.dfltMergedDocFormatId = dfltMergedDocFormatId;
	}

	public String getDocSubPkgTypCode() {
		return this.docSubPkgTypCode;
	}

	public void setDocSubPkgTypCode(String docSubPkgTypCode) {
		this.docSubPkgTypCode = docSubPkgTypCode;
	}

	public String getDocSubPkgTypDesc() {
		return this.docSubPkgTypDesc;
	}

	public void setDocSubPkgTypDesc(String docSubPkgTypDesc) {
		this.docSubPkgTypDesc = docSubPkgTypDesc;
	}

	public String getEdmsAclType() {
		return this.edmsAclType;
	}

	public void setEdmsAclType(String edmsAclType) {
		this.edmsAclType = edmsAclType;
	}

	public String getEdmsBusFunCode() {
		return this.edmsBusFunCode;
	}

	public void setEdmsBusFunCode(String edmsBusFunCode) {
		this.edmsBusFunCode = edmsBusFunCode;
	}

	public String getEdmsDocCategory() {
		return this.edmsDocCategory;
	}

	public void setEdmsDocCategory(String edmsDocCategory) {
		this.edmsDocCategory = edmsDocCategory;
	}

	public String getEdmsDocType() {
		return this.edmsDocType;
	}

	public void setEdmsDocType(String edmsDocType) {
		this.edmsDocType = edmsDocType;
	}

	public String getEdmsObjectType() {
		return this.edmsObjectType;
	}

	public void setEdmsObjectType(String edmsObjectType) {
		this.edmsObjectType = edmsObjectType;
	}
	
	public Set<DocPackage> getDocPackages() {
		return this.docPackages;
	}

	public void setDocPackages(Set<DocPackage> docPackages) {
		this.docPackages = docPackages;
	}
	
	public DocPackageType getDocPackageType() {
		return this.docPackageType;
	}

	public void setDocPackageType(DocPackageType docPackageType) {
		this.docPackageType = docPackageType;
	}

}