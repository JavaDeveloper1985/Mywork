package com.swissre.dgf.data.model;

public enum ITSMEventActionEnum {
	CREATE_INCIDENT("incident"),
	CHECK_INCIDENT_CREATION_STATUS("status");

	private final String name;

	private ITSMEventActionEnum(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
