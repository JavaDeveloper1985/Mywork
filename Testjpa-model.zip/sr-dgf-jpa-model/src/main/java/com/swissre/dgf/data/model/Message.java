package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * The persistent class for the TMESSAGE database table.
 * 
 */
@Entity
@Table(name="TMESSAGE")
public class Message implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MSG_ID")
	private String id;

	@Column(name="MSG_END")
	private Timestamp msgEnd;

	@Column(name="MSG_START")
	private Timestamp msgStart;

	private Character status;

	//bi-directional many-to-one association to ApplicationErrorLog
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ERROR_CASE_ID")
	private ApplicationErrorLog applicationErrorLog;

	//bi-directional one-to-one association to MessageTrace
	@OneToOne(mappedBy="message", cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE}, fetch=FetchType.LAZY)
	private MessageTrace messageTrace;

    public Message() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Timestamp getMsgEnd() {
		return this.msgEnd;
	}

	public void setMsgEnd(Timestamp msgEnd) {
		this.msgEnd = msgEnd;
	}

	public Timestamp getMsgStart() {
		return this.msgStart;
	}

	public void setMsgStart(Timestamp msgStart) {
		this.msgStart = msgStart;
	}

	public Character getStatus() {
		return this.status;
	}

	public void setStatus(Character status) {
		this.status = status;
	}

	public ApplicationErrorLog getApplicationErrorLog() {
		return this.applicationErrorLog;
	}

	public void setApplicationErrorLog(ApplicationErrorLog applicationErrorLog) {
		this.applicationErrorLog = applicationErrorLog;
	}
	
	public MessageTrace getMessageTrace() {
		return this.messageTrace;
	}

	public void setMessageTrace(MessageTrace messageTrace) {
		this.messageTrace = messageTrace;
	}
	
}