package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TDOC_PACKAGE_DEACTIVATE_REASON database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_DEACTIVATE_REASON")
public class DocPackageDeactivateReason implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_PKG_ID")
	private long docPkgId;

    @Temporal( TemporalType.DATE)
	@Column(name="INS_DATE")
	private Date insertDate;

	@Column(name="INS_USER")
	private String insertUser;

	@Column(name="REASON")
	private String reason;

    @Temporal( TemporalType.DATE)
	@Column(name="UPD_DATE")
	private Date updateDate;

	@Column(name="UPD_USER")
	private String updateUser;

	//bi-directional one-to-one association to DocPackage
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private DocPackage docPackage;

    public DocPackageDeactivateReason() {
    }

	public long getDocPkgId() {
		return this.docPkgId;
	}

	public void setDocPkgId(long docPkgId) {
		this.docPkgId = docPkgId;
	}

	public Date getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertUser() {
		return this.insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public DocPackage getDocPackage() {
		return this.docPackage;
	}

	public void setDocPackage(DocPackage docPackage) {
		this.docPackage = docPackage;
	}
	
}