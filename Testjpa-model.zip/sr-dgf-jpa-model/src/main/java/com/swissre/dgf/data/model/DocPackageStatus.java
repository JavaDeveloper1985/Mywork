package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TDOC_PACKAGE_STATUS database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_STATUS")
public class DocPackageStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_PKG_STATUS_ID")
	private Integer id;

	@Column(name="DOC_PKG_STATUS_DESC")
	private String description;
	
	@Column(name="DISPLAY_ORDER")
	private Integer displayOrder;

    public DocPackageStatus() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	

}