package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TFORM_DEFINITION_LANG database table.
 * 
 */
@Entity
@Table(name="TFORM_DEFINITION_LANG")
public class FormDefinitionLang implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FORM_DEF_LANG_ID")
	private Long id;

	private Boolean approved;

	@Column(name="BOOKMARK_COUNT")
	private Long bookmarkCount;

	@Column(name="BOOKMARK_PREFIX")
	private String bookmarkPrefix;

    @Temporal( TemporalType.DATE)
	@Column(name="EFFECTIVE_DATE")
	private Date effectiveDate;

	@Column(name="FORM_DATA_UPDT_MANDATORY")
	private Boolean formDataUpdateMandatory;

    @Lob()
	@Column(name="FORM_DEF_XML")
	private String formDefXml;

	@Column(name="TEMPLATE_NAME")
	private String templateName;

    @Temporal( TemporalType.DATE)
	@Column(name="TERMINATION_DATE")
	private Date terminationDate;

	//bi-directional many-to-one association to DocComponent
	@OneToMany(mappedBy="formDefinitionLang")
	private Set<DocComponent> docComponents;

	//uni-directional many-to-one association to DocFormat
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_FORMAT_ID")
	private DocFormat docFormat;

	//bi-directional many-to-one association to FormDefinition
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FORM_DEF_ID")
	private FormDefinition formDefinition;

	//uni-directional many-to-one association to Language
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LANGUAGE_ID")
	private Language language;

	//uni-directional many-to-one association to SourceDataXmlType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="XML_TYPE_ID")
	private SourceDataXmlType sourceDataXmlType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SAMPLE_XML_ID")
	private TemplateGenerateSampleXml templateGenerateSampleXml;

    public FormDefinitionLang() {
    }
   
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getApproved() {
		return this.approved;
	}

	public void setApproved(Boolean approved) {
		this.approved = approved;
	}

	public Long getBookmarkCount() {
		return this.bookmarkCount;
	}

	public void setBookmarkCount(Long bookmarkCount) {
		this.bookmarkCount = bookmarkCount;
	}

	public String getBookmarkPrefix() {
		return this.bookmarkPrefix;
	}

	public void setBookmarkPrefix(String bookmarkPrefix) {
		this.bookmarkPrefix = bookmarkPrefix;
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Boolean getFormDataUpdateMandatory() {
		return this.formDataUpdateMandatory;
	}

	public void setFormDataUpdateMandatory(Boolean formDataUpdateMandatory) {
		this.formDataUpdateMandatory = formDataUpdateMandatory;
	}

	public String getFormDefXml() {
		return this.formDefXml;
	}

	public void setFormDefXml(String formDefXml) {
		this.formDefXml = formDefXml;
	}

	public String getTemplateName() {
		return this.templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Date getTerminationDate() {
		return this.terminationDate;
	}

	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	public Set<DocComponent> getDocComponents() {
		return this.docComponents;
	}

	public void setDocComponents(Set<DocComponent> docComponents) {
		this.docComponents = docComponents;
	}
	
	public DocFormat getDocFormat() {
		return this.docFormat;
	}

	public void setDocFormat(DocFormat docFormat) {
		this.docFormat = docFormat;
	}
	
	public FormDefinition getFormDefinition() {
		return this.formDefinition;
	}

	public void setFormDefinition(FormDefinition formDefinition) {
		this.formDefinition = formDefinition;
	}
	
	public Language getLanguage() {
		return this.language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
	public SourceDataXmlType getSourceDataXmlType() {
		return this.sourceDataXmlType;
	}

	public void setSourceDataXmlType(SourceDataXmlType sourceDataXmlType) {
		this.sourceDataXmlType = sourceDataXmlType;
	}

	public TemplateGenerateSampleXml getTemplateGenerateSampleXml() {
		return templateGenerateSampleXml;
	}

	public void setTemplateGenerateSampleXml(
			TemplateGenerateSampleXml templateGenerateSampleXml) {
		this.templateGenerateSampleXml = templateGenerateSampleXml;
	}

}