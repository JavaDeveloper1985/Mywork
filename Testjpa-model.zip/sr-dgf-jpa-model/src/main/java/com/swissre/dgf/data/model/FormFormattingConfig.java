package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TFORM_FORMATTING_CONFIG database table.
 * 
 */
@Entity
@Table(name="TFORM_FORMATTING_CONFIG")
public class FormFormattingConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FORMATTING_CONFIG_ID")
	private long id;

	@Column(name="DATA_TYPE")
	private String dataType;

	@Column(name="FORMATTING_XPATH")
	private String formattingXpath;

	//bi-directional many-to-one association to FormDataXmlType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FORM_XML_TYPE_ID")
	private FormDataXmlType formDataXmlType;

	//bi-directional many-to-one association to DocGenLocale
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DEFAULT_FORMATTING_LOCALE")
	private DocGenLocale defaultLocale;
	
	@Column(name="DEFAULT_FORMATTING")
	private String defaultFormatting;
	
	@Column(name="REPEATING_FIELD_DELIMITER")
	private String repeatingFieldDelimiter;

	public FormFormattingConfig() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDataType() {
		return this.dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getFormattingXpath() {
		return this.formattingXpath;
	}

	public void setFormattingXpath(String formattingXpath) {
		this.formattingXpath = formattingXpath;
	}

	public FormDataXmlType getFormDataXmlType() {
		return this.formDataXmlType;
	}

	public void setFormDataXmlType(FormDataXmlType formDataXmlType) {
		this.formDataXmlType = formDataXmlType;
	}
	
	public DocGenLocale getDefaultLocale() {
		return this.defaultLocale;
	}

	public void setDefaultLocale(DocGenLocale defaultLocale) {
		this.defaultLocale = defaultLocale;
	}

	public String getDefaultFormatting() {
		return defaultFormatting;
	}

	public void setDefaultFormatting(String defaultFormatting) {
		this.defaultFormatting = defaultFormatting;
	}
	
    public String getRepeatingFieldDelimiter() {
		return repeatingFieldDelimiter;
	}

	public void setRepeatingFieldDelimiter(String repeatingFieldDelimiter) {
		this.repeatingFieldDelimiter = repeatingFieldDelimiter;
	}
}