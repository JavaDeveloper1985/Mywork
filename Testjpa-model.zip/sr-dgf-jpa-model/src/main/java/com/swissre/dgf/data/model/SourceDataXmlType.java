package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TSOURCE_DATA_XML_TYPE database table.
 * 
 */
@Entity
@Table(name="TSOURCE_DATA_XML_TYPE")
public class SourceDataXmlType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="XML_TYPE_ID")
	private long xmlTypeId;

	private String qname;

	//bi-directional many-to-one association to TranslationConfig
	@OneToMany(mappedBy="sourceDataXmlType")
	private Set<TranslationConfig> translationConfigs;

    public SourceDataXmlType() {
    }

	public long getXmlTypeId() {
		return this.xmlTypeId;
	}

	public void setXmlTypeId(long xmlTypeId) {
		this.xmlTypeId = xmlTypeId;
	}

	public String getQname() {
		return this.qname;
	}

	public void setQname(String qname) {
		this.qname = qname;
	}

	public Set<TranslationConfig> getTranslationConfigs() {
		return this.translationConfigs;
	}

	public void setTranslationConfigs(Set<TranslationConfig> translationConfigs) {
		this.translationConfigs = translationConfigs;
	}
	
}