package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TAUTHORIZATION database table.
 * 
 */
@Entity
@Table(name="TAUTHORIZATION")
public class Authorization implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="AUTH_ID")
	private Integer id;

	//bi-directional many-to-one association to ApplicationRole
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ROLE_ID")
	private ApplicationRole applicationRole;

	//bi-directional many-to-one association to Capability
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CAPABILITY_ID")
	private Capability capability;

	//bi-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_TYP_ID")
	private DocPackageType docPackageType;

	//uni-directional many-to-one association to SourceSystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_SYSTEM_ID")
	private SourceSystem sourceSystem;

    public Authorization() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ApplicationRole getApplicationRole() {
		return this.applicationRole;
	}

	public void setApplicationRole(ApplicationRole applicationRole) {
		this.applicationRole = applicationRole;
	}
	
	public Capability getCapability() {
		return this.capability;
	}

	public void setCapability(Capability capability) {
		this.capability = capability;
	}
	
	public DocPackageType getDocPackageType() {
		return this.docPackageType;
	}

	public void setDocPackageType(DocPackageType docPackageType) {
		this.docPackageType = docPackageType;
	}
	
	public SourceSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
}