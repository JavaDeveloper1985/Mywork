package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the TLANGUAGE database table.
 * 
 */
@Entity
@Table(name="TLANGUAGE")
public class Language implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LANGUAGE_ID")
	private String id;

	@Column(name="LANGUAGE_DESC")
	private String description;

	//bi-directional many-to-one association to Translation
	@OneToMany(mappedBy="language")
	private Set<Translation> translations;

    public Language() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Translation> getTranslations() {
		return this.translations;
	}

	public void setTranslations(Set<Translation> translations) {
		this.translations = translations;
	}
	
}