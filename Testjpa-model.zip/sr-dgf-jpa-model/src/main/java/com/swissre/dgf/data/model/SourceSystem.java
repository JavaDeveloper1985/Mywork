package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TSOURCE_SYSTEM database table.
 * 
 */
@Entity
@Table(name="TSOURCE_SYSTEM")
public class SourceSystem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SOURCE_SYSTEM_ID")
	private String id;

	@Column(name="CODE_TYPE")
	private String codeType;

	@Column(name="EDMS_REPOSITORY")
	private String edmsRepository;

	@Column(name="SOURCE_SYSTEM_NAME")
	private String name;
	
	@Column(name="TEMPLATE_SEARCH_ENABLED")
	private Boolean templateSearchEnabled;

	//bi-directional many-to-one association to DocPackage
	@OneToMany(mappedBy="sourceSystem")
	private Set<DocPackage> docPackages;

	//bi-directional many-to-one association to TransformationRule
	@OneToMany(mappedBy="sourceSystem")
	private Set<TransformationRule> transformationRules;

	//bi-directional many-to-one association to ValidationControl
	@OneToMany(mappedBy="sourceSystem")
	private Set<ValidationControl> validationControls;

	//bi-directional many-to-one association to FormSelectionCriteriaValue
	@OneToMany(mappedBy="sourceSystem")
	private Set<FormSelectionCriteriaValue> formSelectionCriteriaValues;
	
    public SourceSystem() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCodeType() {
		return this.codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getEdmsRepository() {
		return this.edmsRepository;
	}

	public void setEdmsRepository(String edmsRepository) {
		this.edmsRepository = edmsRepository;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<DocPackage> getDocPackages() {
		return this.docPackages;
	}

	public void setDocPackages(Set<DocPackage> docPackages) {
		this.docPackages = docPackages;
	}
	
	public Set<TransformationRule> getTransformationRules() {
		return this.transformationRules;
	}

	public void setTransformationRules(Set<TransformationRule> transformationRules) {
		this.transformationRules = transformationRules;
	}
	
	public Set<ValidationControl> getValidationControls() {
		return this.validationControls;
	}

	public void setValidationControls(Set<ValidationControl> validationControls) {
		this.validationControls = validationControls;
	}
	
	public Set<FormSelectionCriteriaValue> getFormSelectionCriteriaValues() {
		return this.formSelectionCriteriaValues;
	}

	public void setFormSelectionCriteriaValues(Set<FormSelectionCriteriaValue> formSelectionCriteriaValues) {
		this.formSelectionCriteriaValues = formSelectionCriteriaValues;
	}

	public Boolean isTemplateSearchEnabled() {
		return templateSearchEnabled;
	}

	public void setTemplateSearchEnabled(Boolean templateSearchEnabled) {
		this.templateSearchEnabled = templateSearchEnabled;
	}	
}