package com.swissre.dgf.data.access;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;
import java.util.logging.Logger;

import javax.persistence.EntityManager;


public class StoredFuntion {

    private static final Logger logger = Logger.getLogger(StoredFuntion.class.getName());
    
    public static String DEFAULT_SCHEMA = "DGF";
    
    static {
    	try {
    		Properties StoredProcedureProps = new Properties();
    		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();		
			StoredProcedureProps.load(classLoader.getResourceAsStream("StoredProcedure.properties"));
			DEFAULT_SCHEMA = StoredProcedureProps.getProperty("default.schema");
		} catch (IOException e) {
			logger.info(e.getMessage());
		}		
    	
    }
 
    /**
     * Execute the Function that has no arguments.
     * 
     * @param entityManager A JPA entity manager.
     * @param functionName The function name.
     * @param returnType The oracle retun type.
     * @return the Object.
     */
	public static Object executeNoArgumentFunction(EntityManager entityManager, final String functionName, final int oracleReturnType){
		Connection connection = entityManager.unwrap(Connection.class);
    	return StoredFuntion.executeNoArgumentFunction(connection, functionName, oracleReturnType);
    }
    
    
	private static Object executeNoArgumentFunction(Connection connection, String functionName, int returnType) {
			Object returnValue = null;
		  	CallableStatement stmt;
			try {
				stmt = connection.prepareCall ("{? = call "+DEFAULT_SCHEMA+"."+functionName +"()}");
				stmt.registerOutParameter(1, returnType);
				stmt.execute();
				if(returnType == Types.INTEGER){
					returnValue = stmt.getInt(1);
				} else {
					returnValue = stmt.getString(1);
				}
				
			} catch (SQLException e) {
				throw new RuntimeException("Failed to execute function "+functionName, e);
			}   
			return returnValue;
	}
}
