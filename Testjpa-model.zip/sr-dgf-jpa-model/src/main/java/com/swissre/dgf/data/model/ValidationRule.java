package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TVALIDATION_RULES database table.
 * 
 */
@Entity
@Table(name="TVALIDATION_RULES")
public class ValidationRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="VALIDATION_ID")
	private long validationId;

	private String qname;

	//bi-directional many-to-one association to ApplicationResource
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="XSD_RESOURCE_ID")
	private ApplicationResource applicationResource;

    public ValidationRule() {
    }

	public long getValidationId() {
		return this.validationId;
	}

	public void setValidationId(long validationId) {
		this.validationId = validationId;
	}

	public String getQname() {
		return this.qname;
	}

	public void setQname(String qname) {
		this.qname = qname;
	}

	public ApplicationResource getApplicationResource() {
		return this.applicationResource;
	}

	public void setApplicationResource(ApplicationResource applicationResource) {
		this.applicationResource = applicationResource;
	}
	
}