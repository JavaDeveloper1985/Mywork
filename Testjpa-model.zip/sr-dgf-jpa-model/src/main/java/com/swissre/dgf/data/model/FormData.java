package com.swissre.dgf.data.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TFORM_DATA database table.
 * 
 */
@Entity
@Table(name="TFORM_DATA")
public class FormData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_COMP_ID")
	private long docCompId;

    @Lob()
	@Column(name="FORM_XML")
	private String formXml;

	//bi-directional one-to-one association to DocComponent
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private DocComponent docComponent;

    public FormData() {
    }

	public long getDocCompId() {
		return this.docCompId;
	}

	public void setDocCompId(long docCompId) {
		this.docCompId = docCompId;
	}

	public String getFormXml() {
		return this.formXml;
	}

	public void setFormXml(String formXml) {
		this.formXml = formXml;
	}

	public DocComponent getDocComponent() {
		return this.docComponent;
	}

	public void setDocComponent(DocComponent docComponent) {
		this.docComponent = docComponent;
	}
	
}