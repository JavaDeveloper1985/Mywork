package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TSYSTEM_ACTIVITY database table.
 * 
 */
@Entity
@Table(name="TSYSTEM_ACTIVITY")
public class SystemActivity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TSYSTEM_ACTIVITY_AUDITID_GENERATOR", sequenceName="SEQ_SYS_AUDIT_ID", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TSYSTEM_ACTIVITY_AUDITID_GENERATOR")
	@Column(name="AUDIT_ID")
	private long auditId;

	@Column(name="ACTION_DATE")
	private Timestamp actionDate;

	@Column(name="ACTION_DESC")
	private String actionDesc;
	
	@Column(name="DOC_PKG_ID")
	private Long docPackageId;

	//bi-directional many-to-one association to SystemAction
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ACTION_ID")
	private SystemAction systemAction;

    public SystemActivity() {
    }

	public long getAuditId() {
		return this.auditId;
	}

	public void setAuditId(long auditId) {
		this.auditId = auditId;
	}

	public Timestamp getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Timestamp actionDate) {
		this.actionDate = actionDate;
	}

	public String getActionDesc() {
		return this.actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public SystemAction getSystemAction() {
		return this.systemAction;
	}

	public void setSystemAction(SystemAction systemAction) {
		this.systemAction = systemAction;
	}

	public Long getDocPackageId() {
		return docPackageId;
	}

	public void setDocPackageId(Long docPackageId) {
		this.docPackageId = docPackageId;
	}
	
}