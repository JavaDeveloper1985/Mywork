package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TDOC_PACKAGE_TYPE database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_TYPE")
public class DocPackageType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_PKG_TYP_ID")
	private Integer id;

	@Column(name="DOC_PKG_TYP_CODE")
	private String code;

	@Column(name="DOC_PKG_TYP_DESC")
	private String description;

	@Column(name="EDMS_ACL_TYPE")
	private String edmsAclType;

	@Column(name="EDMS_BUS_FUN_CODE")
	private String edmsBusFunCode;

	@Column(name="EDMS_DOC_CATEGORY")
	private String edmsDocCategory;

	@Column(name="EDMS_DOC_TYPE")
	private String edmsDocType;

	@Column(name="EDMS_OBJECT_TYPE")
	private String edmsObjectType;

	//bi-directional many-to-one association to Authorization
	@OneToMany(mappedBy="docPackageType")
	private Set<Authorization> authorizations;	
	
	//bi-directional many-to-one association to DocSubpkgType
	@OneToMany(mappedBy="docPackageType")
	private Set<DocSubPackageType> docSubPackageType;

	//bi-directional many-to-one association to DocPackage
	@OneToMany(mappedBy="docPackageType")
	private Set<DocPackage> docPackages;

	//bi-directional many-to-one association to DocFormat
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DFLT_MERGED_DOC_FORMAT_ID")
	private DocFormat docFormat;

	//bi-directional many-to-one association to TransformationRule
	@OneToMany(mappedBy="docPackageType")
	private Set<TransformationRule> transformationRules;

	//bi-directional many-to-one association to ValidationControl
	@OneToMany(mappedBy="docPackageType")
	private Set<ValidationControl> validationControls;

    public DocPackageType() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEdmsAclType() {
		return this.edmsAclType;
	}

	public void setEdmsAclType(String edmsAclType) {
		this.edmsAclType = edmsAclType;
	}

	public String getEdmsBusFunCode() {
		return this.edmsBusFunCode;
	}

	public void setEdmsBusFunCode(String edmsBusFunCode) {
		this.edmsBusFunCode = edmsBusFunCode;
	}

	public String getEdmsDocCategory() {
		return this.edmsDocCategory;
	}

	public void setEdmsDocCategory(String edmsDocCategory) {
		this.edmsDocCategory = edmsDocCategory;
	}

	public String getEdmsDocType() {
		return this.edmsDocType;
	}

	public void setEdmsDocType(String edmsDocType) {
		this.edmsDocType = edmsDocType;
	}

	public String getEdmsObjectType() {
		return this.edmsObjectType;
	}

	public void setEdmsObjectType(String edmsObjectType) {
		this.edmsObjectType = edmsObjectType;
	}

	public Set<Authorization> getAuthorizations() {
		return this.authorizations;
	}

	public void setAuthorizations(Set<Authorization> authorizations) {
		this.authorizations = authorizations;
	}
	
	public Set<DocPackage> getDocPackages() {
		return this.docPackages;
	}

	public void setDocPackages(Set<DocPackage> docPackages) {
		this.docPackages = docPackages;
	}
	
	public DocFormat getDocFormat() {
		return this.docFormat;
	}

	public void setDocFormat(DocFormat docFormat) {
		this.docFormat = docFormat;
	}
	
	public Set<TransformationRule> getTransformationRules() {
		return this.transformationRules;
	}

	public void setTransformationRules(Set<TransformationRule> transformationRules) {
		this.transformationRules = transformationRules;
	}
	
	public Set<ValidationControl> getValidationControls() {
		return this.validationControls;
	}

	public void setValidationControls(Set<ValidationControl> validationControls) {
		this.validationControls = validationControls;
	}
	
	public Set<DocSubPackageType> getDocSubPackageType() {
		return this.docSubPackageType;
	}

	public void setDocSubPackageType(Set<DocSubPackageType> docSubPackageType) {
		this.docSubPackageType = docSubPackageType;
	}
		
}