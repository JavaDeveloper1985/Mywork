package com.swissre.dgf.data.model;

import org.apache.commons.lang3.StringUtils;

/**
 * Used to hold the results of a named query that retrieves the parameters
 * necessary to generate a new document.
 * 
 * See the {@code DocGenerationParameters.xml} file for the named query.
 */
public class DocGenerationParameters
{
	private String sourceSystem;
	private String templateName;
	private String docFormat;
	private String edmsRepository;
	private String edmsAclName;
	private String edmsBusinessFunctionCode;
	private String edmsDocType;
	private String edmsDocCategory;
	private String edmsObjectType;

	public DocGenerationParameters()
	{
	}

	public DocGenerationParameters(String sourceSystem, String edmsRepository,
			String edmsAclName, String businessFunctionCode, String edmsDocType, String edmsDocCategory, String edmsObjectType)
	{
		this(sourceSystem, edmsRepository, edmsAclName,
				businessFunctionCode, null, null, edmsDocType, edmsDocCategory, edmsObjectType);
	}

	public DocGenerationParameters(String sourceSystem, String edmsRepository,
			String edmsAclName, String businessFunctionCode,
			String templateName, String docFormat, String edmsDocType, String edmsDocCategory, String edmsObjectType)
	{
		setSourceSystem(sourceSystem);
		setTemplateName(templateName);
		setDocFormat(docFormat);
		setEdmsRepository(edmsRepository);
		setEdmsAclName(edmsAclName);
		setEdmsBusinessFunctionCode(businessFunctionCode);
		setEdmsDocType(edmsDocType);
		setEdmsDocCategory(edmsDocCategory);
		setEdmsObjectType(edmsObjectType);
	}

	/**
	 * Validates that all properties are not blank or {@code null}.
	 * 
	 * @return {@code true} if valid; {@code false} otherwise.
	 */
	public boolean isValid()
	{
		return StringUtils.isNotBlank(this.sourceSystem)
				&& StringUtils.isNotBlank(this.templateName)
				&& StringUtils.isNotBlank(this.edmsRepository)
				&& StringUtils.isNotBlank(this.edmsAclName)
				&& StringUtils.isNotBlank(this.edmsBusinessFunctionCode);
	}
	
	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public String getTemplateName()
	{
		return templateName;
	}

	public void setTemplateName(String templateName)
	{
		this.templateName = templateName;
	}

	public String getDocFormat()
	{
		return docFormat;
	}

	public void setDocFormat(String docFormat)
	{
		this.docFormat = docFormat;
	}

	public String getEdmsRepository()
	{
		return edmsRepository;
	}
	
	public void setEdmsRepository(String edmsRepository)
	{
		this.edmsRepository = edmsRepository;
	}

	public String getEdmsAclName()
	{
		return edmsAclName;
	}

	public void setEdmsAclName(String aclName)
	{
		this.edmsAclName = aclName;
	}

	public String getEdmsBusinessFunctionCode()
	{
		return edmsBusinessFunctionCode;
	}
	
	public void setEdmsBusinessFunctionCode(String fnCode)
	{
		this.edmsBusinessFunctionCode = fnCode;
	}

	
	public String getEdmsDocType() {
		return edmsDocType;
	}

	public void setEdmsDocType(String edmsDocType) {
		this.edmsDocType = edmsDocType;
	}

	public String getEdmsDocCategory() {
		return edmsDocCategory;
	}

	public void setEdmsDocCategory(String edmsDocCategory) {
		this.edmsDocCategory = edmsDocCategory;
	}

	public String getEdmsObjectType() {
		return edmsObjectType;
	}

	public void setEdmsObjectType(String edmsObjectType) {
		this.edmsObjectType = edmsObjectType;
	}

	@Override
	public String toString() {
		return "DocGenerationParameters [sourceSystem=" + sourceSystem
				+ ", templateName=" + templateName + ", docFormat=" + docFormat
				+ ", edmsRepository=" + edmsRepository + ", edmsFolderPath="
				+ ", edmsBusinessFunctionCode=" + edmsBusinessFunctionCode
				+ "]";
	}
}
