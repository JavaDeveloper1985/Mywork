package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TFORM_MAPPING database table.
 * 
 */
@Entity
@Table(name="TFORM_MAPPING")
public class FormMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FORM_MAPPING_ID")
	private long id;

	private String action;

	//uni-directional many-to-one association to FormDefinitionLang
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="OLD_FORM_DEF_LANG_ID")
	private FormDefinitionLang oldFormDefinitionLang;

	//uni-directional many-to-one association to FormDefinitionLang
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="NEW_FORM_DEF_LANG_ID")
	private FormDefinitionLang newFormDefinitionLang;

	//uni-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="OLD_PKG_TYP_ID")
	private DocPackageType oldDocPackageType;

	//uni-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="NEW_PKG_TYP_ID")
	private DocPackageType newDocPackageType;

    public FormMapping() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public FormDefinitionLang getOldFormDefinitionLang() {
		return this.oldFormDefinitionLang;
	}

	public void setOldFormDefinitionLang(FormDefinitionLang oldFormDefinitionLang) {
		this.oldFormDefinitionLang = oldFormDefinitionLang;
	}
	
	public FormDefinitionLang getNewFormDefinitionLang() {
		return this.newFormDefinitionLang;
	}

	public void setNewFormDefinitionLang(FormDefinitionLang newFormDefinitionLang) {
		this.newFormDefinitionLang = newFormDefinitionLang;
	}
	
	public DocPackageType getOldDocPackageType() {
		return this.oldDocPackageType;
	}

	public void setOldDocPackageType(DocPackageType oldDocPackageType) {
		this.oldDocPackageType = oldDocPackageType;
	}
	
	public DocPackageType getNewDocPackageType() {
		return this.newDocPackageType;
	}

	public void setNewDocPackageType(DocPackageType newDocPackageType) {
		this.newDocPackageType = newDocPackageType;
	}
	
}