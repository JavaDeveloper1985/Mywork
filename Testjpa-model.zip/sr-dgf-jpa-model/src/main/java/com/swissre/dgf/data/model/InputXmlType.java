package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TINPUT_XML_TYPE database table.
 * 
 */
@Entity
@Table(name="TINPUT_XML_TYPE")
public class InputXmlType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="INPUT_XML_TYPE_ID")
	private long id;

	@Column(name="INPUT_XML_TYPE_NAME")
	private String inputXmlTypeName;

	//bi-directional many-to-one association to TransformationRule
	@OneToMany(mappedBy="inputXmlType")
	private Set<TransformationRule> transformationRules;

    public InputXmlType() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getInputXmlTypeName() {
		return this.inputXmlTypeName;
	}

	public void setInputXmlTypeName(String inputXmlTypeName) {
		this.inputXmlTypeName = inputXmlTypeName;
	}

	public Set<TransformationRule> getTransformationRules() {
		return this.transformationRules;
	}

	public void setTransformationRules(Set<TransformationRule> transformationRules) {
		this.transformationRules = transformationRules;
	}
	
}