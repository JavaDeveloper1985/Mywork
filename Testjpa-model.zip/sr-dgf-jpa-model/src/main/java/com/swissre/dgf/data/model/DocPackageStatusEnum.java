package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocPackageStatus} by id.
 */
public enum DocPackageStatusEnum
{
	IN_PROGRESS(1),
	GENERATING(5),
	IN_PROGRESS_MERGED(2),
	FINALIZING(3),
	FINAL(4);
	
	private int id;
	
	private DocPackageStatusEnum(int id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code DocPackageStatus}
	 */
	public int getId()
	{
		return id;
	}
}
