package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TAPPLICATION_ROLE database table.
 * 
 */
@Entity
@Table(name="TAPPLICATION_ROLE")
public class ApplicationRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ROLE_ID")
	private Integer id;

	@Column(name="ROLE_DESC")
	private String description;

	@Column(name="ROLE_NAME")
	private String name;
	
	@Column(name="IS_IT_SUPPORT_ROLE")
	private boolean itSupportRole;

	//bi-directional many-to-one association to Authorization
	@OneToMany(mappedBy="applicationRole")
	private Set<Authorization> authorizations;

    public ApplicationRole() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Authorization> getAuthorizations() {
		return this.authorizations;
	}

	public void setAuthorizations(Set<Authorization> authorizations) {
		this.authorizations = authorizations;
	}

	public boolean isItSupportRole() {
		return itSupportRole;
	}

	public void setItSupportRole(boolean itSupportRole) {
		this.itSupportRole = itSupportRole;
	}

	@Override
	public String toString() {
		return "ApplicationRole [id=" + id + ", description=" + description
				+ ", name=" + name + ", itSupportRole=" + itSupportRole
				+ ", authorizations=" + authorizations + "]";
	}	
}