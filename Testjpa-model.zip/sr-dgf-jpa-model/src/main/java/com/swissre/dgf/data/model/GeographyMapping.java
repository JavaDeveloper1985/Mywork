package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TGEOGRAPHY_MAPPING database table.
 * 
 */
@Entity
@Table(name="TGEOGRAPHY_MAPPING")
public class GeographyMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	//bi-directional many-to-one association to Country
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="COUNTRY_ID")
	private Country country;

	//bi-directional many-to-one association to Geography
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GEOGRAPHY_ID")
	private Geography geography;

    public GeographyMapping() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}
	
	public Geography getGeography() {
		return this.geography;
	}

	public void setGeography(Geography geography) {
		this.geography = geography;
	}
	
}