package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the TFORM_SELECTION_CRITERIA database table.
 * 
 */
@Entity
@Table(name="TFORM_SELECTION_CRITERIA")
public class FormSelectionCriteria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="FORM_DEF_ID")
	private Long formDefId;

	@Column(name="FORM_ID")
	private String formId;

	@Column(name="FORM_SEQ")
	private Integer formSeq;

	@Id
	@Column(name="FS_RULE_ID")
	private Long fsRuleId;

	@Column(name="INCLUDE_BY_DEFAULT")
	private Boolean includeByDefault;

    @Temporal( TemporalType.DATE)
	@Column(name="INS_DATE")
	private Date insDate;

	@Column(name="INS_USER")
	private String insUser;

	@Column(name="MANDATORY")
	private Boolean mandatory;

	@Column(name="ROW_VERSION")
	private Long rowVersion;

	private String rule;

    @Temporal( TemporalType.DATE)
	@Column(name="UPD_DATE")
	private Date updDate;

	@Column(name="UPD_USER")
	private String updUser;
	

	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn(name="FORM_DEF_ID")
	private FormDefinition formDefinition;
	
	
	
	

    public FormDefinition getFormDefinition() {
		return formDefinition;
	}

	public void setFormDefinition(FormDefinition formDefinition) {
		this.formDefinition = formDefinition;
	}

	public FormSelectionCriteria() {
    }

	public Long getFormDefId() {
		return this.formDefId;
	}

	public void setFormDefId(Long formDefId) {
		this.formDefId = formDefId;
	}

	public String getFormId() {
		return this.formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Integer getFormSeq() {
		return this.formSeq;
	}

	public void setFormSeq(Integer formSeq) {
		this.formSeq = formSeq;
	}

	public Long getFsRuleId() {
		return this.fsRuleId;
	}

	public void setFsRuleId(Long fsRuleId) {
		this.fsRuleId = fsRuleId;
	}

	public Boolean getIncludeByDefault() {
		return this.includeByDefault;
	}

	public void setIncludeByDefault(Boolean includeByDefault) {
		this.includeByDefault = includeByDefault;
	}

	public Date getInsDate() {
		return this.insDate;
	}

	public void setInsDate(Date insDate) {
		this.insDate = insDate;
	}

	public String getInsUser() {
		return this.insUser;
	}

	public void setInsUser(String insUser) {
		this.insUser = insUser;
	}

	public Boolean getMandatory() {
		return this.mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public Long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(Long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public String getRule() {
		return this.rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public Date getUpdDate() {
		return this.updDate;
	}

	public void setUpdDate(Date updDate) {
		this.updDate = updDate;
	}

	public String getUpdUser() {
		return this.updUser;
	}

	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}

}