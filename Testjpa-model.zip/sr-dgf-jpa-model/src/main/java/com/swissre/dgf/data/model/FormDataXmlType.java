package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TFORM_DATA_XML_TYPE database table.
 * 
 */
@Entity
@Table(name="TFORM_DATA_XML_TYPE")
public class FormDataXmlType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="XML_TYPE_ID")
	private long id;

	@Column(name="QNAME")
	private String qName;

	//bi-directional many-to-one association to FormFormattingConfig
	@OneToMany(mappedBy="formDataXmlType")
	private Set<FormFormattingConfig> formFormattingConfigs;

    public FormDataXmlType() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getQName() {
		return this.qName;
	}

	public void setQName(String qName) {
		this.qName = qName;
	}

	public Set<FormFormattingConfig> getFormFormattingConfigs() {
		return this.formFormattingConfigs;
	}

	public void setFormFormattingConfigs(Set<FormFormattingConfig> formFormattingConfigs) {
		this.formFormattingConfigs = formFormattingConfigs;
	}
	
}