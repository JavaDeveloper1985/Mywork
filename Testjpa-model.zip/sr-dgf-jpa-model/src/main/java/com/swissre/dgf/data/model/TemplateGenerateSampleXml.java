package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TTEMPLATE_GENERATE_SAMPLE_XML database table.
 * 
 */
@Entity
@Table(name="TTEMPLATE_GENERATE_SAMPLE_XML")
public class TemplateGenerateSampleXml implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SAMPLE_XML_ID")
	private long sampleXmlId;

    @Lob()
	@Column(name="SAMPLE_XML")
	private String sampleXml;

	//bi-directional many-to-one association to FormDefinitionLang
	@OneToMany(mappedBy="templateGenerateSampleXml")
	private Set<FormDefinitionLang> formDefinitionLangs;
	
	//bi-directional many-to-one association to TemplateGenerateDynamicDataConfig
	@OneToMany(mappedBy="templateGenerateSampleXml")
	private Set<TemplateGenerateDynamicDataConfig> templateGenDynDataConfigs;

    public TemplateGenerateSampleXml() {
    }

	public long getSampleXmlId() {
		return this.sampleXmlId;
	}

	public void setSampleXmlId(long sampleXmlId) {
		this.sampleXmlId = sampleXmlId;
	}

	public String getSampleXml() {
		return this.sampleXml;
	}

	public void setSampleXml(String sampleXml) {
		this.sampleXml = sampleXml;
	}

	public Set<FormDefinitionLang> getFormDefinitionLangs() {
		return this.formDefinitionLangs;
	}

	public void setFormDefinitionLangs(Set<FormDefinitionLang> formDefinitionLangs) {
		this.formDefinitionLangs = formDefinitionLangs;
	}

	public Set<TemplateGenerateDynamicDataConfig> getTemplateGenDynDataConfigs() {
		return templateGenDynDataConfigs;
	}

	public void setTemplateGenDynDataConfigs(
			Set<TemplateGenerateDynamicDataConfig> templateGenDynDataConfigs) {
		this.templateGenDynDataConfigs = templateGenDynDataConfigs;
	}	
}