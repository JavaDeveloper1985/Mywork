package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TDOC_MERGED_VERSION database table.
 * 
 */
@Entity
@Table(name="TDOC_MERGED_VERSION")
public class DocMergedVersion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDOC_MERGED_VERSION_ID_GENERATOR", sequenceName="SEQ_DOC_MERGED_VERSION",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDOC_MERGED_VERSION_ID_GENERATOR")
	@Column(name="MERGED_VERSION_ID")
	private long mergedVersionId;

	@Column(name="MERGED_DOC_VERSION_NO")
	private String mergedDocVersionNo;

	@Column(name="PDF_VERSION_NO")
	private String pdfVersionNo;

	//bi-directional many-to-one association to DocPackageLang
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_LANG_ID")
	private DocPackageLang docPackageLang;

    public DocMergedVersion() {
    }

	public long getMergedVersionId() {
		return this.mergedVersionId;
	}

	public void setMergedVersionId(long mergedVersionId) {
		this.mergedVersionId = mergedVersionId;
	}

	public String getMergedDocVersionNo() {
		return this.mergedDocVersionNo;
	}

	public void setMergedDocVersionNo(String mergedDocVersionNo) {
		this.mergedDocVersionNo = mergedDocVersionNo;
	}

	public String getPdfVersionNo() {
		return this.pdfVersionNo;
	}

	public void setPdfVersionNo(String pdfVersionNo) {
		this.pdfVersionNo = pdfVersionNo;
	}

	public DocPackageLang getDocPackageLang() {
		return this.docPackageLang;
	}

	public void setDocPackageLang(DocPackageLang docPackageLang) {
		this.docPackageLang = docPackageLang;
	}
	
}