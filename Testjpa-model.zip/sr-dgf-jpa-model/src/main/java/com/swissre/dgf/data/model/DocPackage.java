package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;


/**
 * The persistent class for the TDOC_PACKAGE database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE")
public class DocPackage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDOC_PACKAGE_ID_GENERATOR", sequenceName="SEQ_PKGCOMP_NO", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDOC_PACKAGE_ID_GENERATOR")
	@Column(name="DOC_PKG_ID")
	private Long id;	

	@Column(name="ACTIVE_FLAG")
	private boolean activeFlag;

	@Column(name="FORMER_DOC_PKG_ID")
	private Long formerDocPkgId;

	@Column(name="INS_DATE")
	private Timestamp insertDate;

	@Column(name="INS_USER")
	private String insertUser;

	@Column(name="REVISION_HISTORY")
	private String revisionHistory;

	@Version
	@Column(name="ROW_VERSION")
	private Long rowVersion;

	@Column(name="UPD_DATE")
	private Timestamp updateDate;

	@Column(name="UPD_USER")
	private String updateUser;

	private Integer version;

	//uni-directional one-to-one association to DocPackageBusinessAttributes
	@PrimaryKeyJoinColumn
	@OneToOne(fetch=FetchType.LAZY)
	private DocPackageBusinessAttributes businessAttributes;

	//bi-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_TYP_ID")
	private DocPackageType docPackageType;
	
	//bi-directional many-to-one association to DocSubPackageType
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_SUB_PKG_TYP_ID")
	private DocSubPackageType docSubPackageType;

	//uni-directional many-to-one association to Message
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MSG_ID")
	private Message message;

	//bi-directional many-to-one association to SourceSystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_SYSTEM_ID")
	private SourceSystem sourceSystem;

	//bi-directional many-to-one association to DocPackageLang
	@OneToMany(mappedBy="docPackage")
	private Set<DocPackageLang> docPackageLangs;

	//bi-directional many-to-one association to UserActivity
	@OneToMany(mappedBy="docPackage")
	private Set<UserActivity> userActivities;

	//bi-directional one-to-one association to DocPackageDeactivateReason
	@OneToOne(mappedBy="docPackage", fetch=FetchType.LAZY)
	private DocPackageDeactivateReason docPackageDeactivateReason;

    public DocPackage() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean getActiveFlag() {
		return this.activeFlag;
	}

	public void setActiveFlag(boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public Long getFormerDocPkgId() {
		return this.formerDocPkgId;
	}

	public void setFormerDocPkgId(Long formerDocPkgId) {
		this.formerDocPkgId = formerDocPkgId;
	}

	public Timestamp getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Timestamp insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertUser() {
		return this.insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public String getRevisionHistory() {
		return this.revisionHistory;
	}

	public void setRevisionHistory(String revisionHistory) {
		this.revisionHistory = revisionHistory;
	}

	public Long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(Long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public Timestamp getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Integer getVersion() {
		return this.version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public DocPackageBusinessAttributes getBusinessAttributes() {
		return this.businessAttributes;
	}

	public void setBusinessAttributes(DocPackageBusinessAttributes businessAttributes) {
		this.businessAttributes = businessAttributes;
	}
	
	public DocPackageType getDocPackageType() {
		return this.docPackageType;
	}

	public void setDocPackageType(DocPackageType docPackageType) {
		this.docPackageType = docPackageType;
	}
	
	public Message getMessage() {
		return this.message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	public SourceSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	public Set<DocPackageLang> getDocPackageLangs() {
		return this.docPackageLangs;
	}

	public void setDocPackageLangs(Set<DocPackageLang> docPackageLangs) {
		this.docPackageLangs = docPackageLangs;
	}
	
	public Set<UserActivity> getUserActivities() {
		return this.userActivities;
	}

	public void setUserActivities(Set<UserActivity> userActivities) {
		this.userActivities = userActivities;
	}
	
	public DocPackageDeactivateReason getDocPackageDeactivateReason() {
		return this.docPackageDeactivateReason;
	}

	public void setDocPackageDeactivateReason(DocPackageDeactivateReason docPackageDeactivateReason) {
		this.docPackageDeactivateReason = docPackageDeactivateReason;
	}
	
	public DocSubPackageType getDocSubPackageType() {
		return this.docSubPackageType;
	}

	public void setDocSubPackageType(DocSubPackageType docSubPackageType) {
		this.docSubPackageType = docSubPackageType;
	}	
	
}