package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TDOC_PACKAGE_BUS_ATTS database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_BUS_ATTS")
public class DocPackageBusinessAttributes implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BUS_ATTS_ID")
	private Long id;

	@Column(name="CARRIER_COUNTRY_CODE")
	private String carrierCountryCode;

	@Column(name="CARRIER_ID")
	private Integer carrierId;

	@Column(name="CARRIER_NAME")
	private String carrierName;

	@Column(name="DOC_PKG_ID")
	private Long docPkgId;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRATION_DATE")
	private Date expirationDate;

    @Temporal( TemporalType.DATE)
	@Column(name="INCEPTION_DATE")
	private Date inceptionDate;

	@Column(name="INDUSTRY_SEGMENT")
	private String industrySegment;

	@Column(name="INSURED_ID")
	private Integer insuredId;

	@Column(name="INSURED_NAME")
	private String insuredName;

	private String jurisdiction;

	@Column(name="LEGAL_UW_NAME")
	private String legalUwName;

	@Column(name="LEGAL_UW_USER_ID")
	private String legalUwUserId;

	@Column(name="LINE_NUMBER")
	private String lineNumber;

	@Column(name="LINE_STATUS")
	private String lineStatus;

	@Column(name="POLICY_NUMBER")
	private String policyNumber;

	@Column(name="PRIMARY_LOB_CODE")
	private Integer primaryLobCode;

	@Column(name="PRIMARY_LOB_NAME")
	private String primaryLobName;

	@Column(name="RETAIL_BROKER_ID")
	private Integer retailBrokerId;

	@Column(name="RETAIL_BROKER_NAME")
	private String retailBrokerName;

	@Column(name="SUB_LOB_CODE")
	private Integer subLobCode;

	@Column(name="SUB_LOB_NAME")
	private String subLobName;

	@Column(name="SUB_LOB_SDL_CODE")
	private Integer subLobSdlCode;

	@Column(name="USR_NAME")
	private String underwritingSupportRepName;

	@Column(name="USR_USER_ID")
	private String underwritingSupportRepUserId;

	@Column(name="UW_NAME")
	private String underwriterName;

	@Column(name="UW_USER_ID")
	private String underwriterUserId;

	@Column(name="WHOLESALE_BROKER_ID")
	private Integer wholesaleBrokerId;

	@Column(name="WHOLESALE_BROKER_NAME")
	private String wholesaleBrokerName;
	
	@Column(name="UW_TEAM")
	private String uwTeam;

	//uni-directional one-to-one association to DocPackage
	@OneToOne(fetch=FetchType.LAZY)
	@PrimaryKeyJoinColumn(name="BUS_ATTS_ID", referencedColumnName="DOC_PKG_ID")
	private DocPackage docPackage;

	//uni-directional many-to-one association to Geography
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GEOGRAPHY_ID")
	private Geography geography;

	//bi-directional many-to-one association to DocPackagePartnerAttr
	@OneToMany(mappedBy="docPackageBusAttr" , cascade= CascadeType.PERSIST) 
	private Set<DocPackagePartnerAttr> docPackagePartnerAtts;

    public DocPackageBusinessAttributes() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCarrierCountryCode() {
		return this.carrierCountryCode;
	}

	public void setCarrierCountryCode(String carrierCountryCode) {
		this.carrierCountryCode = carrierCountryCode;
	}

	public Integer getCarrierId() {
		return this.carrierId;
	}

	public void setCarrierId(Integer carrierId) {
		this.carrierId = carrierId;
	}

	public String getCarrierName() {
		return this.carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public Long getDocPkgId() {
		return this.docPkgId;
	}

	public void setDocPkgId(Long docPkgId) {
		this.docPkgId = docPkgId;
	}

	public Date getExpirationDate() {
		return this.expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getInceptionDate() {
		return this.inceptionDate;
	}

	public void setInceptionDate(Date inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public String getIndustrySegment() {
		return this.industrySegment;
	}

	public void setIndustrySegment(String industrySegment) {
		this.industrySegment = industrySegment;
	}

	public Integer getInsuredId() {
		return this.insuredId;
	}

	public void setInsuredId(Integer insuredId) {
		this.insuredId = insuredId;
	}

	public String getInsuredName() {
		return this.insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getJurisdiction() {
		return this.jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getLegalUwName() {
		return this.legalUwName;
	}

	public void setLegalUwName(String legalUwName) {
		this.legalUwName = legalUwName;
	}

	public String getLegalUwUserId() {
		return this.legalUwUserId;
	}

	public void setLegalUwUserId(String legalUwUserId) {
		this.legalUwUserId = legalUwUserId;
	}

	public String getLineNumber() {
		return this.lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getLineStatus() {
		return this.lineStatus;
	}

	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}

	public String getPolicyNumber() {
		return this.policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Integer getPrimaryLobCode() {
		return this.primaryLobCode;
	}

	public void setPrimaryLobCode(Integer primaryLobCode) {
		this.primaryLobCode = primaryLobCode;
	}

	public String getPrimaryLobName() {
		return this.primaryLobName;
	}

	public void setPrimaryLobName(String primaryLobName) {
		this.primaryLobName = primaryLobName;
	}

	public Integer getRetailBrokerId() {
		return this.retailBrokerId;
	}

	public void setRetailBrokerId(Integer retailBrokerId) {
		this.retailBrokerId = retailBrokerId;
	}

	public String getRetailBrokerName() {
		return this.retailBrokerName;
	}

	public void setRetailBrokerName(String retailBrokerName) {
		this.retailBrokerName = retailBrokerName;
	}

	public Integer getSubLobCode() {
		return this.subLobCode;
	}

	public void setSubLobCode(Integer subLobCode) {
		this.subLobCode = subLobCode;
	}

	public String getSubLobName() {
		return this.subLobName;
	}

	public void setSubLobName(String subLobName) {
		this.subLobName = subLobName;
	}

	public Integer getSubLobSdlCode() {
		return this.subLobSdlCode;
	}

	public void setSubLobSdlCode(Integer subLobSdlCode) {
		this.subLobSdlCode = subLobSdlCode;
	}

	public String getUnderwritingSupportRepName() {
		return this.underwritingSupportRepName;
	}

	public void setUnderwritingSupportRepName(String underwritingSupportRepName) {
		this.underwritingSupportRepName = underwritingSupportRepName;
	}

	public String getUnderwritingSupportRepUserId() {
		return this.underwritingSupportRepUserId;
	}

	public void setUnderwritingSupportRepUserId(String underwritingSupportRepUserId) {
		this.underwritingSupportRepUserId = underwritingSupportRepUserId;
	}

	public String getUnderwriterName() {
		return this.underwriterName;
	}

	public void setUnderwriterName(String underwriterName) {
		this.underwriterName = underwriterName;
	}

	public String getUnderwriterUserId() {
		return this.underwriterUserId;
	}

	public void setUnderwriterUserId(String underwriterUserId) {
		this.underwriterUserId = underwriterUserId;
	}

	public Integer getWholesaleBrokerId() {
		return this.wholesaleBrokerId;
	}

	public void setWholesaleBrokerId(Integer wholesaleBrokerId) {
		this.wholesaleBrokerId = wholesaleBrokerId;
	}

	public String getWholesaleBrokerName() {
		return this.wholesaleBrokerName;
	}

	public void setWholesaleBrokerName(String wholesaleBrokerName) {
		this.wholesaleBrokerName = wholesaleBrokerName;
	}

	public DocPackage getDocPackage() {
		return this.docPackage;
	}

	public void setDocPackage(DocPackage docPackage) {
		this.docPackage = docPackage;
	}
	
	public Geography getGeography() {
		return this.geography;
	}

	public void setGeography(Geography geography) {
		this.geography = geography;
	}
	
	public Set<DocPackagePartnerAttr> getDocPackagePartnerAtts() {
		return this.docPackagePartnerAtts;
	}

	public void setDocPackagePartnerAtts(Set<DocPackagePartnerAttr> docPackagePartnerAtts) {
		this.docPackagePartnerAtts = docPackagePartnerAtts;
	}

	public String getUwTeam() {
		return uwTeam;
	}

	public void setUwTeam(String uwTeam) {
		this.uwTeam = uwTeam;
	}
	
	
	
}