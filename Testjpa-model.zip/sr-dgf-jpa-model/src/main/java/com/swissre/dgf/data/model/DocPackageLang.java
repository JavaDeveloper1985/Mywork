package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TDOC_PACKAGE_LANG database table.
 * 
 */
@Entity
@Table(name="TDOC_PACKAGE_LANG")
public class DocPackageLang implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TDOC_PACKAGE_LANG_ID_GENERATOR", sequenceName="SEQ_PKGLANG_NO", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TDOC_PACKAGE_LANG_ID_GENERATOR")
	@Column(name="DOC_PKG_LANG_ID")
	private Long id;

	@Column(name="DOC_PKG_NAME")
	private String packageName;

	@Column(name="EDMS_DOC_ID_PDF")
	private String edmsDocIdPdf;

	@Column(name="EDMS_DOC_ID_WORD")
	private String edmsDocIdWord;

	@Column(name="SEQ_NO")
	private int seqNo;

	//bi-directional many-to-one association to DocComponent
	@OneToMany(mappedBy="docPackageLang", cascade={CascadeType.REMOVE})
	private Set<DocComponent> docComponents;

	//uni-directional many-to-one association to DocFormat
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MERGED_DOC_FORMAT_ID")
	private DocFormat docFormat;

	//bi-directional many-to-one association to DocPackage
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_ID")
	private DocPackage docPackage;

	//uni-directional many-to-one association to DocPackageStatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_STATUS_ID")
	private DocPackageStatus docPackageStatus;

	//uni-directional many-to-one association to Language
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LANGUAGE_ID")
	private Language language;

	//bi-directional many-to-one association to DocMergedVersion
	@OneToMany(mappedBy="docPackageLang", cascade={CascadeType.REMOVE})
	private Set<DocMergedVersion> docMergedVersions;

	//bi-directional many-to-one association to DocGenLocale
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FORMAT_LOCALE_ID")
	private DocGenLocale formatLocale;
	
	@Column(name="FORMATTING_REQUIRED")
	private boolean formattingRequired;
	
    public DocPackageLang() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPackageName() {
		return this.packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getEdmsDocIdPdf() {
		return this.edmsDocIdPdf;
	}

	public void setEdmsDocIdPdf(String edmsDocIdPdf) {
		this.edmsDocIdPdf = edmsDocIdPdf;
	}

	public String getEdmsDocIdWord() {
		return this.edmsDocIdWord;
	}

	public void setEdmsDocIdWord(String edmsDocIdWord) {
		this.edmsDocIdWord = edmsDocIdWord;
	}

	public int getSeqNo() {
		return this.seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public Set<DocComponent> getDocComponents() {
		return this.docComponents;
	}

	public void setDocComponents(Set<DocComponent> docComponents) {
		this.docComponents = docComponents;
	}
	
	public DocFormat getDocFormat() {
		return this.docFormat;
	}

	public void setDocFormat(DocFormat docFormat) {
		this.docFormat = docFormat;
	}
	
	public DocPackage getDocPackage() {
		return this.docPackage;
	}

	public void setDocPackage(DocPackage docPackage) {
		this.docPackage = docPackage;
	}
	
	public DocPackageStatus getDocPackageStatus() {
		return this.docPackageStatus;
	}

	public void setDocPackageStatus(DocPackageStatus docPackageStatus) {
		this.docPackageStatus = docPackageStatus;
	}
	
	public Language getLanguage() {
		return this.language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
	public Set<DocMergedVersion> getDocMergedVersions() {
		return this.docMergedVersions;
	}

	public void setDocMergedVersions(Set<DocMergedVersion> docMergedVersions) {
		this.docMergedVersions = docMergedVersions;
	}

	public DocGenLocale getFormatLocale() {
		return formatLocale;
	}

	public void setFormatLocale(DocGenLocale formatLocale) {
		this.formatLocale = formatLocale;
	}

	public boolean isFormattingRequired() {
		return formattingRequired;
	}

	public void setFormattingRequired(boolean formattingRequired) {
		this.formattingRequired = formattingRequired;
	}
	
}