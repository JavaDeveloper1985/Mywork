package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * The persistent class for the TFORM_DEFINITION database table.
 * 
 */
@Entity
@Table(name="TFORM_DEFINITION")
public class FormDefinition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FORM_DEF_ID")
	private Long id;

	@Column(name="DOC_EDITABLE")
	private boolean docEditable;

    @Lob()
	@Column(name="FORM_DEF_XML")
	private String formDefXml;

	@Column(name="FORM_ID")
	private String formId;

	@Lob()
	@Column(name="FORM_INSTRUCTIONS")
	private String formInstructions;

	@Column(name="FORM_TITLE")
	private String formTitle;

    @Temporal( TemporalType.DATE)
	@Column(name="INS_DATE")
	private Date insertDate;

	@Column(name="INS_USER")
	private String insertUser;

	@Version
	@Column(name="ROW_VERSION")
	private Long rowVersion;

	@Column(name="STAND_ALONE_FORM")
	private Boolean standAloneForm;

    @Temporal( TemporalType.DATE)
	@Column(name="UPD_DATE")
	private Date updateDate;

	@Column(name="UPD_USER")
	private String updateUser;

	//bi-directional many-to-one association to FormDefinitionLang
	@OneToMany(mappedBy="formDefinition")
	private Set<FormDefinitionLang> formDefinitionLangs;
	
	
	@OneToOne(mappedBy = "formDefinition" ,fetch=FetchType.LAZY)
	private FormSelectionCriteria formSelectionCriteria;
	
	

	@Column(name="LOCALE_FORMATTING_ALLOWED")
	private boolean localeFormattingAllowed;
	
    public FormDefinition() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	

	public FormSelectionCriteria getFormSelectionCriteria() {
		return formSelectionCriteria;
	}

	public void setFormSelectionCriteria(FormSelectionCriteria formSelectionCriteria) {
		this.formSelectionCriteria = formSelectionCriteria;
	}

	public boolean getDocEditable() {
		return this.docEditable;
	}

	public void setDocEditable(boolean docEditable) {
		this.docEditable = docEditable;
	}

	public String getFormDefXml() {
		return this.formDefXml;
	}

	public void setFormDefXml(String formDefXml) {
		this.formDefXml = formDefXml;
	}

	public String getFormId() {
		return this.formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormInstructions() {
		return this.formInstructions;
	}

	public void setFormInstructions(String formInstructions) {
		this.formInstructions = formInstructions;
	}

	public String getFormTitle() {
		return this.formTitle;
	}

	public void setFormTitle(String formTitle) {
		this.formTitle = formTitle;
	}

	public Date getInsertDate() {
		return this.insertDate;
	}

	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}

	public String getInsertUser() {
		return this.insertUser;
	}

	public void setInsertUser(String insertUser) {
		this.insertUser = insertUser;
	}

	public Long getRowVersion() {
		return this.rowVersion;
	}

	public void setRowVersion(Long rowVersion) {
		this.rowVersion = rowVersion;
	}

	public Boolean getStandAloneForm() {
		return this.standAloneForm;
	}

	public void setStandAloneForm(Boolean standAloneForm) {
		this.standAloneForm = standAloneForm;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Set<FormDefinitionLang> getFormDefinitionLangs() {
		return this.formDefinitionLangs;
	}

	public void setFormDefinitionLangs(Set<FormDefinitionLang> formDefinitionLangs) {
		this.formDefinitionLangs = formDefinitionLangs;
	}

	public boolean isLocaleFormattingAllowed() {
		return localeFormattingAllowed;
	}

	public void setLocaleFormattingAllowed(boolean localeFormattingAllowed) {
		this.localeFormattingAllowed = localeFormattingAllowed;
	}
}