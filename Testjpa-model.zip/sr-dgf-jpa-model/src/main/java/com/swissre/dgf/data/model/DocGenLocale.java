package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TLOCALE database table.
 * 
 */
@Entity
@Table(name="TLOCALE")
public class DocGenLocale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LOCALE_ID")
	private String id;

	@Column(name="LOCALE_COUNTRY_NAME")
	private String countryName;

	@Column(name="LOCALE_LANG_DESC")
	private String languageDesc;

	//bi-directional many-to-one association to DocPackageLang
	@OneToMany(mappedBy="formatLocale")
	private Set<DocPackageLang> docPackageLangs;

	//bi-directional many-to-one association to FormFormattingConfig
	@OneToMany(mappedBy="defaultLocale")
	private Set<FormFormattingConfig> formFormattingConfigs;

    public DocGenLocale() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCountryName() {
		return this.countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getLanguageDesc() {
		return this.languageDesc;
	}

	public void setLanguageDesc(String languageDesc) {
		this.languageDesc = languageDesc;
	}

	public Set<DocPackageLang> getDocPackageLangs() {
		return this.docPackageLangs;
	}

	public void setDocPackageLangs(Set<DocPackageLang> docPackageLangs) {
		this.docPackageLangs = docPackageLangs;
	}
	
	public Set<FormFormattingConfig> getFormFormattingConfigs() {
		return this.formFormattingConfigs;
	}

	public void setFormFormattingConfigs(Set<FormFormattingConfig> formFormattingConfigs) {
		this.formFormattingConfigs = formFormattingConfigs;
	}
	
}