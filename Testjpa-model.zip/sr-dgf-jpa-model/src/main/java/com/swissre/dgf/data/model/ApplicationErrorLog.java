package com.swissre.dgf.data.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAPPLICATION_ERROR_LOG database table.
 * 
 */
@Entity
@Table(name="TAPPLICATION_ERROR_LOG")
public class ApplicationErrorLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TERROR_ID_GENERATOR", sequenceName="ERROR_SEQ_ID", allocationSize=1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="TERROR_ID_GENERATOR")
	@Column(name="ERROR_CASE_ID")
	private Long id;

	@Column(name="CHANNEL")
	private String channel;

	@Column(name="CONTEXT")
	private String context;

	@Column(name="ERROR_DATE")
	private Timestamp errorDate;

	@Column(name="ERROR_MSG")
	private String errorMsg;

	@Column(name="SERVER_ENV")
	private String serverEnv;

    @Lob()
    @Column(name="STACKTRACE")
	private String stacktrace;

	@Column(name="USER_ID")
	private String userId;
	
	@Column(name="ITSM_RESPONSE")
	private String itsmResponse;

	//bi-directional many-to-one association to Message
	@OneToMany(mappedBy="applicationErrorLog")
	private Set<Message> messages;

    public ApplicationErrorLog() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getContext() {
		return this.context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public Timestamp getErrorDate() {
		return this.errorDate;
	}

	public void setErrorDate(Timestamp errorDate) {
		this.errorDate = errorDate;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getServerEnv() {
		return this.serverEnv;
	}

	public void setServerEnv(String serverEnv) {
		this.serverEnv = serverEnv;
	}

	public String getStacktrace() {
		return this.stacktrace;
	}

	public void setStacktrace(String stacktrace) {
		this.stacktrace = stacktrace;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Set<Message> getMessages() {
		return this.messages;
	}

	public void setMessages(Set<Message> messages) {
		this.messages = messages;
	}

	public String getItsmResponse() {
		return itsmResponse;
	}

	public void setItsmResponse(String itsmResponse) {
		this.itsmResponse = itsmResponse;
	}	
}