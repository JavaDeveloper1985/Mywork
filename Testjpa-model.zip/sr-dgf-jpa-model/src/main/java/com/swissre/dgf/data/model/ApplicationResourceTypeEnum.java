package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code ApplicationResourceType} by id.
 */
public enum ApplicationResourceTypeEnum
{
	XSD(1),
	XSL(2);
	
	private long id;
	
	private ApplicationResourceTypeEnum(long id)
	{
		this.id = id;
	}

	/**
	 * @return The primary key of the referenced {@code ApplicationResourceType}
	 */
	public long getId()
	{
		return id;
	}
}
