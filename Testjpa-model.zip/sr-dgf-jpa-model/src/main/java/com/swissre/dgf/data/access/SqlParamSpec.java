package com.swissre.dgf.data.access;


/**
 * Contains meta-data about a parameter to a stored procedure, including the parameter's
 * name, type, and whether it is an OUT parameter.
 */
public class SqlParamSpec
{
    private final String name;
    private final int type;
    private final boolean out;

    /**
     * Creates a {@code SqlParamSpec} for an IN parameter using the given
     * arguments. Defaults the {@code boolean out} property to {@code false}.
     * 
     * @param name
     *            Name of the parameter as defined by the stored procedure.
     * @param type
     *            The SQL type of the parameter. This should be set to one of
     *            the constants in java.sql.Types.
     */
    public SqlParamSpec(String name, int type)
    {
        this(name, type, false);
    }
    
    /**
     * Creates a {@code SqlParamSpec} with the given arguments.
     * 
     * @param name
     *            Name of the parameter as defined by the stored procedure.
     * @param type
     *            The SQL type of the parameter. This should be set to one of
     *            the constants in java.sql.Types.
     * @param out
     *            If true, the parameter is treated as an OUT parameter.
     */
    public SqlParamSpec(String name, int type, boolean out)
    {
        super();
        this.name = name;
        this.type = type;
        this.out = out;
    }

    public String getName()
    {
        return name;
    }

    public int getType()
    {
        return type;
    }

    public boolean isOut()
    {
        return out;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + (out ? 1231 : 1237);
        result = prime * result + type;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SqlParamSpec other = (SqlParamSpec) obj;
        if (name == null)
        {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (out != other.out)
            return false;
        if (type != other.type)
            return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "SqlParamSpec [name=" + name + ", type=" + type + ", out=" + out + "]";
    }
    
}
