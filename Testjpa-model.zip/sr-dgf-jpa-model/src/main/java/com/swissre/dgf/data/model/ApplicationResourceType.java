package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TAPPLICATION_RESOURCE_TYPE database table.
 * 
 */
@Entity
@Table(name="TAPPLICATION_RESOURCE_TYPE")
public class ApplicationResourceType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RESOURCE_TYPE_ID")
	private long resourceTypeId;

	@Column(name="RESOURCE_TYPE_NAME")
	private String resourceTypeName;

	//bi-directional many-to-one association to ApplicationResource
	@OneToMany(mappedBy="applicationResourceType")
	private Set<ApplicationResource> applicationResources;

    public ApplicationResourceType() {
    }

	public long getResourceTypeId() {
		return this.resourceTypeId;
	}

	public void setResourceTypeId(long resourceTypeId) {
		this.resourceTypeId = resourceTypeId;
	}

	public String getResourceTypeName() {
		return this.resourceTypeName;
	}

	public void setResourceTypeName(String resourceTypeName) {
		this.resourceTypeName = resourceTypeName;
	}

	public Set<ApplicationResource> getApplicationResources() {
		return this.applicationResources;
	}

	public void setApplicationResources(Set<ApplicationResource> applicationResources) {
		this.applicationResources = applicationResources;
	}
	
}