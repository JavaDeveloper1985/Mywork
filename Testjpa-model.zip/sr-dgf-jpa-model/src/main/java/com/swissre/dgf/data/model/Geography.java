package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TGEOGRAPHY database table.
 * 
 */
@Entity
@Table(name="TGEOGRAPHY")
public class Geography implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GEOGRAPHY_ID")
	private String geographyId;

	@Column(name="GEOGRAPHY_DESC")
	private String geographyDesc;

    public Geography() {
    }

	public String getGeographyId() {
		return this.geographyId;
	}

	public void setGeographyId(String geographyId) {
		this.geographyId = geographyId;
	}

	public String getGeographyDesc() {
		return this.geographyDesc;
	}

	public void setGeographyDesc(String geographyDesc) {
		this.geographyDesc = geographyDesc;
	}

}