package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TVALIDATION_CONTROL database table.
 * 
 */
@Entity
@Table(name="TVALIDATION_CONTROL")
public class ValidationControl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="VAL_CTRL_ID")
	private long valCtrlId;

	@Column(name="REJECTION_LEVEL")
	private String rejectionLevel;

	@Column(name="VALIDATION_ENABLED")
	private String validationEnabled;

	//bi-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_TYP_ID")
	private DocPackageType docPackageType;

	//bi-directional many-to-one association to SourceSystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_SYSTEM_ID")
	private SourceSystem sourceSystem;

    public ValidationControl() {
    }

	public long getValCtrlId() {
		return this.valCtrlId;
	}

	public void setValCtrlId(long valCtrlId) {
		this.valCtrlId = valCtrlId;
	}

	public String getRejectionLevel() {
		return this.rejectionLevel;
	}

	public void setRejectionLevel(String rejectionLevel) {
		this.rejectionLevel = rejectionLevel;
	}

	public String getValidationEnabled() {
		return this.validationEnabled;
	}

	public void setValidationEnabled(String validationEnabled) {
		this.validationEnabled = validationEnabled;
	}

	public DocPackageType getDocPackageType() {
		return this.docPackageType;
	}

	public void setDocPackageType(DocPackageType docPackageType) {
		this.docPackageType = docPackageType;
	}
	
	public SourceSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
}