package com.swissre.dgf.data.model;

/**
 * An enumeration that can be used to refer to a particular
 * {@code DocPackageStatus} by id.
 */
public enum InputXmlTypeEnum
{
	FORM_XML(new Long(1)),
	EDITED_FORM_XML(new Long(2)),
	FINAL_FORM_XML(new Long(3));
	
	private Long inputXmlTypeId;
	
	private InputXmlTypeEnum(Long inputXmlTypeId)
	{
		this.inputXmlTypeId = inputXmlTypeId;
	}

	/**
	 * @return The primary key of the referenced {@code DocPackageStatus}
	 */
	public Long getInputXmlTypeId()
	{
		return inputXmlTypeId;
	}
}
