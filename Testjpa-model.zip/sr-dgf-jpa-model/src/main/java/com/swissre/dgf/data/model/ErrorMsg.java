package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TERRORMSG database table.
 * 
 */
@Entity
@Table(name="TERRORMSG")
public class ErrorMsg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String errorMsgCode;

	private String errorMsgText;

	private String language;

    public ErrorMsg() {
    }

	public String getErrorMsgCode() {
		return this.errorMsgCode;
	}

	public void setErrorMsgCode(String errorMsgCode) {
		this.errorMsgCode = errorMsgCode;
	}

	public String getErrorMsgText() {
		return this.errorMsgText;
	}

	public void setErrorMsgText(String errorMsgText) {
		this.errorMsgText = errorMsgText;
	}

	public String getLanguage() {
		return this.language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

}