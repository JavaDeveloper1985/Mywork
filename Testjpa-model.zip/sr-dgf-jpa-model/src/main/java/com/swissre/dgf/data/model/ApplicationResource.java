package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TAPPLICATION_RESOURCES database table.
 * 
 */
@Entity
@Table(name="TAPPLICATION_RESOURCES")
public class ApplicationResource implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RESOURCE_ID")
	private Long id;

	@Column(name="RESOURCE_DESC")
	private String description;

    @Lob()
	@Column(name="RESOURCE_FILE")
	private String file;

	@Column(name="RESOURCE_NAME")
	private String name;

	//bi-directional many-to-one association to ApplicationResourceType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RESOURCE_TYPE_ID")
	private ApplicationResourceType applicationResourceType;

	//bi-directional many-to-one association to TransformationRule
	@OneToMany(mappedBy="applicationResource")
	private Set<TransformationRule> transformationRules;

	//bi-directional many-to-one association to ValidationRule
	@OneToMany(mappedBy="applicationResource")
	private Set<ValidationRule> validationRules;

    public ApplicationResource() {
    }

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFile() {
		return this.file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ApplicationResourceType getApplicationResourceType() {
		return this.applicationResourceType;
	}

	public void setApplicationResourceType(ApplicationResourceType applicationResourceType) {
		this.applicationResourceType = applicationResourceType;
	}
	
	public Set<TransformationRule> getTransformationRules() {
		return this.transformationRules;
	}

	public void setTransformationRules(Set<TransformationRule> transformationRules) {
		this.transformationRules = transformationRules;
	}
	
	public Set<ValidationRule> getValidationRules() {
		return this.validationRules;
	}

	public void setValidationRules(Set<ValidationRule> validationRules) {
		this.validationRules = validationRules;
	}
	
}