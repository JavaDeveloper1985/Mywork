package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TDOC_COMPONENT_TYPE database table.
 * 
 */
@Entity
@Table(name="TDOC_COMPONENT_TYPE")
public class DocComponentType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_COMP_TYP_ID")
	private Integer id;

	@Column(name="DOC_COMP_TYP_DESC")
	private String description;

	//bi-directional many-to-one association to DocComponent
	@OneToMany(mappedBy="docComponentType")
	private Set<DocComponent> docComponents;

    public DocComponentType() {
    }

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<DocComponent> getDocComponents() {
		return this.docComponents;
	}

	public void setDocComponents(Set<DocComponent> docComponents) {
		this.docComponents = docComponents;
	}
	
}