package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TTRANSFORMATION_RULES database table.
 * 
 */
@Entity
@Table(name="TTRANSFORMATION_RULES")
public class TransformationRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSFORM_RULE_ID")
	private long id;

	//bi-directional many-to-one association to ApplicationResource
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="XML_STYLESHEET_ID")
	private ApplicationResource applicationResource;

	//bi-directional many-to-one association to DocPackageType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DOC_PKG_TYP_ID")
	private DocPackageType docPackageType;

	//bi-directional many-to-one association to InputXmlType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="INPUT_XML_TYPE_ID")
	private InputXmlType inputXmlType;

	//bi-directional many-to-one association to SourceSystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_SYSTEM_ID")
	private SourceSystem sourceSystem;

    public TransformationRule() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public ApplicationResource getApplicationResource() {
		return this.applicationResource;
	}

	public void setApplicationResource(ApplicationResource applicationResource) {
		this.applicationResource = applicationResource;
	}
	
	public DocPackageType getDocPackageType() {
		return this.docPackageType;
	}

	public void setDocPackageType(DocPackageType docPackageType) {
		this.docPackageType = docPackageType;
	}
	
	public InputXmlType getInputXmlType() {
		return this.inputXmlType;
	}

	public void setInputXmlType(InputXmlType inputXmlType) {
		this.inputXmlType = inputXmlType;
	}
	
	public SourceSystem getSourceSystem() {
		return this.sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
}