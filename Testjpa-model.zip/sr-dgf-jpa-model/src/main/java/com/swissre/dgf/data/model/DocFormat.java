package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the TDOC_FORMAT database table.
 * 
 */
@Entity
@Table(name="TDOC_FORMAT")
public class DocFormat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DOC_FORMAT_ID")
	private String id;

	@Column(name="DOC_FORMAT_DESC")
	private String description;

	//bi-directional many-to-one association to DocPackageType
	@OneToMany(mappedBy="docFormat")
	private Set<DocPackageType> docPackageTypes;

    public DocFormat() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<DocPackageType> getDocPackageTypes() {
		return this.docPackageTypes;
	}

	public void setDocPackageTypes(Set<DocPackageType> docPackageTypes) {
		this.docPackageTypes = docPackageTypes;
	}
	
}