package com.swissre.dgf.data.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TTEMPLATE_GEN_DYN_DATA_CONFIG database table.
 * 
 */
@Entity
@Table(name="TTEMPLATE_GEN_DYN_DATA_CONFIG")
public class TemplateGenerateDynamicDataConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CONFIG_ID")
	private long configId;

	@Column(name="DYN_DATA_TYPE")
	private String dynamicDataType;

	@Column(name="XPATH")
	private String xpath;

	//bi-directional many-to-one association to TemplateGenerateSampleXml
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SAMPLE_XML_ID")
	private TemplateGenerateSampleXml templateGenerateSampleXml;

    public TemplateGenerateDynamicDataConfig() {
    }

	public long getConfigId() {
		return configId;
	}

	public void setConfigId(long configId) {
		this.configId = configId;
	}

	public String getDynamicDataType() {
		return dynamicDataType;
	}

	public void setDynamicDataType(String dynamicDataType) {
		this.dynamicDataType = dynamicDataType;
	}

	public String getXpath() {
		return xpath;
	}

	public void setXpath(String xpath) {
		this.xpath = xpath;
	}

	public TemplateGenerateSampleXml getTemplateGenerateSampleXml() {
		return templateGenerateSampleXml;
	}

	public void setTemplateGenerateSampleXml(
			TemplateGenerateSampleXml templateGenerateSampleXml) {
		this.templateGenerateSampleXml = templateGenerateSampleXml;
	}    
}