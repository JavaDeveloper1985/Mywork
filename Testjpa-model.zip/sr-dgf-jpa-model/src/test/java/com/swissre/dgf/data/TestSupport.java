package com.swissre.dgf.data;

import static com.swissre.dgf.data.access.QueryParameter.with;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import com.swissre.dgf.data.access.DataAccessService;
import com.swissre.dgf.data.model.DocComponent;
import com.swissre.dgf.data.model.DocComponentStatus;
import com.swissre.dgf.data.model.DocComponentStatusEnum;
import com.swissre.dgf.data.model.DocFormat;
import com.swissre.dgf.data.model.DocPackage;
import com.swissre.dgf.data.model.DocPackageBusinessAttributes;
import com.swissre.dgf.data.model.DocPackageLang;
import com.swissre.dgf.data.model.DocPackageStatus;
import com.swissre.dgf.data.model.DocPackageStatusEnum;
import com.swissre.dgf.data.model.DocPackageType;
import com.swissre.dgf.data.model.DocSourceData;
import com.swissre.dgf.data.model.DocumentFormatEnum;
import com.swissre.dgf.data.model.FormData;
import com.swissre.dgf.data.model.FormDefinitionLang;
import com.swissre.dgf.data.model.Language;
import com.swissre.dgf.data.model.SourceSystem;

/**
 * Provides support for JUnit tests by making it easy to create new entities to
 * set up test cases. Subclasses of {@code AbstractJpaTest} automatically have
 * access to an instance of this class through the
 * {@code protected getTestSupport()} method.
 * 
 * @see AbstractJpaTest
 */
public class TestSupport
{
	private static final String DEFAULT_SOURCE_XML = "<sampleSourceData><dataItem>123</dataItem></sampleSourceData>";
	private static final Logger logger = Logger.getLogger(TestSupport.class.getName());
	
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private DataAccessService dataAccessService;
	
	/**
	 * Constructor - should only be instantiated by {@code AbstractJpaTest}.
	 */
	TestSupport(DataAccessService dataAccessService)
	{
		this.dataAccessService = dataAccessService;
	}

	/**
	 * Creates a new {@code DocPackage} with the given parameters. Defaults the
	 * status to New and the source XML to a simple XML document.
	 */
	public DocPackage createDocPackage(String sourceSystemId,
			String pkgTypeCode, String name, String languageId)
	{
		return createDocPackage(sourceSystemId, pkgTypeCode, name,
				DocPackageStatusEnum.IN_PROGRESS, languageId, DEFAULT_SOURCE_XML);
	}

	/**
	 * Creates a new {@code DocPackage} with the given parameters.
	 */
	public DocPackage createDocPackage(String sourceSystemId,
			String pkgTypeCode, String name, DocPackageStatusEnum status,
			String languageId, String sourceDataXml)
	{
		// Create and initialize a new entity instance
		DocPackage docPackage = new DocPackage();
		docPackage.setVersion(1);
		SourceSystem sourceSystem = getDataAccessService().getReference(SourceSystem.class, sourceSystemId);
		docPackage.setSourceSystem(sourceSystem);

		DocPackageType docPkgType = getDataAccessService().findSingleResultWithNamedQuery(
				DocPackageType.class, "DocPackageType.findByCode",
				with("code", pkgTypeCode).parameters());
		docPackage.setDocPackageType(docPkgType);
		
		DocPackageLang docPackageLang = new DocPackageLang();
		docPackageLang.setPackageName(name);
		DocPackageStatus docPkgStatus = getDataAccessService().getReference(DocPackageStatus.class, status.getId());
		docPackageLang.setDocPackageStatus(docPkgStatus);
		Language language = getDataAccessService().getReference(Language.class, languageId);
		docPackageLang.setLanguage(language);
		docPackageLang.setDocPackage(docPackage);
		
		// Persist the entity
		getDataAccessService().create(docPackage);
		logger.info("Created DocPackage with docPkgId = " + docPackage.getId());
		getDataAccessService().create(docPackageLang);
		
		DocSourceData docSourceData = new DocSourceData();
		docSourceData.setDocPkgId(docPackage.getId());
		docSourceData.setSourceDataXml(sourceDataXml);
		getDataAccessService().create(docSourceData);
		
		Set<DocPackageLang> docPackageLangs = new HashSet<DocPackageLang>();
		docPackageLangs.add(docPackageLang);
		docPackage.setDocPackageLangs(docPackageLangs);
		
		return docPackage;
	}
	
	/**
	 * Creates a new {@code DocPackageBusinessAttributes} with the given parameters.
	 */
	public DocPackageBusinessAttributes addBusinessAttributesToDocPackage(DocPackage docPackage, String policyNo,
			String inceptionDate, Integer carrierId, String carrierName, Integer brokerId, String brokerName,
			String industrySegment, Integer insuredId, String insuredName, String jurisdiction, String lineStatus,
			String underwriterUserId, String underwriterName, String underwritingSupportRepUserId,
			String underwritingSupportRepName, String lobCode, String lobName, String subLobCode, String subLobName, String carrierCountryCode, String expDate) {
		
		DocPackageBusinessAttributes businessAtts = new DocPackageBusinessAttributes();

		businessAtts.setPolicyNumber(policyNo);
		businessAtts.setCarrierId(carrierId);
		businessAtts.setCarrierName(carrierName);
		//businessAtts.setWholesaleBrokerId(brokerId);
		//businessAtts.setWholesaleBrokerName(brokerName);
		businessAtts.setIndustrySegment(industrySegment);
		//businessAtts.setInsuredId(insuredId);
		//businessAtts.setInsuredName(insuredName);
		businessAtts.setJurisdiction(jurisdiction);
		businessAtts.setLineStatus(lineStatus);
		businessAtts.setUnderwriterUserId(underwriterUserId);
		businessAtts.setUnderwriterName(underwriterName);
		businessAtts.setUnderwritingSupportRepUserId(underwritingSupportRepUserId);
		businessAtts.setUnderwritingSupportRepName(underwritingSupportRepName);

		try {
			businessAtts.setInceptionDate(dateFormat.parse(inceptionDate));
		}
		catch (ParseException e)
		{
			throw new RuntimeException(
					"Invalid inception date specified in unit test: "
							+ inceptionDate, e);
		}

		businessAtts.setId(docPackage.getId());
		businessAtts.setDocPkgId(docPackage.getId());
		businessAtts.setDocPackage(docPackage);
		businessAtts.setPrimaryLobCode(Integer.valueOf(lobCode));
		businessAtts.setPrimaryLobName(lobName);
		businessAtts.setSubLobCode(Integer.valueOf(subLobCode));
		businessAtts.setSubLobName(subLobName);
		businessAtts.setCarrierCountryCode(carrierCountryCode);
		
		try {
			businessAtts.setExpirationDate(dateFormat.parse(expDate));
		}
		catch (ParseException e)
		{
			throw new RuntimeException(
					"Invalid Expiration date specified in unit test: "
							+ inceptionDate, e);
		}
		
		docPackage.setBusinessAttributes(businessAtts);
		getDataAccessService().create(businessAtts);
		
		return businessAtts;
	}
 
	/**
	 * Creates a new {@code DocComponent} with the given parameters.
	 */
	public DocComponent addDocComponentToDocPackageLang(DocPackageLang docPackageLang,
			Long formDefLangId, String docComponentName,
			DocComponentStatusEnum status, int sequence, DocumentFormatEnum format)
	{
		FormDefinitionLang formDefLang = getDataAccessService().getReference(FormDefinitionLang.class, formDefLangId);
		return addDocComponentToDocPackage(docPackageLang, formDefLang, docComponentName, status, sequence, format);
	}
	
	/**
	 * Creates a new {@code DocComponent} with the given parameters.
	 */
	public DocComponent addDocComponentToDocPackage(DocPackageLang docPackageLang,
			FormDefinitionLang formDefLang, String docComponentName,
			DocComponentStatusEnum status, int sequence, DocumentFormatEnum format)
	{
		DocComponent docComponent = new DocComponent();
		docComponent.setFormDefinitionLang(formDefLang);
		docComponent.setName(docComponentName);
		docComponent.setSequence(sequence);
		docComponent.setEdmsRepository("DCHR_B01");
		
		
		
		
		DocComponentStatus docComponentStatus = getDataAccessService().getReference(DocComponentStatus.class, status.getId());
		docComponent.setDocComponentStatus(docComponentStatus);
		
		DocFormat docFormat = getDataAccessService().getReference(DocFormat.class, format.getId());
		docComponent.setDocFormat(docFormat);
		
		// Associate the docComponent and the docPackage
		Set<DocComponent> docComponentSet = docPackageLang.getDocComponents();
		
		if (docComponentSet == null)
		{
			docComponentSet = new HashSet<DocComponent>();
			docPackageLang.setDocComponents(docComponentSet);
		}
		
		docComponentSet.add(docComponent);
		docComponent.setDocPackageLang(docPackageLang);

		// Persist the entity
		getDataAccessService().create(docComponent);
		
        FormData formData = new FormData();
		
		formData.setDocCompId(docComponent.getId());
		
		formData.setFormXml("<dummyFormXml><container name='x'><item name='y'>123</item></container></dummyFormXml>");
		
		getDataAccessService().create(formData);
		
		docComponent.setFormData(formData);
		
		
		return docComponent;
	}

	private DataAccessService getDataAccessService()
	{
		return dataAccessService;
	}
}
