package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocComponentStatus} JPA entity.
 */
public class DocComponentStatusTest extends AbstractJpaTest
{
	@Test
	public void testFindAll()
	{
		List<DocComponentStatus> statusList = 
			getDataAccessService().findWithNamedQuery(
					DocComponentStatus.class,
					"DocComponentStatus.findAll");
		
		assertNotNull("Null list", statusList);
		assertEquals("Unexpected number of DocComponentStatus objects", 6, statusList.size());
		assertEquals("Unexpected DocComponentStatus #1", "Form Data Pending", statusList.get(0).getDescription());
		assertEquals("Unexpected DocComponentStatus #2", "To Be Generated", statusList.get(1).getDescription());
		assertEquals("Unexpected DocComponentStatus #3", "Editable", statusList.get(2).getDescription());
		assertEquals("Unexpected DocComponentStatus #4", "Finalizing", statusList.get(3).getDescription());
		assertEquals("Unexpected DocComponentStatus #5", "Final", statusList.get(4).getDescription());
	}

	@Test
	public void testFindByDescription()
	{
		final String desc = "Final";
		DocComponentStatus docCmpStatus =
			getDataAccessService().findSingleResultWithNamedQuery(
					DocComponentStatus.class,
					"DocComponentStatus.findByDescription",
					with("desc", desc).parameters());
		
		assertNotNull("Null result", docCmpStatus);
		assertNotNull("Null result id", docCmpStatus.getId());
		assertEquals("Unexpected description", desc, docCmpStatus.getDescription());
	}
}
