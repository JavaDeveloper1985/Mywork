package com.swissre.dgf.data;

import java.lang.reflect.Field;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;

import com.swissre.dgf.data.access.DataAccessService;

/**
 * Abstract base class for JPA-related test classes.
 */
public abstract class AbstractJpaTest
{
    private static final String PERSISTENCE_UNIT_NAME = "sr-dgf-jpa-domain-test";
    
    private DataAccessService dataAccessService;
    private EntityManager entityManager;
    private TestSupport testSupport;
    private boolean commit;
    
    protected AbstractJpaTest()
    {
    }

    /**
     * Allows subclasses to access a {@code TestSupport} instance for creating
     * entities in support of test cases.
     * 
     * @return TestSupport
     */
    protected TestSupport getTestSupport()
    {
    	if (this.testSupport == null)
    	{
    		this.testSupport = new TestSupport(getDataAccessService());
    	}
    	
		return this.testSupport;
	}

    /**
     * Allows subclasses to access the <code>DataAccessService</code>.
     * 
     * @return DataAccessService
     */
    protected DataAccessService getDataAccessService()
    {
    	if (this.dataAccessService == null)
    	{
            this.dataAccessService = new DataAccessService();
            
            try {
				Field emField = this.dataAccessService.getClass().getDeclaredField("em");
				emField.setAccessible(true);
				emField.set(this.dataAccessService, getEntityManager());
			}
            catch (Exception e)
            {
				throw new RuntimeException("Failed to inject EntityManager into DataAccessService", e);
			}
    	}
    	
        return this.dataAccessService;
    }

    protected EntityManager getEntityManager()
    {
    	if (this.entityManager == null)
    	{
            this.entityManager = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME).createEntityManager();
    	}
    	
        return this.entityManager;
    }

	@Before
    public void before()
    {
        this.commit = false;
        
        getEntityManager().getTransaction().begin();
    }
    
    /**
     * Can be called by individual tests to commit rather than rollback at the end of the test.
     */
    protected void enableCommit()
    {
        this.commit = true;
    }

    /**
     * Rolls back transactions after each test. Overriding methods should call
     * super.
     */
    @After
    public void after()
    {
        // Careful - entityManager can be null if there was an error building the entityManager in before().
        if (entityManager != null)
        {
            // Rollback the transaction, unless the test prevented it by calling commit().
            EntityTransaction tx = entityManager.getTransaction();
            if (tx != null && tx.isActive())
            {
                // Send SQL statements to server.
                entityManager.flush();

                if (commit)
                {
                    tx.commit();
                }
                else
                {
                    tx.rollback();
                }
            }
        }
    }
    
}
