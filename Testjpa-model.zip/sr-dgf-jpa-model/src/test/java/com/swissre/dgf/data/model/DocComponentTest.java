package com.swissre.dgf.data.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocComponent} JPA entity.
 */
public class DocComponentTest extends AbstractJpaTest
{
	private static final Long FORM_DEF_LANG_ID = 1L;

	private DocPackage docPackage;
	
	private DocPackageLang docPackageLang;
	
	@Before
	public void setUp()
	{
		this.docPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		this.docPackageLang = docPackage.getDocPackageLangs().iterator().next();

	}
	
	@Test
	public void testCreate()
	{
		// Uncomment next line to commit at the end of the test rather than rollback (but don't check it in uncommented!!)
		//enableCommit();
		
		// Create and persist a new entity
		DocComponent docComponent = getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID,
				"JUnit Form", DocComponentStatusEnum.FORM_DATA_PENDING, 1,
				DocumentFormatEnum.WORD);
		
		// Apply assertions on the result
		assertNotNull("Null entity returned", docComponent);
		assertNotNull("Id generation error: null id", docComponent.getId());
		assertTrue("Negative id generated", (docComponent.getId() > 0));
		assertNotNull("Null entity version", docComponent.getRowVersion());
	}
	
	@Test
	public void testUpdate()
	{
		// Uncomment next line to commit at the end of the test rather than rollback (but don't check it in uncommented!!)
		//enableCommit();

		// Create and persist a new entity
		DocComponent docComponent = getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID,
				"JUnit Form", DocComponentStatusEnum.FORM_DATA_PENDING, 1,
				DocumentFormatEnum.WORD);
		long originalRowVersion = docComponent.getRowVersion();
		
		// Update entity properties
		final String newComponentName = "New Name";
		docComponent.setName(newComponentName);
		
		final Integer newSequence = 2;
		docComponent.setSequence(newSequence);
		
		DocComponentStatus docComponentStatus =
			getDataAccessService().getReference(DocComponentStatus.class, DocComponentStatusEnum.TO_BE_GENERATED.getId());
		docComponent.setDocComponentStatus(docComponentStatus);
		
		// Persist the updates
		DocComponent updatedDocComponent = getDataAccessService().update(docComponent);
		
		// Apply assertions on the result
		assertEquals("Primary key changed on update!", docComponent.getId(), updatedDocComponent.getId());
		assertEquals("Row version not updated!", originalRowVersion, updatedDocComponent.getRowVersion().longValue());
		assertEquals("Package name did not update", newComponentName, updatedDocComponent.getName());
		assertEquals("Sequence did not update", newSequence, updatedDocComponent.getSequence());
		assertEquals("Doc component status did not update", docComponentStatus.getId(), updatedDocComponent.getDocComponentStatus().getId());
	}
}
