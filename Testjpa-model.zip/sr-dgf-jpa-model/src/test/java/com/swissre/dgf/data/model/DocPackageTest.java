package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Logger;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocPackage} JPA entity.
 */
public class DocPackageTest extends AbstractJpaTest
{
	private static final Logger logger = Logger.getLogger(DocPackageTest.class.getName());

	private static final Long FORM_DEF_LANG_ID = 1L;
	
	@Test
	public void testCreate()
	{
		// Uncomment next line to commit at the end of the test rather than rollback (but don't check it in uncommented!!)
		//enableCommit();
		
		// Create and persist a new DocPackage and DocPackageAttributes
		DocPackage docPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		getTestSupport().addBusinessAttributesToDocPackage(docPackage, "555555",
				"2013-05-01", 111, "SRI", 222, "Broker X", "Conglomerates", 333, "General Electric", "US",
				"Binder Verified", "XYZ123", "Joe U", "ABC123", "John R" ,"2", "Casualty", "23142", "LAWYERS NOTARI.", "CHE", "2014-05-01");
		
		// Apply assertions on the result
		assertNotNull("Null entity returned", docPackage);
		assertNotNull("Id generation error: null id", docPackage.getId());
		assertTrue("Negative id generated", (docPackage.getId() > 0));
		assertNotNull("Null entity version", docPackage.getRowVersion());
	}
	
	@Test
	public void testFindDocPackageAndComponents()
	{
		DocPackage newDocPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		DocPackageLang newDocPackageLang = newDocPackage.getDocPackageLangs().iterator().next();
		DocPackageBusinessAttributes newBusinessAtts = getTestSupport().addBusinessAttributesToDocPackage(
				newDocPackage, "555555", "2013-05-01", 111, "SRI", 222, "Broker X", "Conglomerates", 333,
				"General Electric", "US", "Binder Verified", "XYZ123", "Joe U", "ABC123", "John R", "2", "Casualty", "23142", "LAWYERS NOTARI.", "CHE", "2014-05-01");
		Collection<DocComponent> newDocComponents = Arrays.asList(
				getTestSupport().addDocComponentToDocPackageLang(newDocPackageLang, FORM_DEF_LANG_ID, "Form 1", DocComponentStatusEnum.TO_BE_GENERATED, 1, DocumentFormatEnum.PDF),
				getTestSupport().addDocComponentToDocPackageLang(newDocPackageLang, FORM_DEF_LANG_ID, "Form 2", DocComponentStatusEnum.EDITABLE, 2, DocumentFormatEnum.WORD));
		Long docPkgId = newDocPackage.getId();
		
		logger.info("docPkgId = " + docPkgId);

		// Force the inserts to be issued and then clear the persistence context
		getEntityManager().flush();
		getEntityManager().clear();

		// Now query the DocPackage we just created
		DocPackageLang docPackageLang = getDataAccessService()
				.findSingleResultWithNamedQuery(DocPackageLang.class,
						"DocPackageLang.findDocPackageAndComponents",
						with("docPkgId", docPkgId).and("languageId","US_en").parameters());
		DocPackage docPackage = docPackageLang.getDocPackage();
		
		assertNotNull("Null entity returned", docPackage);
		
		// Detach the DocPackage and rollback the transaction
		getEntityManager().clear();
		getEntityManager().getTransaction().rollback();
		
		// Now check that all expected fields were returned by the query
		// (lazy loading is now disabled).
		assertNotNull("Null package type", docPackage.getDocPackageType());
		assertNotNull("Null package type description", docPackage.getDocPackageType().getDescription());
		assertNotNull("Null package status", docPackageLang.getDocPackageStatus());
		assertNotNull("Null package status description", docPackageLang.getDocPackageStatus().getDescription());
		
		assertNotNull("Null business attributes", docPackage.getBusinessAttributes());
		assertNotNull("Null carrier id", docPackage.getBusinessAttributes().getCarrierId());
		assertNotNull("Null carrier name", docPackage.getBusinessAttributes().getCarrierName());
		assertEquals("Unexpected carrier id", newBusinessAtts.getCarrierId(), docPackage.getBusinessAttributes().getCarrierId());
		assertEquals("Unexpected carrier name", newBusinessAtts.getCarrierName(), docPackage.getBusinessAttributes().getCarrierName());
		
		assertNotNull("Null docComponents", docPackageLang.getDocComponents());
		assertEquals("Unexpected number of docComponents", newDocComponents.size(), docPackageLang.getDocComponents().size());

		for (DocComponent docComponent : docPackageLang.getDocComponents())
		{
			assertNotNull("Null form definition", docComponent.getFormDefinitionLang());
			assertNotNull("Null form definition form id", docComponent.getFormDefinitionLang().getFormDefinition().getFormId());
			assertNotNull("Null form definition form title", docComponent.getFormDefinitionLang().getFormDefinition().getFormTitle());
		}
	}
	
	@Test
	public void testUpdate()
	{
		// Uncomment next line to commit at the end of the test rather than rollback (but don't check it in uncommented!!)
		//enableCommit();

		// Create and persist a new entity
		DocPackage docPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		DocPackageLang newDocPackageLang = docPackage.getDocPackageLangs().iterator().next();
		long originalRowVersion = docPackage.getRowVersion();
		
		// Update entity properties
		final String newPkgName = "New Name";
		newDocPackageLang.setPackageName(newPkgName);
		
		DocPackageStatus docPkgStatus = getDataAccessService().getReference(DocPackageStatus.class, DocPackageStatusEnum.IN_PROGRESS.getId());
		newDocPackageLang.setDocPackageStatus(docPkgStatus);
		
		// Persist the updates
		DocPackage updatedDocPackage = getDataAccessService().update(docPackage);
		
		// Apply assertions on the result
		assertEquals("Primary key changed on update!", docPackage.getId(), updatedDocPackage.getId());
		assertEquals("Row version not updated!", originalRowVersion, updatedDocPackage.getRowVersion().longValue());
		assertEquals("Package status did not update", docPkgStatus.getId(), newDocPackageLang.getDocPackageStatus().getId());
		assertEquals("Package name did not update", newPkgName, newDocPackageLang.getPackageName());
	}
	
	
	@Test
	public void testFindNextSequenceNo()
	{
		Integer sequence = 1;
		DocPackage newDocPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		DocPackageLang docPackageLang = newDocPackage.getDocPackageLangs().iterator().next();
		
		getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID, "Form 1", DocComponentStatusEnum.TO_BE_GENERATED, sequence++, DocumentFormatEnum.PDF);
		getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID, "Form 2", DocComponentStatusEnum.EDITABLE, sequence++, DocumentFormatEnum.WORD);
		getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID, "Form 3", DocComponentStatusEnum.TO_BE_GENERATED, sequence++, DocumentFormatEnum.PDF);
		getTestSupport().addDocComponentToDocPackageLang(docPackageLang, FORM_DEF_LANG_ID, "Form 4", DocComponentStatusEnum.EDITABLE, sequence++, DocumentFormatEnum.WORD);
		Long docPkgId = newDocPackage.getId();

		Integer seqNo = getDataAccessService()
				.findSingleResultWithNamedQuery(Integer.class,
						"DocPackageLang.findNextSequenceNumber",
						with("docPkgId", docPkgId).and("languageId", docPackageLang.getLanguage().getId()).parameters());
		
		assertNotNull("Null seq no reurned", seqNo);
		logger.info("seqNo = " + seqNo);
		assertEquals("Unexpected seq no returned", sequence, seqNo);
	}
}
