package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class FormSelectionCriteriaValueTest extends AbstractJpaTest{
	
	@Test
	public void testFindByType(){
		List<FormSelectionCriteriaValue> allBusTypeList = 
		getDataAccessService().findWithNamedQuery(FormSelectionCriteriaValue.class, 
				"FormSelectionCriteriaValue.findByCriteriaType",
				with("criteriaType", "BUSINESSTYPE").and("sourceSystem", "MAN").parameters());
		
		assertNotNull("Could not find FormSelectionCriteriaValue ", allBusTypeList);
		assertEquals("Unexpected BUSINESSTYPE Size", 2, allBusTypeList.size());		
	}
	
	@Test
	public void testFindByTypeAndDesc(){
		FormSelectionCriteriaValue lcr = 
		getDataAccessService().findSingleResultWithNamedQuery(FormSelectionCriteriaValue.class, 
				"FormSelectionCriteriaValue.findByCriteriaTypeAndDesc",
				with("criteriaType", "LCR").and("criteriaDesc", "Large Corporate Risk").and("sourceSystem", "MAN").parameters());
		
		assertNotNull("Could not find LCR ", lcr);
		assertEquals("Unexpected LCR", "1", lcr.getCriteriaValue());	
	}

}
