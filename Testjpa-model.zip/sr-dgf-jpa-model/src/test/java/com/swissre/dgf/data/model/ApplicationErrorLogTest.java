package com.swissre.dgf.data.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Query;

import org.junit.Assert;
import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code ApplicationErrorLog} JPA entity.
 */
public class ApplicationErrorLogTest extends AbstractJpaTest {
	
	@Test
	public void testInsertApplicationErrorLog() {
		enableCommit();
    	ApplicationErrorLog errorLog = new ApplicationErrorLog();
    	errorLog.setUserId("JUNIT1");
    	errorLog.setErrorDate(new Timestamp(new Date().getTime()));    	
    	errorLog.setErrorMsg("Uh oh");
    	errorLog.setStacktrace("[... big long stack trace...]");
    	errorLog.setContext("Document Package 11966"); 
    	errorLog.setChannel("UI");
		errorLog.setServerEnv("/opt/was/p8/AppServer/profiles/p8001a"); 
        
    	getDataAccessService().create(errorLog);
    	
		Query query = getDataAccessService().getEntityManager()
				.createQuery("select e from ApplicationErrorLog e where e.id = " + errorLog.getId());
		ApplicationErrorLog testErrorLog = (ApplicationErrorLog) query.getSingleResult();
		
		Assert.assertNotNull(testErrorLog);
		
		// should return the same entity since we're still in the same transaction
		Assert.assertSame(errorLog, testErrorLog); 
	}
}
