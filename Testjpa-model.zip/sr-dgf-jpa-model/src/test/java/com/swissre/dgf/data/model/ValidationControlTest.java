package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.*;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code SourceSystem} JPA entity.
 */
public class ValidationControlTest extends AbstractJpaTest
{

	
	@Test
	public void testFindValidationEnabledValue()
	{
		final String systemId="MAN";
		final int packageType=4;
		
		String isValidationEnabled = 
		getDataAccessService().findSingleResultWithNamedQuery(String.class, 
    			"ValidationControl.findValidationEnabledValue", 
    			with("sourceSystemId", systemId)
    			.and("docPackageTypeId", packageType).parameters());
	
	assertNotNull("Could not find Qualified Name '" + "'", isValidationEnabled);
	
		
	}
	
	@Test
	public void testFindRejectionLevelValue()
	{
		final String systemId="MAN";
		final int packageType=4;
		
		String rejectionLevel = 
		getDataAccessService().findSingleResultWithNamedQuery(String.class, 
    			"ValidationControl.findRejectionLevelValue", 
    			with("sourceSystemId", systemId)
    			.and("docPackageTypeId", packageType).parameters());
	
	assertNotNull("Could not find Qualified Name '" + "'", rejectionLevel);
	
		
	}
}
