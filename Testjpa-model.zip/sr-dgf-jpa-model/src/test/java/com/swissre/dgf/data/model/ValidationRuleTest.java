package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code SourceSystem} JPA entity.
 */
public class ValidationRuleTest extends AbstractJpaTest
{

	
	@Test
	public void testfindValidationTemplate()
	{
		final String qname = "{http://www.swissre.com/dgf/man/invoice/v1}invoiceData";
		
		ValidationRule qnameXsd = 
			getDataAccessService().findSingleResultWithNamedQuery(
					ValidationRule.class,
					"ValidationRule.findValidationTemplate",with("qname", qname).parameters());;
		
		assertNotNull("Could not find Qualified Name '" + qname + "'", qnameXsd);
		assertEquals("Unexpected Qualified Name", "{http://www.swissre.com/dgf/man/invoice/v1}invoiceData", qnameXsd.getQname());
		
	}
}
