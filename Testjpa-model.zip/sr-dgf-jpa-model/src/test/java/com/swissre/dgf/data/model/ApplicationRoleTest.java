package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code SourceSystem} JPA entity.
 */
public class ApplicationRoleTest extends AbstractJpaTest {
	
	@Test
	public void testFindContentByName() {
		final Integer emeaInvoicePkgTypeId = 4;
		List<ApplicationRole> requiredRoles = 
			getDataAccessService().findWithNamedQuery(ApplicationRole.class,
	    			"ApplicationRole.findRequiredRoles", 
	    			with("capability", CapabilityEnum.MODIFY_PACKAGE.getName())
	    			.and("sourceSystem", "MAN")
	    			.and("packageType", emeaInvoicePkgTypeId).parameters());
		
		assertTrue("Null or empty result", (requiredRoles != null && !requiredRoles.isEmpty()));
		
		for (ApplicationRole role : requiredRoles) {
			System.out.println(role.getName());
		}
	}
	
	@Test
	public void testFindAllITSupportRole() {
		List<ApplicationRole> requiredRoles = 
			getDataAccessService().findWithNamedQuery(ApplicationRole.class,
	    			"ApplicationRole.findAllITSupportRole");
		
		assertTrue("Null or empty result", (requiredRoles != null && !requiredRoles.isEmpty()));
		
		for (ApplicationRole role : requiredRoles) {
			System.out.println(role.getName());
		}
	}
}
