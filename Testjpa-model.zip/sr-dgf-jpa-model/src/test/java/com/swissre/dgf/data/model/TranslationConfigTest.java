package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class TranslationConfigTest extends AbstractJpaTest{

	@Test
	public void testFindConfigsByQName(){
		String qName = "{http://www.swissre.com/dgf/man/invoice/v1}invoiceData";
		List<TranslationConfig> configs = getDataAccessService().findWithNamedQuery(TranslationConfig.class, 
				"TranslationConfig.findConfigsByQName", 
				with("qName", qName).parameters());
		
		assertTrue("Could not load TranslationConfigs", configs.size() > 0);
		assertEquals("TranslationConfig QName mismatch ", qName, configs.get(0).getSourceDataXmlType().getQname());
	}
}
