package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocPackageStatus} JPA entity.
 */
public class DocPackageStatusTest extends AbstractJpaTest
{
	@Test
	public void testFindAll()
	{
		List<DocPackageStatus> statusList =
			getDataAccessService().findWithNamedQuery(
					DocPackageStatus.class,
					"DocPackageStatus.findAll");
		System.out.println(statusList);
		assertNotNull("Null list", statusList);
		assertEquals("Unexpected number of DocPackageStatus objects", 5, statusList.size());
		assertEquals("Unexpected DocPackageStatus #1", "In Progress", statusList.get(0).getDescription());
		assertEquals("Unexpected DocPackageStatus #5", "Generating", statusList.get(1).getDescription());
		assertEquals("Unexpected DocPackageStatus #2", "In Progress-Merged", statusList.get(2).getDescription());
		assertEquals("Unexpected DocPackageStatus #3", "Finalizing", statusList.get(3).getDescription());
		assertEquals("Unexpected DocPackageStatus #4", "Final", statusList.get(4).getDescription());
	}
	
	@Test
	public void testFindByDescription()
	{
		final String desc = "Final";
		DocPackageStatus docPkgStatus =
			getDataAccessService().findSingleResultWithNamedQuery(
					DocPackageStatus.class,
					"DocPackageStatus.findByDescription",
					with("desc", desc).parameters());
		
		assertNotNull("Null result", docPkgStatus);
		assertNotNull("Null result id", docPkgStatus.getId());
		assertEquals("Unexpected description", desc, docPkgStatus.getDescription());
	}
}
