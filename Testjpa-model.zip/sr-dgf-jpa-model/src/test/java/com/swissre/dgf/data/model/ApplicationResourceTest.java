package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.*;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code SourceSystem} JPA entity.
 */
public class ApplicationResourceTest extends AbstractJpaTest
{

	
	@Test
	public void testFindContentByName()
	{
			final String systemId="common.xsd";
		
			String xsdContent = 
			getDataAccessService().findSingleResultWithNamedQuery(String.class, 
	    			"ApplicationResource.findContentByName", 
	    			with("name", systemId)
	    			.and("type", ApplicationResourceTypeEnum.XSD.getId()).parameters());
		
		assertNotNull("Could not find Qualified Name '" + "'", xsdContent);
	
	}
}
