package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class TemplateGenerateDynamicDataConfigTest extends AbstractJpaTest {

	@Test
	public void testSelectByDataType(){
		String dataType = "SOURCE_SYSTEM";
		String xpath = "document/packageInfo/sourceSystem";
		List<TemplateGenerateDynamicDataConfig> configs = getDataAccessService().findWithNamedQuery(TemplateGenerateDynamicDataConfig.class, 
				"TemplateGenerateDynamicDataConfig.selectByType", 
				with("dynamicDataType", dataType).parameters());
		
		assertTrue("Could not load TemplateGenerateDynamicDataConfig", configs.size() > 0);
		assertEquals("TemplateGenerateDynamicDataConfig path mismatch ", xpath, configs.get(0).getXpath());

	}
	
	@Test
	public void testSelectBySampleXmlType(){
		Long samplexmlType = 1L;
		List<TemplateGenerateDynamicDataConfig> configs = getDataAccessService().findWithNamedQuery(TemplateGenerateDynamicDataConfig.class, 
				"TemplateGenerateDynamicDataConfig.selectBySampleXmlId", 
				with("sampleXmlId", samplexmlType).parameters());
		
		assertTrue("Could not load TemplateGenerateDynamicDataConfig", configs.size() > 0);
		assertEquals("TemplateGenerateDynamicDataConfig path mismatch ", samplexmlType, Long.valueOf(configs.get(0).getTemplateGenerateSampleXml().getSampleXmlId()));

	}
}
