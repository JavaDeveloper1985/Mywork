package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;


import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;
import com.swissre.dgf.data.model.DocPackage;
import com.swissre.dgf.data.model.DocPackageBusinessAttributes;

public class DocPackageBusinessAttributesTest extends AbstractJpaTest {
	
	@Test
	public void testFindByDocPkgId() {
		DocPackage docPackage = getTestSupport().createDocPackage("MAN", "INV", "JUnit Document Package", "US_en");
		getTestSupport().addBusinessAttributesToDocPackage(docPackage, "555555",
				"2013-05-01", 111, "SRI", 222, "Broker X", "Conglomerates", 333, "General Electric", "US",
				"Binder Verified", "XYZ123", "Joe U", "ABC123", "John R", "2", "Casualty", "23142", "LAWYERS NOTARI.", "CHE", "2014-05-01" );
		
		DocPackageBusinessAttributes attributes  = 
			getDataAccessService().findSingleResultWithNamedQuery(DocPackageBusinessAttributes.class, 
					"DocPackageBusinessAttributes.findAttributesByDocPkgId", 
					with("docPkgId", docPackage.getId()).parameters());
		
		assertEquals("Unexpected Policy Number", "555555", attributes.getPolicyNumber());
		
	}

}
