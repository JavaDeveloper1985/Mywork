package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;


public class BusinessAreaTest extends AbstractJpaTest{

	@Test
	public void testFindBusArea(){
		int lobCode = 1;
		String sourceTypeCode = "Manhattan";
		
		BusinessArea area = getDataAccessService().findSingleResultWithNamedQuery(BusinessArea.class, 
				"BusinessArea.findBusinessArea", 
				with("primaryLobCode", lobCode).and("sourceSystemCodeType", sourceTypeCode).parameters());
		assertEquals("Invalid Business Area code for lob property ", "PROP", area.getEdmsBusAreaCode());
	}
}
