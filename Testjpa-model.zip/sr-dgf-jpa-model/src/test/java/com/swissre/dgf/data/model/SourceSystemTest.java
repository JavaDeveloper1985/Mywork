package com.swissre.dgf.data.model;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code SourceSystem} JPA entity.
 */
public class SourceSystemTest extends AbstractJpaTest
{
	@Test
	public void testFindAll()
	{
		List<SourceSystem> sourceSystemList = 
			getDataAccessService().findWithNamedQuery(
					SourceSystem.class,
					"SourceSystem.findAll");
		
		assertNotNull("Null list", sourceSystemList);
		assertTrue("Empty SourceSystem list", sourceSystemList.size() > 0);
		
		boolean containsManhattan = false;
		for (SourceSystem sourceSystem : sourceSystemList)
		{
			if (sourceSystem.getId().equals("MAN"))
			{
				containsManhattan = true;
				break;
			}
		}
		
		assertTrue("'MAN' is missing from the TSOURCESYSTEM table!", containsManhattan);
	}
	
	@Test
	public void testFindById()
	{
		final String appId = "MAN";
		
		SourceSystem manSourceSys = 
			getDataAccessService().find(SourceSystem.class, appId);
		
		assertNotNull("Could not find SourceSystem '" + appId + "'", manSourceSys);
		assertEquals("Unexpected SourceSystem.name", "Manhattan", manSourceSys.getName());
	}
}
