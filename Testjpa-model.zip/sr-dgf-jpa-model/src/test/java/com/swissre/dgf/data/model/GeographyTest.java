package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class GeographyTest extends AbstractJpaTest{

	@Test
	public void testFindGeographyByCountry()
	{
		final String countryCode = "CHE";
		
		Geography geo = 
			getDataAccessService().findSingleResultWithNamedQuery(
					Geography.class,
					"Geography.findGeographyByCountry",
					with("countryCode", countryCode).parameters());
		assertNotNull("Could not find Geography ", geo);
		assertEquals("Unexpected Country Code", "EMEA", geo.getGeographyId());
	}
}
