package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.StoredProcedureQuery;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the Stored Procedure DGF.PKG_RULE_MAPPING.proc_form_selection_rule.
 */
public class StoredProcFormSelectionRuleTest extends AbstractJpaTest
{
	private static final Logger logger = Logger.getLogger(StoredProcFormSelectionRuleTest.class.getName());	
	
    private String sourceSystemIdVar = "MAN";
    private String docPackageTypeCodeVar = "QUOTATION";
    private String languageVar = "GB_en";
	private ArrayList<String> optionalParmList;
	private Boolean includeByDefaultVar;
	private String docSubPackageTypeCodeVar = null;
	
	void init(){
		optionalParmList = new ArrayList<String>();
		optionalParmList.add("p_country_code");
		optionalParmList.add("p_state_code");
		optionalParmList.add("p_lob");
		optionalParmList.add("p_sub_lob");
		optionalParmList.add("p_reinsurance_flag");
		optionalParmList.add("p_fast_track");
		optionalParmList.add("p_facilities");
		optionalParmList.add("p_lcr");
		optionalParmList.add("p_business_type");
		optionalParmList.add("p_reins_main_ind_seg");
		optionalParmList.add("p_approved");
		optionalParmList.add("p_include_by_default");
		optionalParmList.add("p_doc_sub_pkg_typ_code");
		optionalParmList.add("p_carrier_mdm_id");
	}

	
	/**
	 * Test Select Form method with mandatory params only and ignore includeByDefault flag
	 */
	@Test
	public void testSelectFormsWithReqdParams()
	{
		// Initialize data setup
		init();
		
		// Call service method. 
		List<FormInit> formInitList = 
			selectForms(sourceSystemIdVar,docPackageTypeCodeVar,languageVar,null);		
		
		printResults(formInitList);
		
    }
	
	
	/**
	 * Test Select Form method with mandatory params and includeByDefault flag as true
	 */
	@Test
	public void testSelectFormsToBeIncludedByDefault()
	{
		// Initialize data setup
		init();
		includeByDefaultVar = new Boolean(true);
		
		// Call service method. 
		List<FormInit> formInitList = 
			selectForms(sourceSystemIdVar,docPackageTypeCodeVar,languageVar,
					null,includeByDefaultVar,docSubPackageTypeCodeVar);		
		
		printResults(formInitList);
		
    }
	
	
	/**
	 * Test Select Form method with mandatory and some optional params. 
	 * includeByDefaultVar flag is ignored
	 */
	@Test
	public void testSelectFormsWithOptionalParams()
	{
		// Initialize data setup
		init();
		includeByDefaultVar = new Boolean(true);
			
		//Optional Params
		String countryCodeVar = "ZAF";
        String stateCodeVar = "";
        String lobVar = "Property";
        String fastTrackVar = "0";
        String facilitiesVar = "0";
        String lcrVar = "0";
        String businessTypeVar = "Non-fronting";
        //String approvedVar = null; Not setting approved. Code should be able to pass a null automatically
        String carrierIdVar = "1906";

		// Call service method. 
		List<FormInit> formInitList = 
			selectForms(sourceSystemIdVar,docPackageTypeCodeVar,languageVar,
					with ("countryCode", countryCodeVar).
					and ("lob", lobVar).
					and ("stateCode",stateCodeVar).
					and ("businessType", businessTypeVar).
					and ("lcr",lcrVar).
					and ("fastTrack", fastTrackVar).
					and ("facilities", facilitiesVar).
					and ("carrierId", carrierIdVar).
					parameters());		
		
		printResults(formInitList);
		
    }
	
	
	
	/**
	 * Test Select Form method with mandatory and some optional params.
	 */
	@Test
	public void testSelectFormsToBeIncludedByDefaultWithOptionalParams()
	{
		// Initialize data setup
		init();
		includeByDefaultVar = new Boolean(false);
		
		//Optional Params
		String countryCodeVar = "US";
		String stateCodeVar = "NY";
		String lobVar = "Marine";
		String fastTrackVar = "1";
		String facilitiesVar = "1";
		String lcrVar = "1";
		String businessTypeVar = "Non-fronting";
		//String approvedVar = null; Not setting approved. Code should be able to pass a null automatically
		String carrierIdVar = "6087077";
		
		// Call service method. 
		List<FormInit> formInitList = 
			selectForms(sourceSystemIdVar,docPackageTypeCodeVar,languageVar,
					with ("countryCode", countryCodeVar).
					and ("lob", lobVar).
					and ("stateCode",stateCodeVar).
					and ("businessType", businessTypeVar).
					and ("lcr",lcrVar).
					and ("fastTrack", fastTrackVar).
					and ("facilities", facilitiesVar).
					and ("carrierId", carrierIdVar).
					parameters(),includeByDefaultVar,docSubPackageTypeCodeVar);		
		
		printResults(formInitList);
		
    }
		
	public List<FormInit> selectForms(String sourceSystemId,
			String docPackageTypeCode, String language,	Map<String,Object> formSelectionCriteria)
	{
		
		return selectForms(sourceSystemId, docPackageTypeCode, language, formSelectionCriteria, false,docSubPackageTypeCodeVar);
	}

	
	
	/**
	 * Should be similar to the selectForms() method in FromsSelectionService.java 
	 *  
	 */
	private List<FormInit> selectForms(String sourceSystemId,
			String docPackageTypeCode, String language, Map<String,Object> formSelectionCriteria, 
			Boolean includeByDefault, String docSubPackageTypeCode)
	{
		StoredProcedureQuery proc = getDataAccessService().getEntityManager().createNamedStoredProcedureQuery("FormDefinitionLang.getList");
		proc.setParameter("p_source_system_id",		sourceSystemId);
		proc.setParameter("p_doc_pkg_typ_code",		docPackageTypeCode);
		proc.setParameter("p_language",				language);
		proc.setParameter("p_country_code",			"ZAF");
		proc.setParameter("p_state_code",			null);
		proc.setParameter("p_lob",					"Casualty");
		proc.setParameter("p_sub_lob",				null);
		proc.setParameter("p_reinsurance_flag",		"0");
		proc.setParameter("p_fast_track",			"1");
		proc.setParameter("p_facilities",			"1");
		proc.setParameter("p_lcr",					"1");
		proc.setParameter("p_business_type",		"Fronting");
		proc.setParameter("p_reins_main_ind_seg",	null);
		proc.setParameter("p_approved",				null);
		proc.setParameter("p_include_by_default",	null);
		proc.setParameter("p_doc_sub_pkg_typ_code",	docSubPackageTypeCode);
		proc.setParameter("p_carrier_mdm_id",		null);
		
		
		if (includeByDefault != null) {
			proc.setParameter("p_include_by_default",	boolToString(includeByDefault));
		}

		try{
			@SuppressWarnings("unchecked")
			List<FormDefinitionLang> queryResults = proc.getResultList();
			
			List<FormInit> formInitList = new ArrayList<FormInit>(queryResults.size());
			for (FormDefinitionLang formDef : queryResults) {
				FormSelectionCriteria criteria = formDef.getFormDefinition().getFormSelectionCriteria();
				if(null!=criteria ){
					formInitList.add(new FormInit(formDef,criteria.getMandatory() , null, null));
				}
				
			}
		
	    return formInitList;
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		  return null;
    }
	

	void printOptionalParams(String name, String val){
		logger.info("optionalParam: "+name+ " Val:"+val);
	}
	
	
	void printResults(List<FormInit> formInitList){
		logger.info("#### FormDefinition List SIZE: "+formInitList.size()+" ####");
		
		Iterator<FormInit> iterator = formInitList.iterator();
		FormInit formInit;
		FormDefinitionLang formDefinitionLang = null;
		FormDefinition formDefinition = null;
	    int counter = 1;
	    while (iterator.hasNext()) {
	    	formInit = (FormInit)iterator.next();
	    	formDefinitionLang = formInit.getFormDefinitionLang();
	    	formDefinition = formDefinitionLang.getFormDefinition();
	    	logger.info("RECORD #:"+ counter++ +
	    			" | Form Id: "+formDefinition.getFormId()+
	    			" | Form Language: "+formDefinitionLang.getLanguage().getId()+
	    			" | Form Title: "+formDefinition.getFormTitle()+
					" | Mandatory: "+formInit.getMandatory());
	    }
	    
	    logger.info("\n");
	}
	
	/** Return null, "0" or "1". */
	private String boolToString(Boolean b) {
		String s = null;
		if (b != null) {
			s = (b ? "1" : "0");
		}
		return s;
	}

}
