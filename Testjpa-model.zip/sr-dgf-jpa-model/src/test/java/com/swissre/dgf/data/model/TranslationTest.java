package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class TranslationTest extends AbstractJpaTest{

	@Test
	public void findLOBsByCodeType(){
		final String codeType = "Manhattan"; 
		
		List<Translation> translations = getDataAccessService().findWithNamedQuery(Translation.class, 
				"Translation.findLOBsByCodeType", 
				with("codeType", codeType).parameters());
		assertEquals("Invalid codeType ", codeType,translations.get(0).getSourceSystemCodeType());
	}
	
	public void testFindTranslation(){
		final String codeType = "Manhattan";
		final String language = "US_en";
		final String code = "1";
		final String translatedString = "Property";
		final String translationType = "LOB";
		
		Translation translation = getDataAccessService().findSingleResultWithNamedQuery(Translation.class, 
				"Translation.findLOBsByCodeType", with("codeType", codeType).and("languageId", language)
				.and("code", code)
				.and("trasnlationType", translationType).parameters());
		
		assertEquals("Invalid Translation ", translatedString ,translation.getTranslation());
		assertEquals("Invalid Language ", language ,translation.getLanguage().getId());
		
	}
}
