package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocPackageType} JPA entity.
 */
public class DocPackageTypeTest extends AbstractJpaTest
{
	@Test
	public void testFindAll()
	{
		List<DocPackageType> pkgTypeList = 
			getDataAccessService().findWithNamedQuery(
					DocPackageType.class,
					"DocPackageType.findAll");
		
		assertNotNull("Null list", pkgTypeList);
		assertTrue("Empty DocComponentType list", pkgTypeList.size() > 0);
	}
	
	@Test
	public void testFindByCode()
	{
		final String pkgTypeCode = "INV";
		
		DocPackageType docPkgType = 
			getDataAccessService().findSingleResultWithNamedQuery(
					DocPackageType.class,
					"DocPackageType.findByCode",
					with("code", pkgTypeCode).parameters());
		
		assertNotNull("Could not find DocPackageType '" + pkgTypeCode + "'", docPkgType);
		assertEquals("Unexpected DocPackageType found", "Invoice", docPkgType.getDescription());
	}
	
	@Test
	public void testFindIdByCode()
	{
		final String pkgTypeCode = "INV";
		
		int docPkgTypeId = 
			getDataAccessService().findSingleResultWithNamedQuery(
					Integer.class,
					"DocPackageType.findIdByCode",
					with("code", pkgTypeCode).parameters());
		
	assertNotNull("Could not find DocPackageType '" + pkgTypeCode + "'", docPkgTypeId);
	assertEquals("Unexpected DocPackageType found", 1, docPkgTypeId);
	}
}
