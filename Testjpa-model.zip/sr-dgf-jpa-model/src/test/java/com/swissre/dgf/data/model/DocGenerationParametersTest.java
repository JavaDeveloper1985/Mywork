package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;
import com.swissre.dgf.data.model.DocGenerationParameters;

/**
 * JUnit test class for the {@code DocGenerationParameters} model class
 * (which is used only to hold the results of a named query and is not
 * mapped directly to a table).
 */
public class DocGenerationParametersTest extends AbstractJpaTest
{
	@Test
	public void testFindForDocPackage()
	{
		final String appId = "MAN";
		final String docPkgType = "REMINDER";
		final String docSubPkgType ="REMINDER-FIRST";
		DocGenerationParameters docGenParams = 
			getDataAccessService().findSingleResultWithNamedQuery(
					DocGenerationParameters.class,
					"DocGenerationParameters.findForDocPackage",
					 with ("docSubPkgTypeCode", docSubPkgType)
					.and("appId", appId)
					.and("docPkgTypeCode", docPkgType)
					.parameters());
		
		// Perform assertions to all test cases
		validateResult(docGenParams);
		
		// Perform assertions specific to this test case...

		// Not valid yet, since we haven't populated template name or document format yet
		assertEquals("DocGenerationParameters.isValid()", false, docGenParams.isValid());
	}

	private void validateResult(DocGenerationParameters docGenParams)
	{
		final String subfolder = "Invoices";
		
		assertNotNull("No DocumentGenerationParameters found", docGenParams);
		assertEquals("Unexpected EDMS repository", "DCHR_B03", docGenParams.getEdmsRepository());
		assertEquals("Unexpected EDMS subfolder", subfolder, docGenParams.getEdmsAclName());
		assertEquals("Unexpected EDMS object type", "UW", docGenParams.getEdmsBusinessFunctionCode());
	}
}
