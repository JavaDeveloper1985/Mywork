package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

/**
 * JUnit test class for the {@code DocComponentType} JPA entity.
 */
public class DocComponentTypeTest extends AbstractJpaTest
{
	@Test
	public void testFindAll()
	{
		List<DocComponentType> typeList = 
			getDataAccessService().findWithNamedQuery(
					DocComponentType.class,
					"DocComponentType.findAll");
		
		assertNotNull("Null list", typeList);
		assertEquals("Unexpected number of DocComponentType objects", 3, typeList.size());
		assertEquals("Unexpected DocComponentType #1", "Form", typeList.get(0).getDescription());
		assertEquals("Unexpected DocComponentType #2", "Manuscript", typeList.get(1).getDescription());
		assertEquals("Unexpected DocComponentType #3", "Attachment", typeList.get(2).getDescription());
	}

	@Test
	public void testFindByDescription()
	{
		final String desc = "Manuscript";
		DocComponentType docCmpType =
			getDataAccessService().findSingleResultWithNamedQuery(
					DocComponentType.class,
					"DocComponentType.findByDescription",
					with("desc", desc).parameters());
		
		assertNotNull("Null result", docCmpType);
		assertNotNull("Null result id", docCmpType.getId());
		assertEquals("Unexpected description", desc, docCmpType.getDescription());
	}
}
