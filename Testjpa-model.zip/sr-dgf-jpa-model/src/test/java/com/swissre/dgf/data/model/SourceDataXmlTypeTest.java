package com.swissre.dgf.data.model;

import static com.swissre.dgf.data.access.QueryParameter.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.swissre.dgf.data.AbstractJpaTest;

public class SourceDataXmlTypeTest extends AbstractJpaTest{

	@Test
	public void testFindByQName() {
		final String qname = "{http://www.swissre.com/dgf/man/invoice/v1}invoiceData";
		
		 SourceDataXmlType type = 
			getDataAccessService().findSingleResultWithNamedQuery(
					SourceDataXmlType.class,
					"SourceDataXmlType.findByQName",
					with("qname", qname).parameters());
		assertNotNull("Could not find SourceDataXmlType ", type);
		assertEquals("Unexpected qname", qname, type.getQname());
	}
}
