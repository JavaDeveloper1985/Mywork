'use strict';

SwaggerUi.Views.ParameterContentTypeView = Backbone.View.extend({
  initialize: function  () {},

  render: function(){
    this.model.parameterContentTypeId = 'pct' + Math.random();
    $(this.el).html(Handlebars.templates.parameter_content_type(this.model));
    return this;
  }

});