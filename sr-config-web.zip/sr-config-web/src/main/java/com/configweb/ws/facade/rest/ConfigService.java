package com.configweb.ws.facade.rest;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.configweb.data.access.DataAccessService;
import com.configweb.jpa.entities.Configuration;


public class ConfigService {
	/*@EJB
	DataAccessService dataAccessService;*/
	
	public Config addConfig(Config config){
		/*Configuration cnf  = new Configuration();
		cnf.setConfigData(config.getData());
		cnf = (Configuration) dataAccessService.create(cnf);
		config.setId(Long.toString(cnf.getConfigId()));*/
		return config;
		
	}
	
	public Config getConfig(String id){
		/*Configuration cnf  = new Configuration();
		cnf.setConfigId(Long.parseLong(id));
		cnf = (Configuration) dataAccessService.find(Configuration.class,cnf);
		Config config = new Config();
		config.setId(Long.toString(cnf.getConfigId()));
		config.setData(cnf.getConfigData());*/
		return null;
		
	}
	
	public Config putConfig(Config config){
		/*Configuration cnf  = new Configuration();
		cnf.setConfigId(Long.parseLong(config.getId()));
		cnf.setConfigData(config.getData());
		cnf = (Configuration) dataAccessService.update(cnf);*/
		return config;
		
	}
	
	public void deleteConfig(String id){
		/*Configuration cnf  = new Configuration();
		cnf.setConfigId(Long.parseLong(id));
		dataAccessService.delete(Configuration.class,cnf);*/
		
	}
}
