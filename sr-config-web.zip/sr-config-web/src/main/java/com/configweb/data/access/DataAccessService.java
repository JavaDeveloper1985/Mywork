package com.configweb.data.access;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.annotation.Resource.AuthenticationType;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * A generic data access service EJB used for much of the application's JPA database access.
 * This class is based on Adam Bien's JavaEE patterns; see his
 * <a href="http://www.adam-bien.com/roller/abien/entry/generic_crud_service_aka_dao">
 * Generic CRUD Service</a> article for more info. 
 */
@Stateless
@LocalBean
@TransactionAttribute(TransactionAttributeType.REQUIRED)
@Resource(name="jdbc/configdata", authenticationType=AuthenticationType.CONTAINER, type=javax.sql.DataSource.class )
public class DataAccessService
{
	private static final Logger logger = Logger.getLogger(DataAccessService.class.getName());

	@PersistenceContext(unitName = "ConfigPU")
	EntityManager em;
	
	/**
	 * Creates a new entity in the database.
	 * 
	 * @param <T> The entity's type
	 * @param entity A new entity (i.e., an entity that does not yet exist in the database)
	 * @return The newly-persisted entity
	 */
	public Object create(Object entity)
	{
		this.em.persist(entity);
		this.em.flush();
		if (logger.isLoggable(Level.FINE))
		{
			logger.fine("Created new " + entity.getClass().getSimpleName());
		}
		return entity;
   	}

	/**
	 * Finds an entity by its id.
	 * 
	 * @param <T> The entity's type
	 * @param type The entity's class
	 * @param id The entity's id
	 * @return The entity if found, or null otherwise.
	 */
	public <T> T find(Class<T> type, Object id)
	{
		return (T) this.em.find(type, id);
	}

	/**
	 * Deletes the given entity from the database.
	 * 
	 * @param type The entity's class
	 * @param id The entity's id
	 */
	public void delete(Class<?> type, Object id)
	{
		Object ref = this.em.getReference(type, id);
		this.em.remove(ref);
		
		if (logger.isLoggable(Level.FINE))
		{
			logger.fine("Removed " + type.getSimpleName() + " with id " + id);
		}
	}

	/**
	 * Updates the given entity in the database.
	 * 
	 * @param <T> The entity's type
	 * @param entity The entity
	 * @return The entity after update
	 */
	public <T> T update(T entity)
	{
		return (T) this.em.merge(entity);
	}
	
	/**
	 * Refresh the state of the instance from the database, overwriting changes made to the entity, if any.
	 * 
	 * @param entity The entity to refresh
	 */
	public void refresh(Object entity)
	{
	    this.em.refresh(entity);
	}

	
	/**
	 * @return An {@code EntityManager} reference.
	 */
	public EntityManager getEntityManager() {
        return em;
    }
	

	
}


