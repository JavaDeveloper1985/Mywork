package com.swissre.prodcfg.ws.facade.rest;

import static com.swissre.prodcfg.data.access.QueryParameter.with;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.swissre.prodcfg.data.access.DataAccessService;
import com.swissre.prodcfg.jpa.entities.Product;
import com.swissre.prodcfg.jpa.entities.ProductConfig;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;
import com.swissre.prodcfg.utils.ProdConstants;

@Stateless
@LocalBean
public class ProcessProdService {

	private static final Logger logger = Logger.getLogger(ProcessProdService.class.getName());

	@EJB
	DataAccessService dataAccessService;

	public ProductData addProductData(ProductData product) throws ConfigException {
		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product config details is empty");
			} else {
				prod.setProdName("");
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prod.setProdTypeCd(ProdConstants.PPROD_ID);
				prod.setProductConfig(prodcfg);
				prodcfg.setProduct(prod);
				prod = (Product) dataAccessService.create(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in addProductData at ProcessProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public List<ProductData> getProcessProd() throws ConfigException {
		List<ProductData> configList = new ArrayList<ProductData>();
		try {
			List<Product> cnfList = dataAccessService.findWithNamedQuery(Product.class, ProdConstants.PROD_DETAILS,
					with(ProdConstants.PROD_TYPE_CD, ProdConstants.PPROD_ID).parameters());

			for (Product cnf : cnfList) {
				ProductData config = new ProductData();
				config.setProductId(Long.toString(cnf.getProdId()));
				config.setProductName(cnf.getProdName());
				config.setProductConfig(getProductConfig(cnf.getProductConfig().getProdCfg()));
				configList.add(config);
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in getProcessProd", e);
			throw new ConfigException(e.getMessage());

		}
		return configList;

	}

	public ProductData getProcessProdById(long id) throws ConfigException {
		logger.info("get product by id:" + id);
		ProductData config = new ProductData();
		try {
			Product prod = dataAccessService.findSingleResultWithNamedQuery(Product.class,
					ProdConstants.PROD_DETAILS_BYID, with(ProdConstants.PROD_TYPE_CD, ProdConstants.PPROD_ID)
							.and(ProdConstants.PROD_ID, id).parameters());

			config.setProductId(Long.toString(prod.getProdId()));
			config.setProductName(prod.getProdName());
			config.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
		} catch (ConfigException ce) {
			logger.error("Error in getProcessProdById", ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in getProcessProdById", e);
			throw new ConfigException(e.getMessage());

		}
		return config;

	}

	public ProductData putProductData(ProductData product) throws ConfigException {

		Product prod = new Product();
		ProductConfig prodcfg = new ProductConfig();
		try {
			if (StringUtils.isBlank(product.getProductConfig().toString())) {
				throw new ConfigException("Product config details is empty");
			} else {
				prod.setProdId(Long.parseLong(product.getProductId()));
				prod.setProdName("");
				prod.setProdTypeCd(ProdConstants.PPROD_ID);
				prodcfg.setProdCfg(product.getProductConfig().toString());
				prod.setProductConfig(prodcfg);
				prodcfg.setProduct(prod);
				prod = (Product) dataAccessService.update(prod);
				product.setProductId(Long.toString(prod.getProdId()));
				product.setProductConfig(getProductConfig(prod.getProductConfig().getProdCfg()));
			}
		} catch (ConfigException ce) {
			logger.error(ce.getMsg(), ce);
			throw new ConfigException(ce.getMsg());
		} catch (Exception e) {
			logger.error("Error in putProductData at ProcessProdService", e);
			throw new ConfigException(e.getMessage());

		}
		return product;

	}

	public void deleteProductData(long id)  {
		dataAccessService.delete(Product.class, id);
	}

	public Map<String, Object> getProductConfig(String cngxml) throws ConfigException {
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		logger.info("XML Config data ::" + cngxml);
		try {

			XmlMapper xmlMapper = new XmlMapper();
			jsonInMap = xmlMapper.readValue(cngxml, new TypeReference<Map<String, Object>>() {

			});

		} catch (Exception e) {
			logger.error("Error while converting xml to map object", e);
			throw new ConfigException(e.getMessage());
			// e.printStackTrace();
		}
		return jsonInMap;
	}

}