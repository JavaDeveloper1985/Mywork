package com.swissre.prodcfg.ws.facade.rest;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.Status;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.swissre.prodcfg.models.ProductData;
import com.swissre.prodcfg.utils.ConfigException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Stateless
@LocalBean
@Path("/ProcessProducts")
@Api(value = "Process Products")
public class ProcessProductResource {

	private static final Logger logger = Logger.getLogger(ProcessProductResource.class.getName());
	@EJB
	ProcessProdService ProcessProdService;

	private static final String LINK_SELF = "self";
	@Context
	UriInfo uriInfo;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get Process Products")
	// @Path("/ProcessProducts")
	public Response getProcessProductData() {
		logger.info("Get all data");
		try {
			List<ProductData> configData = ProcessProdService.getProcessProd();
			List<ProductData> productData = new ArrayList<>();
			for (ProductData product : configData) {
				Link link = buildSelfLink(uriInfo, product);
				ProductData pd = new ProductData();
				pd.setProductId(product.getProductId());
				pd.setProductName(product.getProductName());
				pd.setProductConfig(product.getProductConfig());
				pd.addLink(link);
				productData.add(pd);
			}
			logger.info("output all data::" + new ObjectMapper().writeValueAsString(productData));
			return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(productData)).build();
		} catch (ConfigException ce) {
			logger.error("Error in finding all process product details", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while finding all process product details::", e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while finding all process product details::")
					.build();
		}

	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get Process Products by id")
	@Path("/{id}")
	public Response getProcessProductDataById(@ApiParam(value = "product id") @PathParam("id") String id) {
		logger.info("input id:" + id);
		try {
			if (StringUtils.isBlank(id)) {
				throw new ConfigException("Id is null/empty");
			} else {
				ProductData pData = ProcessProdService.getProcessProdById(Long.parseLong(id));
				Link link = buildSelfLink(uriInfo, pData);
				pData.addLink(link);

				logger.info("output product data by id:" + new ObjectMapper().writeValueAsString(pData));
				return Response.status(Status.OK).entity(new ObjectMapper().writeValueAsString(pData)).build();
			}
		} catch (ConfigException ce) {
			logger.error("Error in finding process product details by ID", ce);
			return Response.status(Status.BAD_REQUEST).entity(ce.getMsg()).build();
		} catch (Exception e) {
			logger.error("Error in while finding process details by ID::" + id, e);
			return Response.status(Status.BAD_REQUEST).entity("Error in while finding process details by ID::" + id)
					.build();
		}

	}

	private Link buildSelfLink(UriInfo uriInfo, ProductData product) {
		URI uri = uriInfo.getBaseUriBuilder().path(ProcessProductResource.class).path(product.getProductId()).build();
		Link link = Link.fromUri(uri).rel(LINK_SELF).build();
		return link;
	}

}
