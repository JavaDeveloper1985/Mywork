package com.swissre.prodcfg.data.access;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.annotation.Resource;
import javax.annotation.Resource.AuthenticationType;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.swissre.prodcfg.utils.ProdConstants;

@Stateless
@LocalBean
@Resource(name="jdbc/configdata", authenticationType=AuthenticationType.CONTAINER, type=javax.sql.DataSource.class )
public class DataAccessService
{
	private static final Logger logger = Logger.getLogger(DataAccessService.class.getName());

	@PersistenceContext(unitName = "ConfigPU")
	EntityManager em;
	
	/**
	 * Creates a new entity in the database.
	 * 
	 * @param <T> The entity's type
	 * @param entity A new entity (i.e., an entity that does not yet exist in the database)
	 * @return The newly-persisted entity
	 */
	public Object create(Object entity)
	{
		this.em.persist(entity);
		this.em.flush();
		if (logger.isDebugEnabled())
		{
			logger.debug("Created new " + entity.getClass().getSimpleName());
		}
		return entity;
   	}

	/**
	 * Finds an entity by its id.
	 * 
	 * @param <T> The entity's type
	 * @param type The entity's class
	 * @param id The entity's id
	 * @return The entity if found, or null otherwise.
	 */
	public <T> T find(Class<T> type, Object id)
	{
		return (T) this.em.find(type, id);
	}
	

	/**
	 * Deletes the given entity from the database.
	 * 
	 * @param type The entity's class
	 * @param id The entity's id
	 */
	public void delete(Class<?> type, Object id)
	{
		Object ref = this.em.getReference(type, id);
		this.em.remove(ref);
		
		if (logger.isDebugEnabled())
		{
			logger.debug("Removed " + type.getSimpleName() + " with id " + id);
		}
	}
	/**
	 * Deletes the given entity from the database.
	 * 
	 * @param type The entity's class
	 * @param id The entity's id
	 */
	public void deleteWithNamedQuery(String namedQueryName, Map<String, Object> parameters)
	{
		 Query query = this.em.createNamedQuery(namedQueryName);
         if (parameters != null)
	        {
		        Set<Entry<String, Object>> rawParameters = parameters.entrySet();
		        for (Entry<String, Object> entry : rawParameters) {
		            query.setParameter(entry.getKey(), entry.getValue());
		        }
	        }
        int d=  query.executeUpdate();
         if (logger.isDebugEnabled())
 		{
 			logger.debug("Removed " + d + " with id " + parameters.get(ProdConstants.DPROD_ID));
 		}
	}

	/**
	 * Updates the given entity in the database.
	 * 
	 * @param <T> The entity's type
	 * @param entity The entity
	 * @return The entity after update
	 */
	public <T> T update(T entity)
	{
		return (T) this.em.merge(entity);
	}
	
	/**
	 * Refresh the state of the instance from the database, overwriting changes made to the entity, if any.
	 * 
	 * @param entity The entity to refresh
	 */
	public void refresh(Object entity)
	{
	    this.em.refresh(entity);
	}
	
	/**
	 * Get an instance, whose state may be lazily fetched. If the requested
	 * instance does not exist in the database, throws {@code EntityNotFoundException}
	 * when the instance state is first accessed. (The persistence provider
	 * runtime is permitted to throw EntityNotFoundException when
	 * getReference(java.lang.Class, java.lang.Object) is called.) The
	 * application should not expect that the instance state will be available
	 * upon detachment, unless it was accessed by the application while the
	 * entity manager was open.
	 * 
	 * @param <T> The entity's type
	 * @param entityClass The entity's class
	 * @param id The entity's primary key
	 * @return
	 */
	public <T> T getReference(Class<T> entityClass, Object id)
	{
		return this.em.getReference(entityClass, id);
	}

	/**
	 * Finds entities with a named query.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The expected result type
	 * @param namedQueryName The query's name
	 * @return A {@code List} of entities found by the query
	 */
	public <T> List<T> findWithNamedQuery(Class<T> resultType, String namedQueryName)
	{
		return this.em.createNamedQuery(namedQueryName, resultType).getResultList();
	}

	/**
	 * Finds entities with a named query and the given parameters.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The expected result type
	 * @param namedQueryName The query's name
	 * @param parameters Query parameters as name/value pairs
	 * @return A {@code List} of entities found by the query
	 */
	public <T> List<T> findWithNamedQuery(Class<T> resultType, String namedQueryName, Map<String, Object> parameters)
	{
		return findWithNamedQuery(resultType, namedQueryName, parameters, 0);
	}

	/**
	 * Finds entities with a named query.  Returns no more than {@code resultLimit} entities.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The expected result type
	 * @param namedQueryName The query's name
	 * @param resultLimit The maximum number of entities to find
	 * @return A {@code List} of entities found by the query
	 */
	public <T> List<T> findWithNamedQuery(Class<T> resultType, String namedQueryName, int resultLimit)
	{
		return findWithNamedQuery(resultType, namedQueryName, null, resultLimit);
	}

	/**
	 * Finds entities with a named query and the given parameters.  Returns no more than {@code resultLimit}
	 * entities.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The expected result type
	 * @param namedQueryName The query's name
	 * @param parameters Query parameters as name/value pairs
	 * @param resultLimit The maximum number of entities to find
	 * @return A {@code List} of entities found by the query
	 */
	@SuppressWarnings("unchecked")
	public <T> List<T> findWithNamedQuery(Class<T> resultType, String namedQueryName, Map<String, Object> parameters, int resultLimit)
	{
        Query query = this.em.createNamedQuery(namedQueryName);
        
        if(resultLimit > 0)
        {
            query.setMaxResults(resultLimit);
        }
        
        if (parameters != null)
        {
	        Set<Entry<String, Object>> rawParameters = parameters.entrySet();
	        for (Entry<String, Object> entry : rawParameters) {
	            query.setParameter(entry.getKey(), entry.getValue());
	        }
        }
        
        return (List<T>) query.getResultList();
    }
	
	/**
	 * Finds an entity with a named query.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The entity's class
	 * @param namedQueryName The query's name
	 * @return The entity if found, or null otherwise.
	 * @throws NonUniqueResultException Thrown if the query returns more than one entity
	 */
	public <T> T findSingleResultWithNamedQuery(Class<T> resultType, String namedQueryName)
	{
		return findSingleResultWithNamedQuery(resultType, namedQueryName, null);
	}
	
	/**
	 * Finds an entity with a named query and the given parameters.
	 * 
	 * @param <T> The entity's type
	 * @param resultType The entity's class
	 * @param namedQueryName The query's name
	 * @param parameters Query parameters as name/value pairs
	 * @return The entity if found, or null otherwise.
	 * @throws NonUniqueResultException Thrown if the query returns more than one entity
	 */
	public <T> T findSingleResultWithNamedQuery(Class<T> resultType, String namedQueryName, Map<String, Object> parameters)
	{
		List<T> results = findWithNamedQuery(resultType, namedQueryName, parameters);
		
		if (results.size() > 1)
		{
			throw new NoResultException(
					"Multiple results returned from named query '"
							+ namedQueryName
							+ "' when only 1 result was expected");
		}
		
		return (results.isEmpty() ? null : results.get(0));
	}
	
	/**
	 * @return An {@code EntityManager} reference.
	 */
	public EntityManager getEntityManager() {
        return em;
    }
	
	/**
	 * Executes a named query and returns the results. The results do not need
	 * to be JPA entities. Does NOT limit the number of results returned.
	 * 
	 * @param namedQueryName
	 *            Name of the named query.
	 * @param parameters
	 *            Query parameters as name/value pairs
	 * @return A {@code List} of the results. If the results are not entities,
	 *         then each entry in the {@code List} will typically be an
	 *         {@code Object[]} that holds the fields for one result.
	 */
	@SuppressWarnings("rawtypes")
	public List executeNamedQuery(String namedQueryName, Map<String, Object> parameters) {
		return executeNamedQuery(namedQueryName, parameters, 0);
	}
	
	/**
	 * Executes a named query and returns the results. The results do not need
	 * to be JPA entities. Limits the number of results returned to
	 * {@code resultLimit}.
	 * 
	 * @param namedQueryName
	 *            Name of the named query.
	 * @param parameters
	 *            Query parameters as name/value pairs
	 * @param resultLimit
	 *            The maximum number of entities to find
	 * @return A {@code List} of the results. If the results are not entities,
	 *         then each entry in the {@code List} will typically be an
	 *         {@code Object[]} that holds the fields for one result.
	 */
	@SuppressWarnings("rawtypes")
	public List executeNamedQuery(String namedQueryName, Map<String, Object> parameters, int resultLimit) {
        Query query = this.em.createNamedQuery(namedQueryName);
        
        if(resultLimit > 0)
        {
            query.setMaxResults(resultLimit);
        }
        
        if (parameters != null)
        {
	        Set<Entry<String, Object>> rawParameters = parameters.entrySet();
	        for (Entry<String, Object> entry : rawParameters) {
	            query.setParameter(entry.getKey(), entry.getValue());
	        }
        }
        List resultList = query.getResultList();
        return resultList;
    }
	
}


