package com.configprod.jpa.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="TPRODUCT_CONFIG")
public class ProductConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "ProdConfigSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "ProdConfigSeq", sequenceName = "SEQ_PROD_CONFIG_ID",   allocationSize = 1)
	
	@Lob
	@Column(name="PROD_CFG")
	private String prodCfg;

	//bi-directional one-to-one association to TProduct
	@OneToOne
	@JoinColumn(name="PROD_ID")
	private Product tproduct;

	public ProductConfig() {
	}

	public String getProdCfg() {
		return this.prodCfg;
	}

	public void setProdCfg(String prodCfg) {
		this.prodCfg = prodCfg;
	}

	public Product getTproduct() {
		return this.tproduct;
	}

	public void setTproduct(Product tproduct) {
		this.tproduct = tproduct;
	}

}