package com.configprod.jpa.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TPRODUCT")
@NamedQuery(name="findproddetails",query="select p from Product p where p.prodTypeCd = :pType ")

public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PROD_ID")
	@GeneratedValue(generator = "ProdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "ProdSeq", sequenceName = "SEQ_PROD_ID",   allocationSize = 1)
	private long prodId;

	@Column(name="PROD_NAME")
	private String prodName;
	
	@Column(name="PROD_TYPE_CD")
	private String prodTypeCd;

	//bi-directional one-to-one association to TProductConfig
	@OneToOne(mappedBy="tproduct")
	private ProductConfig tproductConfig;

	public Product() {
	}

	public long getProdId() {
		return this.prodId;
	}

	public void setProdId(long prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return this.prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdTypeCd() {
		return this.prodTypeCd;
	}

	public void setProdTypeCd(String prodTypeCd) {
		this.prodTypeCd = prodTypeCd;
	}

	public ProductConfig getTproductConfig() {
		return this.tproductConfig;
	}

	public void setTproductConfig(ProductConfig tproductConfig) {
		this.tproductConfig = tproductConfig;
	}

}