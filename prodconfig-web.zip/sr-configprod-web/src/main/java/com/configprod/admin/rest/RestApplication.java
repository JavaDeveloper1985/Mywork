package com.configprod.admin.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.configprod.ws.facade.rest.DataPointProdResource;
import com.configprod.ws.facade.rest.ProcessProdResource;



/**
 * Per the JAX-RS API, this extension of the JAX-RS {@code Application} class
 * defines the REST resource classes to the JAX-RS runtime. In the Gateway
 * Services architecture, our resource classes are Service Facades.
 * 
 * @see javax.ws.rs.core.Application
 */
@ApplicationPath("/rest/")
public class RestApplication extends Application
{

    /**
     * This method should return all of the REST Service Facade classes defined
     * by this application.
     * 
     * @see javax.ws.rs.core.Application#getClasses()
     */
    @Override
    public Set<Class<?>> getClasses()
    {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(DataPointProdResource.class);
        classes.add(ProcessProdResource.class);
        return classes;
    }

}
