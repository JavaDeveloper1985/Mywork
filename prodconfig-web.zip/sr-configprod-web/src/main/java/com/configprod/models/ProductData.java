package com.configprod.models;

import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProductData")
public class ProductData {
	
	
private String productId;
private String productName;

@XmlAnyElement(lax=true)
private Object productConfig;

public String getProductId() {
	return productId;
}
public void setProductId(String productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public Object getProductConfig() {
	return productConfig;
}
public void setProductConfig(Object productConfig2) {
	this.productConfig = productConfig2;
}

}
