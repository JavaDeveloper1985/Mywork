package com.configprod.ws.facade.rest;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.configprod.models.ProductData;

@Stateless
@LocalBean
@Path("/datapoint") 
public class DataPointProdResource {
	
	@EJB
	DataPointProdService datapointProdService;
	
	/*@POST
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addConfigData(Config configData) {
		System.out.println("inside path");
		configData  = configService.addConfig(configData);
		return Response.status(200).entity(configData).build();
		
	}*/
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	//@Consumes(MediaType.APPLICATION_JSON)
	@Path("/products")
	public Response getConfigData(){
		System.out.println("inside get path");
		List<ProductData> configData  = datapointProdService.getProd();
		return Response.status(200).entity(configData).build();
		
	}
	
	
	/*@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Response updateConfigData(@PathParam("id") String id, Config configData) {
		System.out.println("inside put path");
		configData.setId(id);
		configData  = configService.putConfig(configData);
		return Response.status(200).entity(configData).build();
		
	}
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Response deleteConfigData(@PathParam("id") String id) {
		System.out.println("inside delete path");
		configService.deleteConfig(id);
		return Response.status(200).entity(id).build();
		
		
	}*/
}