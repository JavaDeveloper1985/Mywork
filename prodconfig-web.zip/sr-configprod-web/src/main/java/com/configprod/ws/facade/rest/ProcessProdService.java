package com.configprod.ws.facade.rest;

import static com.configprod.data.access.QueryParameter.with;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import com.configprod.data.access.DataAccessService;
import com.configprod.jpa.entities.Product;
import com.configprod.models.ProductData;
import com.configprod.utils.ConfigConstants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


@Stateless
@LocalBean
public class ProcessProdService {
	@EJB
	DataAccessService dataAccessService;
	
	/*public Product addConfig(Product config){
		Product cnf  = new Product();
		long cid= dataAccessService.findSingleResultWithNamedQuery(Long.class,
				ConfigConstants.CONFIG_MAX_ID);
		cnf.setId(new ProdId(cid+1, 1l));
		cnf.setConfigData(config.getData());
		cnf = (Product) dataAccessService.create(cnf);
		config.setId(Long.toString(cnf.getId().getConfigId()));
		config.setVersion(Long.toString(cnf.getId().getConfigver()));
		return config;
		
	}*/
	
	public List<ProductData> getConfig(){
		
		List<Product> cnfList = dataAccessService.findWithNamedQuery(Product.class,
				ConfigConstants.PROD_DETAILS,
				with(ConfigConstants.PROD_TYPE_CD,ConfigConstants.PPROD_ID).parameters()
				);
		List<ProductData> configList = new ArrayList<ProductData>();
		for(Product cnf :  cnfList){
			ProductData config = new ProductData();
		config.setProductId(Long.toString(cnf.getProdId()));
		config.setProductName(cnf.getProdName());
		config.setProductConfig(getProductConfig(cnf.getTproductConfig().getProdCfg()));
		configList.add(config);
		}
		return configList;
		
	}
	
	/*public Product putConfig(Product config){
		Product cnf  = new Product();
		long cver= dataAccessService.findSingleResultWithNamedQuery(Long.class,
				ConfigConstants.CONFIG_MAX_VER,
				with(ConfigConstants.CONFIG_ID,Long.parseLong(config.getId())).parameters()
				);

		cnf.setId(new ProdId(Long.parseLong(config.getId()), cver+1));
		cnf.setConfigData(config.getData());
		cnf = (Product) dataAccessService.create(cnf);
		config.setId(Long.toString(cnf.getId().getConfigId()));
		config.setVersion(Long.toString(cnf.getId().getConfigver()));
		return config;
		
	}*/
	
	/*public void deleteConfig(String id){
		 dataAccessService.deleteWithNamedQuery(
				ConfigConstants.CONFIG_DELETE,
				with(ConfigConstants.CONFIG_ID,Long.parseLong(id)).parameters()
				);
	}
	*/
/*	private Date dateFormat(String dat){
		Date date = null;
		String newstring = "";
		try {System.out.println(dat);
			date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(dat);
			newstring = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(date);
			System.out.println(newstring);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
		
		
	}*/
	public Map<String, Object> getProductConfig(String cngxml){
		Map<String, Object> jsonInMap = new HashMap<String, Object>();
		try {
			
			XmlMapper xmlMapper = new XmlMapper();
		    jsonInMap = xmlMapper.readValue(cngxml, new TypeReference<Map<String, Object>>() {
		   
		    });
		    
			} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonInMap;
	}	
	
}