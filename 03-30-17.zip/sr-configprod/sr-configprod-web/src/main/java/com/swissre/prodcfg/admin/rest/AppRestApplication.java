package com.swissre.prodcfg.admin.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.swissre.prodcfg.ws.facade.rest.DataPointProdResource;
import com.swissre.prodcfg.ws.facade.rest.ProcessProdResource;

import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;


/**
 * Per the JAX-RS API, this extension of the JAX-RS {@code Application} class
 * defines the REST resource classes to the JAX-RS runtime. In the Gateway
 * Services architecture, our resource classes are Service Facades.
 * 
 * @see javax.ws.rs.core.Application
 */
public class AppRestApplication extends Application
{

    /**
     * This method should return all of the REST Service Facade classes defined
     * by this application.
     * 
     * @see javax.ws.rs.core.Application#getClasses()
     */
    @Override
    public Set<Class<?>> getClasses()
    {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(ApiListingResource.class);
        classes.add(SwaggerSerializers.class);
        classes.add(DataPointProdResource.class);
        classes.add(ProcessProdResource.class);
        return classes;
    }

}
