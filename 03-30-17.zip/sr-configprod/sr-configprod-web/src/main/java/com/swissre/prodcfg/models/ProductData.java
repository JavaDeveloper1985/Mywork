package com.swissre.prodcfg.models;

import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Link;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.swissre.prodcfg.utils.LinksSerializer;

@JsonAutoDetect(fieldVisibility = Visibility.ANY)
@JsonInclude(Include.NON_NULL)
public class ProductData {

	private String productId;
	private String productName;

	private Object productConfig;

	@JsonProperty("links")
	@JsonSerialize(using = LinksSerializer.class)
	private List<Link> links;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Object getProductConfig() {
		return productConfig;
	}

	public void setProductConfig(Object productConfig) {
		this.productConfig = productConfig;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void addLink(Link link) {
		if (this.links == null) {
			this.links = new ArrayList<Link>();
		}
		this.links.add(link);
	}

	@Override
	public String toString() {
		return "ProductData [productId=" + productId + ", productName=" + productName + ", productConfig="
				+ productConfig + "]";
	}

}
