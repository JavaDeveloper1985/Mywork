package com.swissre.prodcfg.utils;

public class ConfigException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ConfigException(String detail) {
		this(detail, null);
	}

	public ConfigException(String detail, Exception causedBy) {
		super(detail, causedBy);
	}

}
